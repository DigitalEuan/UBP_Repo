"""
RGDL V3.1 Professional - 3D Unfolding Plugin for Laser Cutting
==============================================================

This plugin automatically unfolds 3D shapes into flat 2D patterns optimized for laser cutting.
Features:
- Intelligent surface unfolding algorithms
- Overlap detection and automatic separation
- Connected part preservation
- Material optimization and nesting
- Laser cutting path generation
- Tab and slot generation for assembly

Author: RGDL V3.1 Professional
Date: 2025-06-24
"""

import numpy as np
import trimesh
from scipy.spatial.distance import cdist
from scipy.optimize import minimize
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
import json
import os

class UnfoldingPlugin:
    """
    3D to 2D unfolding plugin for laser cutting applications
    """
    
    def __init__(self):
        self.mesh = None
        self.unfolded_faces = []
        self.face_connections = {}
        self.overlap_threshold = 0.001  # 1mm overlap threshold
        self.material_thickness = 0.003  # 3mm default material thickness
        self.kerf_width = 0.0002  # 0.2mm laser kerf
        self.tab_size = 0.01  # 10mm tab size
        self.slot_tolerance = 0.0001  # 0.1mm slot tolerance
        
    def load_mesh_from_bitfield(self, bitfield, voxel_size=0.001):
        """
        Convert RGDL bitfield to mesh for unfolding
        
        Args:
            bitfield: 3D numpy array representing the geometry
            voxel_size: Size of each voxel in meters
        """
        # Extract surface mesh from bitfield using marching cubes
        from skimage import measure
        
        # Apply marching cubes to extract surface
        vertices, faces, normals, values = measure.marching_cubes(
            bitfield, level=0.5, spacing=(voxel_size, voxel_size, voxel_size)
        )
        
        # Create trimesh object
        self.mesh = trimesh.Trimesh(vertices=vertices, faces=faces)
        self.mesh.fix_normals()
        
        print(f"Loaded mesh with {len(vertices)} vertices and {len(faces)} faces")
        return True
        
    def analyze_face_connectivity(self):
        """
        Analyze which faces are connected and should remain together
        """
        if self.mesh is None:
            raise ValueError("No mesh loaded")
            
        # Get face adjacency information
        face_adjacency = self.mesh.face_adjacency
        face_adjacency_edges = self.mesh.face_adjacency_edges
        
        # Build connectivity graph
        self.face_connections = {}
        for i, (face1, face2) in enumerate(face_adjacency):
            if face1 not in self.face_connections:
                self.face_connections[face1] = []
            if face2 not in self.face_connections:
                self.face_connections[face2] = []
                
            # Calculate edge length to determine connection strength
            edge_vertices = face_adjacency_edges[i]
            edge_length = np.linalg.norm(
                self.mesh.vertices[edge_vertices[1]] - self.mesh.vertices[edge_vertices[0]]
            )
            
            self.face_connections[face1].append({
                'face': face2,
                'edge_length': edge_length,
                'edge_vertices': edge_vertices
            })
            self.face_connections[face2].append({
                'face': face1,
                'edge_length': edge_length,
                'edge_vertices': edge_vertices
            })
            
        print(f"Analyzed connectivity for {len(self.face_connections)} faces")
        
    def unfold_connected_component(self, start_face, visited_faces=None):
        """
        Unfold a connected component starting from a specific face
        
        Args:
            start_face: Index of the face to start unfolding from
            visited_faces: Set of already processed faces
            
        Returns:
            Dictionary containing unfolded face positions and orientations
        """
        if visited_faces is None:
            visited_faces = set()
            
        if start_face in visited_faces:
            return {}
            
        unfolded_component = {}
        face_queue = [start_face]
        
        # Place the first face at origin
        face_vertices = self.mesh.faces[start_face]
        face_coords = self.mesh.vertices[face_vertices]
        
        # Project first face to 2D (use first three vertices)
        v1, v2, v3 = face_coords[:3]
        
        # Create 2D coordinate system
        u_axis = v2 - v1
        u_axis = u_axis / np.linalg.norm(u_axis)
        
        # Calculate face normal
        face_normal = np.cross(v2 - v1, v3 - v1)
        face_normal = face_normal / np.linalg.norm(face_normal)
        
        # Create v axis perpendicular to u in the face plane
        v_axis = np.cross(face_normal, u_axis)
        
        # Project vertices to 2D
        face_2d = []
        for vertex in face_coords:
            u_coord = np.dot(vertex - v1, u_axis)
            v_coord = np.dot(vertex - v1, v_axis)
            face_2d.append([u_coord, v_coord])
            
        unfolded_component[start_face] = {
            'vertices_2d': np.array(face_2d),
            'vertices_3d': face_coords,
            'position': np.array([0.0, 0.0]),
            'rotation': 0.0,
            'face_normal': face_normal
        }
        
        visited_faces.add(start_face)
        
        # Process connected faces
        while face_queue:
            current_face = face_queue.pop(0)
            
            if current_face not in self.face_connections:
                continue
                
            for connection in self.face_connections[current_face]:
                connected_face = connection['face']
                
                if connected_face in visited_faces:
                    continue
                    
                # Unfold the connected face
                edge_vertices = connection['edge_vertices']
                
                # Get shared edge in both faces
                current_face_vertices = self.mesh.faces[current_face]
                connected_face_vertices = self.mesh.faces[connected_face]
                
                # Find shared edge vertices
                shared_vertices = []
                for v in edge_vertices:
                    if v in current_face_vertices and v in connected_face_vertices:
                        shared_vertices.append(v)
                        
                if len(shared_vertices) >= 2:
                    # Unfold connected face relative to current face
                    unfolded_face = self._unfold_adjacent_face(
                        current_face, connected_face, shared_vertices[:2], unfolded_component
                    )
                    
                    if unfolded_face:
                        unfolded_component[connected_face] = unfolded_face
                        visited_faces.add(connected_face)
                        face_queue.append(connected_face)
                        
        return unfolded_component
        
    def _unfold_adjacent_face(self, base_face, adjacent_face, shared_edge, unfolded_component):
        """
        Unfold an adjacent face relative to a base face
        """
        # Get 3D coordinates
        base_vertices = self.mesh.vertices[self.mesh.faces[base_face]]
        adjacent_vertices = self.mesh.vertices[self.mesh.faces[adjacent_face]]
        
        # Get shared edge vertices
        edge_v1 = self.mesh.vertices[shared_edge[0]]
        edge_v2 = self.mesh.vertices[shared_edge[1]]
        
        # Calculate fold angle between faces
        base_normal = unfolded_component[base_face]['face_normal']
        
        # Calculate adjacent face normal
        adj_v1, adj_v2, adj_v3 = adjacent_vertices[:3]
        adjacent_normal = np.cross(adj_v2 - adj_v1, adj_v3 - adj_v1)
        adjacent_normal = adjacent_normal / np.linalg.norm(adjacent_normal)
        
        # Calculate fold angle
        fold_angle = np.arccos(np.clip(np.dot(base_normal, adjacent_normal), -1.0, 1.0))
        
        # Project adjacent face to 2D by rotating around shared edge
        edge_direction = edge_v2 - edge_v1
        edge_direction = edge_direction / np.linalg.norm(edge_direction)
        
        # Find the vertex in adjacent face that's not on the shared edge
        non_edge_vertex = None
        for vertex in adjacent_vertices:
            if not (np.allclose(vertex, edge_v1) or np.allclose(vertex, edge_v2)):
                non_edge_vertex = vertex
                break
                
        if non_edge_vertex is None:
            return None
            
        # Rotate the non-edge vertex around the shared edge
        # This is a simplified unfolding - in practice, more sophisticated algorithms needed
        
        # Project to 2D coordinate system of base face
        base_2d = unfolded_component[base_face]['vertices_2d']
        
        # Find shared edge in 2D coordinates of base face
        base_face_vertices = self.mesh.faces[base_face]
        edge_indices_in_base = []
        for i, v_idx in enumerate(base_face_vertices):
            if v_idx in shared_edge:
                edge_indices_in_base.append(i)
                
        if len(edge_indices_in_base) >= 2:
            edge_2d_v1 = base_2d[edge_indices_in_base[0]]
            edge_2d_v2 = base_2d[edge_indices_in_base[1]]
            
            # Calculate position of unfolded vertex
            edge_2d_direction = edge_2d_v2 - edge_2d_v1
            edge_2d_normal = np.array([-edge_2d_direction[1], edge_2d_direction[0]])
            edge_2d_normal = edge_2d_normal / np.linalg.norm(edge_2d_normal)
            
            # Distance from non-edge vertex to shared edge
            edge_to_vertex = non_edge_vertex - edge_v1
            distance_to_edge = np.linalg.norm(edge_to_vertex - np.dot(edge_to_vertex, edge_direction) * edge_direction)
            
            # Position in 2D
            edge_midpoint_2d = (edge_2d_v1 + edge_2d_v2) / 2
            unfolded_vertex_2d = edge_midpoint_2d + distance_to_edge * edge_2d_normal
            
            # Create 2D face representation
            adjacent_2d = []
            for vertex in adjacent_vertices:
                if np.allclose(vertex, edge_v1):
                    adjacent_2d.append(edge_2d_v1)
                elif np.allclose(vertex, edge_v2):
                    adjacent_2d.append(edge_2d_v2)
                else:
                    adjacent_2d.append(unfolded_vertex_2d)
                    
            return {
                'vertices_2d': np.array(adjacent_2d),
                'vertices_3d': adjacent_vertices,
                'position': np.mean(adjacent_2d, axis=0),
                'rotation': 0.0,
                'face_normal': adjacent_normal
            }
            
        return None
        
    def detect_overlaps(self, unfolded_faces):
        """
        Detect overlapping faces in the 2D layout
        """
        overlaps = []
        
        face_ids = list(unfolded_faces.keys())
        for i, face1_id in enumerate(face_ids):
            for face2_id in face_ids[i+1:]:
                face1 = unfolded_faces[face1_id]
                face2 = unfolded_faces[face2_id]
                
                # Check if polygons overlap
                if self._polygons_overlap(face1['vertices_2d'], face2['vertices_2d']):
                    overlaps.append((face1_id, face2_id))
                    
        return overlaps
        
    def _polygons_overlap(self, poly1, poly2):
        """
        Check if two 2D polygons overlap
        """
        from shapely.geometry import Polygon as ShapelyPolygon
        
        try:
            p1 = ShapelyPolygon(poly1)
            p2 = ShapelyPolygon(poly2)
            return p1.intersects(p2) and p1.intersection(p2).area > self.overlap_threshold
        except:
            # Fallback to simple bounding box check
            min1, max1 = np.min(poly1, axis=0), np.max(poly1, axis=0)
            min2, max2 = np.min(poly2, axis=0), np.max(poly2, axis=0)
            
            return not (max1[0] < min2[0] or max2[0] < min1[0] or 
                       max1[1] < min2[1] or max2[1] < min1[1])
                       
    def separate_overlapping_parts(self, unfolded_faces, overlaps):
        """
        Separate overlapping parts while maintaining connections
        """
        # Group connected components
        components = self._find_connected_components(unfolded_faces)
        
        # For each overlap, move one component to avoid intersection
        for face1_id, face2_id in overlaps:
            # Find which components these faces belong to
            comp1 = None
            comp2 = None
            
            for i, component in enumerate(components):
                if face1_id in component:
                    comp1 = i
                if face2_id in component:
                    comp2 = i
                    
            if comp1 != comp2 and comp1 is not None and comp2 is not None:
                # Move the smaller component
                if len(components[comp1]) <= len(components[comp2]):
                    self._move_component(components[comp1], unfolded_faces, direction='right')
                else:
                    self._move_component(components[comp2], unfolded_faces, direction='right')
                    
    def _find_connected_components(self, unfolded_faces):
        """
        Find connected components in the unfolded layout
        """
        components = []
        visited = set()
        
        for face_id in unfolded_faces.keys():
            if face_id not in visited:
                component = []
                self._dfs_component(face_id, component, visited, unfolded_faces)
                components.append(component)
                
        return components
        
    def _dfs_component(self, face_id, component, visited, unfolded_faces):
        """
        Depth-first search to find connected component
        """
        if face_id in visited:
            return
            
        visited.add(face_id)
        component.append(face_id)
        
        # Check connections
        if face_id in self.face_connections:
            for connection in self.face_connections[face_id]:
                connected_face = connection['face']
                if connected_face in unfolded_faces and connected_face not in visited:
                    self._dfs_component(connected_face, component, visited, unfolded_faces)
                    
    def _move_component(self, component, unfolded_faces, direction='right'):
        """
        Move a component to avoid overlaps
        """
        # Calculate bounding box of all components
        all_vertices = []
        for face_id in unfolded_faces.keys():
            all_vertices.extend(unfolded_faces[face_id]['vertices_2d'])
            
        all_vertices = np.array(all_vertices)
        overall_bounds = [np.min(all_vertices, axis=0), np.max(all_vertices, axis=0)]
        
        # Calculate movement distance
        if direction == 'right':
            move_distance = overall_bounds[1][0] - overall_bounds[0][0] + 0.02  # 2cm gap
            move_vector = np.array([move_distance, 0])
        else:
            move_distance = overall_bounds[1][1] - overall_bounds[0][1] + 0.02  # 2cm gap
            move_vector = np.array([0, move_distance])
            
        # Move all faces in the component
        for face_id in component:
            unfolded_faces[face_id]['vertices_2d'] += move_vector
            unfolded_faces[face_id]['position'] += move_vector
            
    def generate_tabs_and_slots(self, unfolded_faces):
        """
        Generate tabs and slots for assembly
        """
        tabs_and_slots = []
        
        for face_id in unfolded_faces.keys():
            if face_id not in self.face_connections:
                continue
                
            for connection in self.face_connections[face_id]:
                connected_face = connection['face']
                
                if connected_face in unfolded_faces:
                    # Generate tab on one face and slot on the other
                    edge_vertices = connection['edge_vertices']
                    edge_length = connection['edge_length']
                    
                    # Only add tabs to edges longer than minimum size
                    if edge_length > self.tab_size * 2:
                        tab_info = {
                            'face_with_tab': face_id,
                            'face_with_slot': connected_face,
                            'edge_vertices': edge_vertices,
                            'tab_size': self.tab_size,
                            'slot_tolerance': self.slot_tolerance
                        }
                        tabs_and_slots.append(tab_info)
                        
        return tabs_and_slots
        
    def optimize_material_usage(self, unfolded_faces, material_width=1.0, material_height=1.0):
        """
        Optimize layout for material usage
        """
        # Simple bin packing algorithm
        # In practice, would use more sophisticated nesting algorithms
        
        components = self._find_connected_components(unfolded_faces)
        
        # Sort components by area (largest first)
        component_areas = []
        for component in components:
            total_area = 0
            for face_id in component:
                vertices = unfolded_faces[face_id]['vertices_2d']
                # Calculate polygon area using shoelace formula
                area = 0.5 * abs(sum(vertices[i][0] * vertices[(i+1) % len(vertices)][1] - 
                                   vertices[(i+1) % len(vertices)][0] * vertices[i][1] 
                                   for i in range(len(vertices))))
                total_area += area
            component_areas.append((total_area, component))
            
        component_areas.sort(reverse=True)
        
        # Place components using bottom-left fill algorithm
        placed_components = []
        current_y = 0
        row_height = 0
        current_x = 0
        
        for area, component in component_areas:
            # Calculate component bounding box
            all_vertices = []
            for face_id in component:
                all_vertices.extend(unfolded_faces[face_id]['vertices_2d'])
                
            vertices_array = np.array(all_vertices)
            min_bounds = np.min(vertices_array, axis=0)
            max_bounds = np.max(vertices_array, axis=0)
            
            component_width = max_bounds[0] - min_bounds[0]
            component_height = max_bounds[1] - min_bounds[1]
            
            # Check if component fits in current row
            if current_x + component_width > material_width:
                # Move to next row
                current_y += row_height + 0.01  # 1cm gap between rows
                current_x = 0
                row_height = 0
                
            # Move component to position
            move_vector = np.array([current_x - min_bounds[0], current_y - min_bounds[1]])
            
            for face_id in component:
                unfolded_faces[face_id]['vertices_2d'] += move_vector
                unfolded_faces[face_id]['position'] += move_vector
                
            current_x += component_width + 0.01  # 1cm gap between components
            row_height = max(row_height, component_height)
            
            placed_components.append({
                'component': component,
                'position': [current_x - component_width, current_y],
                'size': [component_width, component_height]
            })
            
        return placed_components
        
    def generate_laser_cutting_paths(self, unfolded_faces, tabs_and_slots):
        """
        Generate optimized laser cutting paths
        """
        cutting_paths = []
        
        for face_id, face_data in unfolded_faces.items():
            vertices = face_data['vertices_2d']
            
            # Create cutting path for face perimeter
            path = {
                'type': 'cut',
                'face_id': face_id,
                'path': vertices.tolist(),
                'closed': True,
                'speed': 1000,  # mm/min
                'power': 80     # percentage
            }
            cutting_paths.append(path)
            
        # Add tab and slot cutting paths
        for tab_slot in tabs_and_slots:
            # Generate tab geometry
            tab_path = self._generate_tab_geometry(tab_slot, unfolded_faces)
            if tab_path:
                cutting_paths.append(tab_path)
                
            # Generate slot geometry
            slot_path = self._generate_slot_geometry(tab_slot, unfolded_faces)
            if slot_path:
                cutting_paths.append(slot_path)
                
        return cutting_paths
        
    def _generate_tab_geometry(self, tab_slot, unfolded_faces):
        """
        Generate tab cutting geometry
        """
        face_id = tab_slot['face_with_tab']
        if face_id not in unfolded_faces:
            return None
            
        # Simplified tab generation
        # In practice, would calculate exact tab position on edge
        face_vertices = unfolded_faces[face_id]['vertices_2d']
        center = np.mean(face_vertices, axis=0)
        
        # Create rectangular tab
        tab_width = tab_slot['tab_size']
        tab_height = self.material_thickness
        
        tab_vertices = [
            [center[0] - tab_width/2, center[1] - tab_height/2],
            [center[0] + tab_width/2, center[1] - tab_height/2],
            [center[0] + tab_width/2, center[1] + tab_height/2],
            [center[0] - tab_width/2, center[1] + tab_height/2]
        ]
        
        return {
            'type': 'cut',
            'face_id': face_id,
            'feature': 'tab',
            'path': tab_vertices,
            'closed': True,
            'speed': 800,
            'power': 70
        }
        
    def _generate_slot_geometry(self, tab_slot, unfolded_faces):
        """
        Generate slot cutting geometry
        """
        face_id = tab_slot['face_with_slot']
        if face_id not in unfolded_faces:
            return None
            
        # Simplified slot generation
        face_vertices = unfolded_faces[face_id]['vertices_2d']
        center = np.mean(face_vertices, axis=0)
        
        # Create rectangular slot (slightly larger than tab)
        slot_width = tab_slot['tab_size'] + tab_slot['slot_tolerance']
        slot_height = self.material_thickness + tab_slot['slot_tolerance']
        
        slot_vertices = [
            [center[0] - slot_width/2, center[1] - slot_height/2],
            [center[0] + slot_width/2, center[1] - slot_height/2],
            [center[0] + slot_width/2, center[1] + slot_height/2],
            [center[0] - slot_width/2, center[1] + slot_height/2]
        ]
        
        return {
            'type': 'cut',
            'face_id': face_id,
            'feature': 'slot',
            'path': slot_vertices,
            'closed': True,
            'speed': 800,
            'power': 70
        }
        
    def export_dxf(self, cutting_paths, filename):
        """
        Export cutting paths to DXF format for laser cutting
        """
        try:
            import ezdxf
            
            # Create DXF document
            doc = ezdxf.new('R2000')
            msp = doc.modelspace()
            
            # Add cutting paths as polylines
            for path in cutting_paths:
                vertices = path['path']
                
                if path['closed']:
                    # Add closed polyline
                    polyline = msp.add_lwpolyline(vertices)
                    polyline.close()
                else:
                    # Add open polyline
                    msp.add_lwpolyline(vertices)
                    
                # Set layer based on operation type
                if path.get('feature') == 'tab':
                    polyline.dxf.layer = 'TABS'
                elif path.get('feature') == 'slot':
                    polyline.dxf.layer = 'SLOTS'
                else:
                    polyline.dxf.layer = 'CUTS'
                    
            # Save DXF file
            doc.saveas(filename)
            print(f"Exported DXF to {filename}")
            return True
            
        except ImportError:
            print("ezdxf not available, creating simple DXF format")
            
            # Create simple DXF format manually
            with open(filename, 'w') as f:
                f.write("0\nSECTION\n2\nENTITIES\n")
                
                for path in cutting_paths:
                    vertices = path['path']
                    
                    # Write polyline
                    f.write("0\nLWPOLYLINE\n")
                    f.write(f"90\n{len(vertices)}\n")
                    f.write("70\n1\n" if path['closed'] else "70\n0\n")
                    
                    for vertex in vertices:
                        f.write(f"10\n{vertex[0]:.6f}\n")
                        f.write(f"20\n{vertex[1]:.6f}\n")
                        
                f.write("0\nENDSEC\n0\nEOF\n")
                
            print(f"Exported simple DXF to {filename}")
            return True
            
    def unfold_mesh(self, bitfield=None, mesh=None):
        """
        Main unfolding function
        """
        if bitfield is not None:
            self.load_mesh_from_bitfield(bitfield)
        elif mesh is not None:
            self.mesh = mesh
        else:
            raise ValueError("Either bitfield or mesh must be provided")
            
        # Analyze connectivity
        self.analyze_face_connectivity()
        
        # Unfold all connected components
        all_unfolded_faces = {}
        visited_faces = set()
        
        for face_id in range(len(self.mesh.faces)):
            if face_id not in visited_faces:
                component = self.unfold_connected_component(face_id, visited_faces)
                all_unfolded_faces.update(component)
                
        # Detect and resolve overlaps
        overlaps = self.detect_overlaps(all_unfolded_faces)
        if overlaps:
            print(f"Found {len(overlaps)} overlaps, separating...")
            self.separate_overlapping_parts(all_unfolded_faces, overlaps)
            
        # Optimize material usage
        self.optimize_material_usage(all_unfolded_faces)
        
        # Generate tabs and slots
        tabs_and_slots = self.generate_tabs_and_slots(all_unfolded_faces)
        
        # Generate cutting paths
        cutting_paths = self.generate_laser_cutting_paths(all_unfolded_faces, tabs_and_slots)
        
        return {
            'unfolded_faces': all_unfolded_faces,
            'tabs_and_slots': tabs_and_slots,
            'cutting_paths': cutting_paths,
            'overlaps_resolved': len(overlaps)
        }
        
    def visualize_unfolding(self, result, save_path=None):
        """
        Visualize the unfolded layout
        """
        fig, ax = plt.subplots(1, 1, figsize=(12, 8))
        
        # Plot unfolded faces
        for face_id, face_data in result['unfolded_faces'].items():
            vertices = face_data['vertices_2d']
            polygon = Polygon(vertices, alpha=0.7, edgecolor='black', linewidth=1)
            ax.add_patch(polygon)
            
            # Add face label
            center = np.mean(vertices, axis=0)
            ax.text(center[0], center[1], str(face_id), ha='center', va='center', fontsize=8)
            
        # Plot tabs and slots
        for tab_slot in result['tabs_and_slots']:
            # Simplified visualization
            pass
            
        ax.set_aspect('equal')
        ax.grid(True, alpha=0.3)
        ax.set_title('3D Unfolding Result for Laser Cutting')
        ax.set_xlabel('X (meters)')
        ax.set_ylabel('Y (meters)')
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            
        plt.show()
        
        return fig, ax


# Integration with RGDL V3.1 Professional
class RGDLUnfoldingIntegration:
    """
    Integration class for RGDL V3.1 Professional
    """
    
    def __init__(self, rgdl_system):
        self.rgdl_system = rgdl_system
        self.unfolding_plugin = UnfoldingPlugin()
        
    def unfold_current_geometry(self, material_thickness=0.003, kerf_width=0.0002):
        """
        Unfold the current geometry in RGDL system
        """
        # Get current bitfield from RGDL system
        if hasattr(self.rgdl_system, 'bitfield'):
            bitfield = self.rgdl_system.bitfield
        else:
            raise ValueError("No geometry loaded in RGDL system")
            
        # Configure unfolding parameters
        self.unfolding_plugin.material_thickness = material_thickness
        self.unfolding_plugin.kerf_width = kerf_width
        
        # Perform unfolding
        result = self.unfolding_plugin.unfold_mesh(bitfield=bitfield)
        
        return result
        
    def export_for_laser_cutting(self, result, output_dir="laser_cutting_output"):
        """
        Export unfolding result for laser cutting
        """
        os.makedirs(output_dir, exist_ok=True)
        
        # Export DXF file
        dxf_path = os.path.join(output_dir, "unfolded_parts.dxf")
        self.unfolding_plugin.export_dxf(result['cutting_paths'], dxf_path)
        
        # Export visualization
        viz_path = os.path.join(output_dir, "unfolding_layout.png")
        self.unfolding_plugin.visualize_unfolding(result, viz_path)
        
        # Export assembly instructions
        assembly_path = os.path.join(output_dir, "assembly_instructions.json")
        assembly_data = {
            'tabs_and_slots': result['tabs_and_slots'],
            'material_thickness': self.unfolding_plugin.material_thickness,
            'assembly_notes': "Connect parts using tabs and slots. Ensure proper fit before final assembly."
        }
        
        with open(assembly_path, 'w') as f:
            json.dump(assembly_data, f, indent=2)
            
        print(f"Laser cutting files exported to {output_dir}")
        return output_dir


if __name__ == "__main__":
    # Example usage
    plugin = UnfoldingPlugin()
    
    # Create a simple test cube
    test_bitfield = np.zeros((20, 20, 20), dtype=np.uint8)
    test_bitfield[5:15, 5:15, 5:15] = 1  # 10x10x10 cube
    
    # Unfold the cube
    result = plugin.unfold_mesh(bitfield=test_bitfield)
    
    # Visualize result
    plugin.visualize_unfolding(result)
    
    # Export for laser cutting
    plugin.export_dxf(result['cutting_paths'], "test_cube_unfolded.dxf")
    
    print("Unfolding plugin demonstration complete!")

