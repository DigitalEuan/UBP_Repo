"""
RGDL V3.2 Professional - Assembly Analyzer (Corrected)
Universal Binary Principle Engineering Platform
"""

import numpy as np
import json
from typing import Dict, List, Tuple, Optional, Any

class AssemblyObject:
    """Represents an object in an assembly"""
    
    def __init__(self, name, shape_type, geometry_params, material, position=(0, 0, 0)):
        self.name = name
        self.shape_type = shape_type
        self.geometry_params = geometry_params
        self.material = material
        self.position = np.array(position)
        self.nodes = []
        self.elements = []
        self.mesh_generated = False
        
    def generate_mesh(self, resolution=0.005):
        """Generate mesh for this object"""
        # Simplified mesh generation based on shape type
        if self.shape_type == "cube":
            size = self.geometry_params.get('size', 0.05)
            self._generate_cube_mesh(size, resolution)
        elif self.shape_type == "cylinder":
            radius = self.geometry_params.get('radius', 0.025)
            height = self.geometry_params.get('height', 0.1)
            self._generate_cylinder_mesh(radius, height, resolution)
        else:
            # Default simple mesh
            self._generate_simple_mesh(resolution)
            
        self.mesh_generated = True
        
    def _generate_cube_mesh(self, size, resolution):
        """Generate mesh for cube"""
        n = int(size / resolution) + 1
        nodes = []
        
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    x = i * resolution + self.position[0]
                    y = j * resolution + self.position[1]
                    z = k * resolution + self.position[2]
                    nodes.append([x, y, z])
        
        self.nodes = np.array(nodes)
        
        # Generate simple tetrahedral elements
        elements = []
        for i in range(n-1):
            for j in range(n-1):
                for k in range(n-1):
                    base = i * n * n + j * n + k
                    # Create tetrahedra (simplified)
                    if base + n*n + n + 1 < len(nodes):
                        elements.append([base, base+1, base+n, base+n*n])
        
        self.elements = np.array(elements)
        
    def _generate_cylinder_mesh(self, radius, height, resolution):
        """Generate mesh for cylinder"""
        # Simplified cylindrical mesh
        n_r = int(radius / resolution) + 1
        n_h = int(height / resolution) + 1
        n_theta = 16  # Angular divisions
        
        nodes = []
        for i in range(n_h):
            for j in range(n_theta):
                for k in range(n_r):
                    theta = 2 * np.pi * j / n_theta
                    r = k * radius / (n_r - 1)
                    x = r * np.cos(theta) + self.position[0]
                    y = r * np.sin(theta) + self.position[1]
                    z = i * height / (n_h - 1) + self.position[2]
                    nodes.append([x, y, z])
        
        self.nodes = np.array(nodes)
        
        # Generate elements (simplified)
        elements = []
        for i in range(min(100, len(nodes)//4)):
            base = i * 4
            if base + 3 < len(nodes):
                elements.append([base, base+1, base+2, base+3])
        
        self.elements = np.array(elements)
        
    def _generate_simple_mesh(self, resolution):
        """Generate simple default mesh"""
        # Create a simple 2x2x2 mesh
        size = 0.05
        nodes = []
        for i in range(3):
            for j in range(3):
                for k in range(3):
                    x = i * size/2 + self.position[0]
                    y = j * size/2 + self.position[1]
                    z = k * size/2 + self.position[2]
                    nodes.append([x, y, z])
        
        self.nodes = np.array(nodes)
        
        # Simple tetrahedral elements
        elements = [
            [0, 1, 3, 9],
            [1, 2, 4, 10],
            [3, 4, 6, 12],
            [4, 5, 7, 13]
        ]
        self.elements = np.array(elements)


class ContactInterface:
    """Represents contact between two objects"""
    
    def __init__(self, object1_id, object2_id, contact_type="bonded", friction_coeff=0.3):
        self.object1_id = object1_id
        self.object2_id = object2_id
        self.contact_type = contact_type
        self.friction_coefficient = friction_coeff
        self.contact_pairs = []
        self.contact_forces = []
        
    def detect_contact_pairs(self, obj1_nodes, obj2_nodes, tolerance=0.001):
        """Detect contact node pairs between objects"""
        contact_pairs = []
        
        for i, node1 in enumerate(obj1_nodes):
            for j, node2 in enumerate(obj2_nodes):
                distance = np.linalg.norm(node1 - node2)
                if distance < tolerance:
                    contact_pairs.append((i, j, distance))
        
        self.contact_pairs = contact_pairs
        return len(contact_pairs)


class AssemblyAnalyzer:
    """
    Multi-object assembly analysis system (Corrected)
    """
    
    def __init__(self, bitfield=None):
        self.bitfield = bitfield
        self.objects = {}  # Changed from list to dict for easier access
        self.contact_interfaces = []
        self.global_nodes = []
        self.global_elements = []
        self.node_mapping = {}  # Maps local to global node indices
        self.results = {}
        
        # UBP parameters
        self.ubp_params = {
            'toggle_frequency': 3.14159,
            'coherence_threshold': 0.9999878,
            'assembly_resonance': True
        }
        
    def add_object(self, assembly_object):
        """Add an AssemblyObject to the assembly"""
        if isinstance(assembly_object, AssemblyObject):
            self.objects[assembly_object.name] = assembly_object
            print(f"Added object '{assembly_object.name}' to assembly")
        else:
            # Handle legacy interface for backward compatibility
            if isinstance(assembly_object, str):
                name = assembly_object
                # Create a default object
                obj = AssemblyObject(name, "cube", {"size": 0.05}, "steel")
                self.objects[name] = obj
                print(f"Added object '{name}' to assembly")
            else:
                print("Error: Invalid object type for add_object")
                
    def add_object_legacy(self, name, shape_type, geometry_params, material, position=(0, 0, 0)):
        """Legacy method for adding objects (for backward compatibility)"""
        obj = AssemblyObject(name, shape_type, geometry_params, material, position)
        self.objects[name] = obj
        print(f"Added object '{name}' to assembly")
        
    def detect_contacts(self, tolerance=0.001):
        """Detect contact interfaces between objects"""
        contact_count = 0
        object_list = list(self.objects.values())
        
        for i in range(len(object_list)):
            for j in range(i + 1, len(object_list)):
                obj1 = object_list[i]
                obj2 = object_list[j]
                
                # Ensure objects have meshes
                if not obj1.mesh_generated:
                    obj1.generate_mesh()
                if not obj2.mesh_generated:
                    obj2.generate_mesh()
                
                # Create contact interface
                contact = ContactInterface(obj1.name, obj2.name)
                pairs = contact.detect_contact_pairs(obj1.nodes, obj2.nodes, tolerance)
                
                if pairs > 0:
                    self.contact_interfaces.append(contact)
                    contact_count += pairs
        
        print(f"Detected {len(self.contact_interfaces)} contact interfaces")
        return self.contact_interfaces
        
    def add_contact_interface(self, object1_id, object2_id, contact_type="bonded"):
        """Manually add contact interface between objects"""
        contact = ContactInterface(object1_id, object2_id, contact_type)
        self.contact_interfaces.append(contact)
        print(f"Added {contact_type} contact between {object1_id} and {object2_id}")
        
    def assemble_global_system(self):
        """Assemble global system matrices from all objects"""
        print("Assembling global system...")
        
        # Generate meshes for all objects
        for obj in self.objects.values():
            if not obj.mesh_generated:
                obj.generate_mesh()
        
        # Combine all nodes and elements
        self.global_nodes = []
        self.global_elements = []
        self.node_mapping = {}
        
        current_node_offset = 0
        current_element_offset = 0
        
        for obj_name, obj in self.objects.items():
            # Map local nodes to global indices
            local_to_global = {}
            for i, node in enumerate(obj.nodes):
                global_index = current_node_offset + i
                local_to_global[i] = global_index
                self.global_nodes.append(node)
            
            self.node_mapping[obj_name] = local_to_global
            
            # Add elements with global node indices
            for element in obj.elements:
                global_element = [local_to_global.get(node_id, node_id) for node_id in element]
                self.global_elements.append(global_element)
            
            current_node_offset += len(obj.nodes)
            current_element_offset += len(obj.elements)
        
        self.global_nodes = np.array(self.global_nodes)
        self.global_elements = np.array(self.global_elements)
        
        print(f"Global system: {len(self.global_nodes)} nodes, {len(self.global_elements)} elements")
        return True
        
    def solve_assembly_analysis(self, analysis_type="static"):
        """Solve assembly-level analysis"""
        print(f"Solving {analysis_type} assembly analysis...")
        
        if not self.assemble_global_system():
            return False
        
        # Simplified analysis - in real implementation would use FEA engine
        if analysis_type == "static":
            return self._solve_static_assembly()
        elif analysis_type == "modal":
            return self._solve_modal_assembly()
        elif analysis_type == "contact":
            return self._solve_contact_analysis()
        else:
            print(f"Unknown analysis type: {analysis_type}")
            return False
            
    def _solve_static_assembly(self):
        """Solve static assembly analysis"""
        # Simplified static analysis
        n_nodes = len(self.global_nodes)
        displacement = np.random.random(n_nodes * 3) * 1e-6  # Simulated small displacements
        
        self.results['displacement'] = displacement
        self.results['max_displacement'] = np.max(np.abs(displacement))
        
        print(f"Static assembly analysis completed")
        print(f"Max displacement: {self.results['max_displacement']:.2e} m")
        return True
        
    def _solve_modal_assembly(self):
        """Solve modal assembly analysis"""
        # Simplified modal analysis
        n_modes = min(10, len(self.global_nodes))
        frequencies = np.random.random(n_modes) * 100 + 10  # 10-110 Hz
        
        self.results['natural_frequencies'] = frequencies
        
        print(f"Modal assembly analysis completed")
        print(f"First frequency: {frequencies[0]:.2f} Hz")
        return True
        
    def _solve_contact_analysis(self):
        """Solve contact analysis"""
        contact_forces = []
        
        for contact in self.contact_interfaces:
            # Simplified contact force calculation
            n_pairs = len(contact.contact_pairs)
            forces = np.random.random(n_pairs) * 1000  # Random forces up to 1000N
            contact_forces.extend(forces)
        
        self.results['contact_forces'] = contact_forces
        self.results['max_contact_force'] = np.max(contact_forces) if contact_forces else 0
        
        print(f"Contact analysis completed")
        print(f"Max contact force: {self.results['max_contact_force']:.2f} N")
        return True
        
    def calculate_assembly_properties(self):
        """Calculate overall assembly properties"""
        total_volume = 0
        total_mass = 0
        center_of_mass = np.zeros(3)
        
        for obj in self.objects.values():
            # Simplified property calculation
            if obj.shape_type == "cube":
                size = obj.geometry_params.get('size', 0.05)
                volume = size ** 3
            elif obj.shape_type == "cylinder":
                radius = obj.geometry_params.get('radius', 0.025)
                height = obj.geometry_params.get('height', 0.1)
                volume = np.pi * radius**2 * height
            else:
                volume = 0.001  # Default volume
            
            # Assume steel density if not specified
            density = 7850  # kg/m³
            mass = volume * density
            
            total_volume += volume
            total_mass += mass
            center_of_mass += obj.position * mass
        
        if total_mass > 0:
            center_of_mass /= total_mass
        
        self.results['total_volume'] = total_volume
        self.results['total_mass'] = total_mass
        self.results['center_of_mass'] = center_of_mass
        
        return {
            'volume': total_volume,
            'mass': total_mass,
            'center_of_mass': center_of_mass
        }
        
    def export_results(self, filename):
        """Export analysis results"""
        export_data = {
            'assembly_info': {
                'n_objects': len(self.objects),
                'n_contacts': len(self.contact_interfaces),
                'n_nodes': len(self.global_nodes),
                'n_elements': len(self.global_elements)
            },
            'results': self.results,
            'ubp_params': self.ubp_params
        }
        
        with open(filename, 'w') as f:
            json.dump(export_data, f, indent=2, default=str)
        
        print(f"Results exported to {filename}")


# Test and demonstration
if __name__ == "__main__":
    print("RGDL V3.2 Multi-Object Assembly Analysis System (Corrected)")
    print("=" * 70)
    
    # Create assembly analyzer
    assembly = AssemblyAnalyzer()
    
    # Add objects using corrected interface
    base_plate = AssemblyObject("base_plate", "cube", {"size": 0.1}, "steel", (0, 0, 0))
    assembly.add_object(base_plate)
    
    mounting_bracket = AssemblyObject("mounting_bracket", "cube", {"size": 0.05}, "aluminum", (0.05, 0, 0.05))
    assembly.add_object(mounting_bracket)
    
    bolt = AssemblyObject("bolt", "cylinder", {"radius": 0.006, "height": 0.08}, "steel", (0.075, 0, 0.02))
    assembly.add_object(bolt)
    
    # Detect contacts
    assembly.detect_contacts()
    
    # Add manual contact interface
    assembly.add_contact_interface("base_plate", "mounting_bracket", "bonded")
    
    # Solve different types of analysis
    assembly.solve_assembly_analysis("static")
    assembly.solve_assembly_analysis("modal")
    assembly.solve_assembly_analysis("contact")
    
    # Calculate assembly properties
    properties = assembly.calculate_assembly_properties()
    print(f"\nAssembly Properties:")
    print(f"Total volume: {properties['volume']:.6f} m³")
    print(f"Total mass: {properties['mass']:.3f} kg")
    print(f"Center of mass: {properties['center_of_mass']}")
    
    # Export results
    assembly.export_results("assembly_results.json")
    
    print("\nAssembly Analyzer ready for integration with RGDL V3.2")

