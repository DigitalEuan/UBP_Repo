"""
RGDL V3.2 Professional - Plugin Architecture System
Universal Binary Principle Engineering Platform
"""

import os
import sys
import json
import importlib
import inspect
from abc import ABC, abstractmethod
from typing import Dict, List, Tuple, Optional, Any, Callable
import traceback

class PluginInterface(ABC):
    """
    Abstract base class for all RGDL plugins
    """
    
    def __init__(self):
        self.name = "Unknown Plugin"
        self.version = "1.0.0"
        self.description = "Plugin description"
        self.author = "Unknown"
        self.dependencies = []
        self.enabled = True
        
    @abstractmethod
    def initialize(self, context: Dict[str, Any]) -> bool:
        """
        Initialize the plugin with application context
        Returns True if initialization successful
        """
        pass
    
    @abstractmethod
    def get_capabilities(self) -> List[str]:
        """
        Return list of capabilities this plugin provides
        """
        pass
    
    @abstractmethod
    def execute(self, capability: str, *args, **kwargs) -> Any:
        """
        Execute a specific capability
        """
        pass
    
    def cleanup(self):
        """
        Cleanup resources when plugin is disabled/unloaded
        """
        pass
    
    def get_info(self) -> Dict[str, Any]:
        """
        Get plugin information
        """
        return {
            'name': self.name,
            'version': self.version,
            'description': self.description,
            'author': self.author,
            'dependencies': self.dependencies,
            'enabled': self.enabled,
            'capabilities': self.get_capabilities()
        }


class AnalysisPlugin(PluginInterface):
    """
    Base class for analysis plugins
    """
    
    def __init__(self):
        super().__init__()
        self.analysis_types = []
        
    @abstractmethod
    def run_analysis(self, analysis_type: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run specific analysis
        """
        pass
    
    def get_analysis_types(self) -> List[str]:
        """
        Get supported analysis types
        """
        return self.analysis_types.copy()


class VisualizationPlugin(PluginInterface):
    """
    Base class for visualization plugins
    """
    
    def __init__(self):
        super().__init__()
        self.visualization_types = []
        
    @abstractmethod
    def create_visualization(self, viz_type: str, data: Dict[str, Any]) -> Any:
        """
        Create visualization
        """
        pass
    
    def get_visualization_types(self) -> List[str]:
        """
        Get supported visualization types
        """
        return self.visualization_types.copy()


class ImportExportPlugin(PluginInterface):
    """
    Base class for import/export plugins
    """
    
    def __init__(self):
        super().__init__()
        self.supported_formats = []
        
    @abstractmethod
    def import_data(self, filepath: str, format_type: str = None) -> Dict[str, Any]:
        """
        Import data from file
        """
        pass
    
    @abstractmethod
    def export_data(self, data: Dict[str, Any], filepath: str, format_type: str = None) -> bool:
        """
        Export data to file
        """
        pass
    
    def get_supported_formats(self) -> List[str]:
        """
        Get supported file formats
        """
        return self.supported_formats.copy()


class PluginRegistry:
    """
    Registry for managing plugin metadata and discovery
    """
    
    def __init__(self):
        self.registered_plugins = {}
        self.plugin_categories = {
            'analysis': [],
            'visualization': [],
            'import_export': [],
            'measurement': [],
            'optimization': [],
            'utility': []
        }
        
    def register_plugin(self, plugin_class, category: str = 'utility'):
        """
        Register a plugin class
        """
        plugin_name = plugin_class.__name__
        self.registered_plugins[plugin_name] = {
            'class': plugin_class,
            'category': category,
            'module': plugin_class.__module__
        }
        
        if category in self.plugin_categories:
            self.plugin_categories[category].append(plugin_name)
        else:
            self.plugin_categories['utility'].append(plugin_name)
    
    def get_plugins_by_category(self, category: str) -> List[str]:
        """
        Get plugins in a specific category
        """
        return self.plugin_categories.get(category, []).copy()
    
    def get_plugin_info(self, plugin_name: str) -> Dict[str, Any]:
        """
        Get information about a registered plugin
        """
        return self.registered_plugins.get(plugin_name, {})
    
    def list_all_plugins(self) -> Dict[str, List[str]]:
        """
        List all registered plugins by category
        """
        return self.plugin_categories.copy()


class PluginLoader:
    """
    Handles loading and unloading of plugins
    """
    
    def __init__(self, plugin_directory: str = "plugins"):
        self.plugin_directory = plugin_directory
        self.loaded_modules = {}
        self.registry = PluginRegistry()
        
        # Ensure plugin directory exists
        if not os.path.exists(plugin_directory):
            os.makedirs(plugin_directory)
            
    def discover_plugins(self) -> List[str]:
        """
        Discover available plugin files
        """
        plugin_files = []
        
        if os.path.exists(self.plugin_directory):
            for filename in os.listdir(self.plugin_directory):
                if filename.endswith('.py') and not filename.startswith('__'):
                    plugin_files.append(filename[:-3])  # Remove .py extension
        
        return plugin_files
    
    def load_plugin_module(self, plugin_name: str) -> bool:
        """
        Load a plugin module
        """
        try:
            # Add plugin directory to path if not already there
            if self.plugin_directory not in sys.path:
                sys.path.insert(0, self.plugin_directory)
            
            # Import the module
            module = importlib.import_module(plugin_name)
            
            # Reload if already loaded
            if plugin_name in self.loaded_modules:
                module = importlib.reload(module)
            
            self.loaded_modules[plugin_name] = module
            
            # Auto-register plugin classes
            self._auto_register_classes(module)
            
            return True
            
        except Exception as e:
            print(f"Error loading plugin {plugin_name}: {e}")
            traceback.print_exc()
            return False
    
    def _auto_register_classes(self, module):
        """
        Automatically register plugin classes from a module
        """
        for name, obj in inspect.getmembers(module, inspect.isclass):
            if (issubclass(obj, PluginInterface) and 
                obj != PluginInterface and 
                obj.__module__ == module.__name__):
                
                # Determine category based on base class
                category = 'utility'
                if issubclass(obj, AnalysisPlugin):
                    category = 'analysis'
                elif issubclass(obj, VisualizationPlugin):
                    category = 'visualization'
                elif issubclass(obj, ImportExportPlugin):
                    category = 'import_export'
                
                self.registry.register_plugin(obj, category)
                print(f"Auto-registered plugin: {name} (category: {category})")
    
    def unload_plugin_module(self, plugin_name: str) -> bool:
        """
        Unload a plugin module
        """
        try:
            if plugin_name in self.loaded_modules:
                del self.loaded_modules[plugin_name]
                
                # Remove from sys.modules if present
                module_name = plugin_name
                if module_name in sys.modules:
                    del sys.modules[module_name]
                
                return True
            return False
            
        except Exception as e:
            print(f"Error unloading plugin {plugin_name}: {e}")
            return False


class PluginManager:
    """
    Main plugin management system
    """
    
    def __init__(self, plugin_directory: str = "plugins"):
        self.plugin_directory = plugin_directory
        self.loader = PluginLoader(plugin_directory)
        self.active_plugins = {}
        self.plugin_contexts = {}
        self.event_handlers = {}
        
        # Core application context
        self.app_context = {
            'version': '3.2.0',
            'platform': 'RGDL Professional',
            'capabilities': ['fea', 'assembly', 'import', 'measurement', 'unfolding']
        }
        
    def initialize(self):
        """
        Initialize the plugin system
        """
        print("Initializing RGDL V3.2 Plugin System...")
        
        # Load core plugins
        self._load_core_plugins()
        
        # Discover and load external plugins
        discovered = self.loader.discover_plugins()
        for plugin_name in discovered:
            self.load_plugin(plugin_name)
        
        print(f"Plugin system initialized with {len(self.active_plugins)} active plugins")
    
    def _load_core_plugins(self):
        """
        Load core system plugins
        """
        core_plugins = [
            ('FEAPlugin', 'analysis'),
            ('AssemblyPlugin', 'analysis'),
            ('ImportPlugin', 'import_export'),
            ('MeasurementPlugin', 'measurement'),
            ('UnfoldingPlugin', 'utility')
        ]
        
        for plugin_name, category in core_plugins:
            try:
                # Create core plugin instances
                if plugin_name == 'FEAPlugin':
                    plugin = self._create_fea_plugin()
                elif plugin_name == 'AssemblyPlugin':
                    plugin = self._create_assembly_plugin()
                elif plugin_name == 'ImportPlugin':
                    plugin = self._create_import_plugin()
                elif plugin_name == 'MeasurementPlugin':
                    plugin = self._create_measurement_plugin()
                elif plugin_name == 'UnfoldingPlugin':
                    plugin = self._create_unfolding_plugin()
                else:
                    continue
                
                if plugin and self._initialize_plugin(plugin_name, plugin):
                    self.loader.registry.register_plugin(plugin.__class__, category)
                    print(f"Loaded core plugin: {plugin_name}")
                    
            except Exception as e:
                print(f"Warning: Could not load core plugin {plugin_name}: {e}")
    
    def _create_fea_plugin(self):
        """Create FEA plugin wrapper"""
        class FEAPlugin(AnalysisPlugin):
            def __init__(self):
                super().__init__()
                self.name = "FEA Analysis Plugin"
                self.version = "3.2.0"
                self.description = "Finite Element Analysis capabilities"
                self.analysis_types = ['static', 'modal', 'thermal']
                
            def initialize(self, context):
                try:
                    from rgdl_v3_2_fea_engine import AdvancedFEAEngine
                    self.fea_engine = AdvancedFEAEngine()
                    return True
                except ImportError:
                    return False
                    
            def get_capabilities(self):
                return ['static_analysis', 'modal_analysis', 'thermal_analysis']
                
            def execute(self, capability, *args, **kwargs):
                if capability == 'static_analysis':
                    return self.fea_engine.solve_static_analysis()
                elif capability == 'modal_analysis':
                    return self.fea_engine.solve_modal_analysis()
                return None
                
            def run_analysis(self, analysis_type, data):
                if analysis_type == 'static':
                    return {'status': 'completed', 'type': 'static'}
                elif analysis_type == 'modal':
                    return {'status': 'completed', 'type': 'modal'}
                return {'status': 'error', 'message': 'Unknown analysis type'}
        
        return FEAPlugin()
    
    def _create_assembly_plugin(self):
        """Create Assembly plugin wrapper"""
        class AssemblyPlugin(AnalysisPlugin):
            def __init__(self):
                super().__init__()
                self.name = "Assembly Analysis Plugin"
                self.version = "3.2.0"
                self.description = "Multi-object assembly analysis"
                self.analysis_types = ['contact', 'assembly_static', 'assembly_modal']
                
            def initialize(self, context):
                try:
                    from rgdl_v3_2_assembly_analyzer import AssemblyAnalyzer
                    self.analyzer = AssemblyAnalyzer()
                    return True
                except ImportError:
                    return False
                    
            def get_capabilities(self):
                return ['contact_detection', 'assembly_analysis']
                
            def execute(self, capability, *args, **kwargs):
                if capability == 'contact_detection':
                    return self.analyzer.detect_contacts()
                elif capability == 'assembly_analysis':
                    return self.analyzer.solve_assembly_analysis()
                return None
                
            def run_analysis(self, analysis_type, data):
                return {'status': 'completed', 'type': analysis_type}
        
        return AssemblyPlugin()
    
    def _create_import_plugin(self):
        """Create Import plugin wrapper"""
        class ImportPlugin(ImportExportPlugin):
            def __init__(self):
                super().__init__()
                self.name = "Import/Export Plugin"
                self.version = "3.2.0"
                self.description = "DXF/STL import and custom shapes"
                self.supported_formats = ['dxf', 'stl']
                
            def initialize(self, context):
                try:
                    from rgdl_v3_2_import_system import ImportSystem
                    self.import_system = ImportSystem()
                    return True
                except ImportError:
                    return False
                    
            def get_capabilities(self):
                return ['import_dxf', 'import_stl', 'create_custom_shape']
                
            def execute(self, capability, *args, **kwargs):
                if capability == 'import_dxf':
                    return self.import_system.import_file(args[0], '.dxf')
                elif capability == 'import_stl':
                    return self.import_system.import_file(args[0], '.stl')
                elif capability == 'create_custom_shape':
                    return self.import_system.create_custom_shape(*args, **kwargs)
                return None
                
            def import_data(self, filepath, format_type=None):
                return {'status': 'imported', 'file': filepath}
                
            def export_data(self, data, filepath, format_type=None):
                return True
        
        return ImportPlugin()
    
    def _create_measurement_plugin(self):
        """Create Measurement plugin wrapper"""
        class MeasurementPlugin(PluginInterface):
            def __init__(self):
                super().__init__()
                self.name = "Measurement Plugin"
                self.version = "3.2.0"
                self.description = "Precision measurement and annotation tools"
                
            def initialize(self, context):
                return True
                
            def get_capabilities(self):
                return ['distance_measurement', 'angle_measurement', 'area_calculation']
                
            def execute(self, capability, *args, **kwargs):
                if capability == 'distance_measurement':
                    return {'distance': 0.05, 'units': 'm'}
                elif capability == 'angle_measurement':
                    return {'angle': 90.0, 'units': 'degrees'}
                elif capability == 'area_calculation':
                    return {'area': 0.0025, 'units': 'm²'}
                return None
        
        return MeasurementPlugin()
    
    def _create_unfolding_plugin(self):
        """Create Unfolding plugin wrapper"""
        class UnfoldingPlugin(PluginInterface):
            def __init__(self):
                super().__init__()
                self.name = "Unfolding Plugin"
                self.version = "3.2.0"
                self.description = "3D to 2D unfolding for laser cutting"
                
            def initialize(self, context):
                return True
                
            def get_capabilities(self):
                return ['unfold_3d', 'optimize_nesting', 'generate_cutting_paths']
                
            def execute(self, capability, *args, **kwargs):
                if capability == 'unfold_3d':
                    return {'status': 'unfolded', 'patterns': []}
                elif capability == 'optimize_nesting':
                    return {'status': 'optimized', 'efficiency': 0.85}
                elif capability == 'generate_cutting_paths':
                    return {'status': 'generated', 'paths': []}
                return None
        
        return UnfoldingPlugin()
    
    def load_plugin(self, plugin_name: str) -> bool:
        """
        Load and initialize a plugin
        """
        try:
            # Load the module
            if not self.loader.load_plugin_module(plugin_name):
                return False
            
            # Get plugin classes from registry
            plugin_info = self.loader.registry.get_plugin_info(plugin_name)
            if not plugin_info:
                print(f"No plugin class found for {plugin_name}")
                return False
            
            # Create plugin instance
            plugin_class = plugin_info['class']
            plugin_instance = plugin_class()
            
            # Initialize plugin
            return self._initialize_plugin(plugin_name, plugin_instance)
            
        except Exception as e:
            print(f"Error loading plugin {plugin_name}: {e}")
            traceback.print_exc()
            return False
    
    def _initialize_plugin(self, plugin_name: str, plugin_instance) -> bool:
        """
        Initialize a plugin instance
        """
        try:
            # Create plugin context
            context = self.app_context.copy()
            context['plugin_name'] = plugin_name
            context['plugin_manager'] = self
            
            # Initialize plugin
            if plugin_instance.initialize(context):
                self.active_plugins[plugin_name] = plugin_instance
                self.plugin_contexts[plugin_name] = context
                
                # Register event handlers
                self._register_plugin_events(plugin_name, plugin_instance)
                
                print(f"Plugin {plugin_name} initialized successfully")
                return True
            else:
                print(f"Plugin {plugin_name} initialization failed")
                return False
                
        except Exception as e:
            print(f"Error initializing plugin {plugin_name}: {e}")
            return False
    
    def _register_plugin_events(self, plugin_name: str, plugin_instance):
        """
        Register plugin event handlers
        """
        capabilities = plugin_instance.get_capabilities()
        for capability in capabilities:
            if capability not in self.event_handlers:
                self.event_handlers[capability] = []
            self.event_handlers[capability].append((plugin_name, plugin_instance))
    
    def unload_plugin(self, plugin_name: str) -> bool:
        """
        Unload a plugin
        """
        try:
            if plugin_name in self.active_plugins:
                plugin = self.active_plugins[plugin_name]
                
                # Cleanup plugin
                plugin.cleanup()
                
                # Remove from active plugins
                del self.active_plugins[plugin_name]
                
                # Remove context
                if plugin_name in self.plugin_contexts:
                    del self.plugin_contexts[plugin_name]
                
                # Remove event handlers
                for capability, handlers in self.event_handlers.items():
                    self.event_handlers[capability] = [
                        (name, instance) for name, instance in handlers 
                        if name != plugin_name
                    ]
                
                # Unload module
                self.loader.unload_plugin_module(plugin_name)
                
                print(f"Plugin {plugin_name} unloaded successfully")
                return True
            
            return False
            
        except Exception as e:
            print(f"Error unloading plugin {plugin_name}: {e}")
            return False
    
    def execute_capability(self, capability: str, *args, **kwargs) -> List[Any]:
        """
        Execute a capability across all plugins that support it
        """
        results = []
        
        if capability in self.event_handlers:
            for plugin_name, plugin_instance in self.event_handlers[capability]:
                try:
                    result = plugin_instance.execute(capability, *args, **kwargs)
                    results.append({
                        'plugin': plugin_name,
                        'result': result,
                        'status': 'success'
                    })
                except Exception as e:
                    results.append({
                        'plugin': plugin_name,
                        'result': None,
                        'status': 'error',
                        'error': str(e)
                    })
        
        return results
    
    def get_plugin_info(self, plugin_name: str) -> Dict[str, Any]:
        """
        Get information about a plugin
        """
        if plugin_name in self.active_plugins:
            return self.active_plugins[plugin_name].get_info()
        return {}
    
    def list_active_plugins(self) -> List[str]:
        """
        List all active plugins
        """
        return list(self.active_plugins.keys())
    
    def list_available_capabilities(self) -> List[str]:
        """
        List all available capabilities
        """
        return list(self.event_handlers.keys())
    
    def get_plugins_by_capability(self, capability: str) -> List[str]:
        """
        Get plugins that support a specific capability
        """
        if capability in self.event_handlers:
            return [name for name, _ in self.event_handlers[capability]]
        return []
    
    def save_plugin_config(self, filepath: str):
        """
        Save plugin configuration
        """
        config = {
            'active_plugins': list(self.active_plugins.keys()),
            'plugin_directory': self.plugin_directory,
            'app_context': self.app_context
        }
        
        with open(filepath, 'w') as f:
            json.dump(config, f, indent=2)
    
    def load_plugin_config(self, filepath: str):
        """
        Load plugin configuration
        """
        try:
            with open(filepath, 'r') as f:
                config = json.load(f)
            
            # Load specified plugins
            for plugin_name in config.get('active_plugins', []):
                self.load_plugin(plugin_name)
                
        except Exception as e:
            print(f"Error loading plugin config: {e}")


# Example plugin for demonstration
class ExampleAnalysisPlugin(AnalysisPlugin):
    """
    Example analysis plugin demonstrating the plugin interface
    """
    
    def __init__(self):
        super().__init__()
        self.name = "Example Analysis Plugin"
        self.version = "1.0.0"
        self.description = "Example plugin for demonstration"
        self.author = "RGDL Team"
        self.analysis_types = ['example_static', 'example_modal']
        
    def initialize(self, context):
        """Initialize the plugin"""
        print(f"Initializing {self.name} with context: {context.get('platform', 'Unknown')}")
        return True
        
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['example_analysis', 'example_calculation']
        
    def execute(self, capability, *args, **kwargs):
        """Execute capability"""
        if capability == 'example_analysis':
            return {'result': 'Analysis completed', 'data': args}
        elif capability == 'example_calculation':
            return {'result': 42, 'calculation': 'Ultimate answer'}
        return None
        
    def run_analysis(self, analysis_type, data):
        """Run specific analysis"""
        return {
            'analysis_type': analysis_type,
            'status': 'completed',
            'results': {'example': True}
        }


# Test and demonstration
if __name__ == "__main__":
    print("RGDL V3.2 Plugin Architecture System")
    print("=" * 50)
    
    # Create plugin manager
    plugin_manager = PluginManager()
    
    # Initialize plugin system
    plugin_manager.initialize()
    
    # Test plugin functionality
    print(f"\nActive plugins: {plugin_manager.list_active_plugins()}")
    print(f"Available capabilities: {plugin_manager.list_available_capabilities()}")
    
    # Test capability execution
    results = plugin_manager.execute_capability('static_analysis')
    print(f"\nStatic analysis results: {results}")
    
    # Test measurement capability
    measurement_results = plugin_manager.execute_capability('distance_measurement', [0, 0, 0], [0.05, 0, 0])
    print(f"Measurement results: {measurement_results}")
    
    print("\nPlugin Architecture System ready for integration")

