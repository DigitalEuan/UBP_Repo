"""
RGDL V3.1 Professional - Comprehensive Measurements System
=========================================================

This plugin provides comprehensive measurement capabilities for engineering analysis.
Features:
- Distance measurements between points, edges, and surfaces
- Angle measurements between lines, planes, and surfaces
- Area and volume calculations
- Dimensional annotations with tolerances
- Real-time measurement display
- Export to technical drawings
- Integration with UBP mathematical framework

Author: RGDL V3.1 Professional
Date: 2025-06-24
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Circle, Arc
from mpl_toolkits.mplot3d import proj3d
import json
import os
from scipy.spatial.distance import cdist
from scipy.optimize import minimize_scalar

class MeasurementSystem:
    """
    Comprehensive measurement system for RGDL V3.1 Professional
    """
    
    def __init__(self):
        self.measurements = []
        self.annotations = []
        self.measurement_id_counter = 0
        self.precision = 6  # decimal places
        self.units = "mm"  # default units
        self.tolerance_class = "IT7"  # ISO tolerance class
        self.measurement_style = {
            'line_color': 'blue',
            'text_color': 'black',
            'arrow_color': 'red',
            'dimension_line_style': '--',
            'font_size': 10,
            'arrow_size': 0.02
        }
        
    def set_units(self, units):
        """Set measurement units (mm, cm, m, in, ft)"""
        valid_units = ['mm', 'cm', 'm', 'in', 'ft']
        if units in valid_units:
            self.units = units
            print(f"Units set to {units}")
        else:
            print(f"Invalid units. Valid options: {valid_units}")
            
    def set_precision(self, decimal_places):
        """Set measurement precision"""
        self.precision = max(0, min(10, decimal_places))
        print(f"Precision set to {self.precision} decimal places")
        
    def measure_distance_points(self, point1, point2, label=None):
        """
        Measure distance between two points
        
        Args:
            point1: [x, y, z] coordinates of first point
            point2: [x, y, z] coordinates of second point
            label: Optional label for the measurement
            
        Returns:
            Measurement dictionary
        """
        p1 = np.array(point1)
        p2 = np.array(point2)
        
        distance = np.linalg.norm(p2 - p1)
        
        measurement = {
            'id': self._get_next_id(),
            'type': 'distance_points',
            'point1': p1.tolist(),
            'point2': p2.tolist(),
            'distance': distance,
            'units': self.units,
            'label': label or f"Distance_{self.measurement_id_counter}",
            'precision': self.precision,
            'midpoint': ((p1 + p2) / 2).tolist(),
            'direction_vector': (p2 - p1).tolist()
        }
        
        self.measurements.append(measurement)
        print(f"Distance measurement: {distance:.{self.precision}f} {self.units}")
        
        return measurement
        
    def measure_distance_point_to_line(self, point, line_point1, line_point2, label=None):
        """
        Measure perpendicular distance from point to line
        """
        p = np.array(point)
        l1 = np.array(line_point1)
        l2 = np.array(line_point2)
        
        # Line direction vector
        line_vec = l2 - l1
        line_length = np.linalg.norm(line_vec)
        
        if line_length == 0:
            distance = np.linalg.norm(p - l1)
            closest_point = l1
        else:
            line_unit = line_vec / line_length
            
            # Project point onto line
            t = np.dot(p - l1, line_unit)
            closest_point = l1 + t * line_unit
            
            # Calculate perpendicular distance
            distance = np.linalg.norm(p - closest_point)
            
        measurement = {
            'id': self._get_next_id(),
            'type': 'distance_point_to_line',
            'point': p.tolist(),
            'line_point1': l1.tolist(),
            'line_point2': l2.tolist(),
            'distance': distance,
            'closest_point_on_line': closest_point.tolist(),
            'units': self.units,
            'label': label or f"Point_to_Line_{self.measurement_id_counter}",
            'precision': self.precision
        }
        
        self.measurements.append(measurement)
        print(f"Point to line distance: {distance:.{self.precision}f} {self.units}")
        
        return measurement
        
    def measure_distance_point_to_plane(self, point, plane_point, plane_normal, label=None):
        """
        Measure perpendicular distance from point to plane
        """
        p = np.array(point)
        plane_pt = np.array(plane_point)
        normal = np.array(plane_normal)
        
        # Normalize plane normal
        normal_unit = normal / np.linalg.norm(normal)
        
        # Calculate distance using plane equation
        distance = abs(np.dot(p - plane_pt, normal_unit))
        
        # Find closest point on plane
        closest_point = p - distance * normal_unit * np.sign(np.dot(p - plane_pt, normal_unit))
        
        measurement = {
            'id': self._get_next_id(),
            'type': 'distance_point_to_plane',
            'point': p.tolist(),
            'plane_point': plane_pt.tolist(),
            'plane_normal': normal.tolist(),
            'distance': distance,
            'closest_point_on_plane': closest_point.tolist(),
            'units': self.units,
            'label': label or f"Point_to_Plane_{self.measurement_id_counter}",
            'precision': self.precision
        }
        
        self.measurements.append(measurement)
        print(f"Point to plane distance: {distance:.{self.precision}f} {self.units}")
        
        return measurement
        
    def measure_angle_three_points(self, vertex, point1, point2, label=None):
        """
        Measure angle formed by three points (vertex is the angle vertex)
        """
        v = np.array(vertex)
        p1 = np.array(point1)
        p2 = np.array(point2)
        
        # Vectors from vertex to other points
        vec1 = p1 - v
        vec2 = p2 - v
        
        # Calculate angle using dot product
        cos_angle = np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))
        cos_angle = np.clip(cos_angle, -1.0, 1.0)  # Handle numerical errors
        
        angle_rad = np.arccos(cos_angle)
        angle_deg = np.degrees(angle_rad)
        
        measurement = {
            'id': self._get_next_id(),
            'type': 'angle_three_points',
            'vertex': v.tolist(),
            'point1': p1.tolist(),
            'point2': p2.tolist(),
            'angle_radians': angle_rad,
            'angle_degrees': angle_deg,
            'label': label or f"Angle_{self.measurement_id_counter}",
            'precision': self.precision,
            'vector1': vec1.tolist(),
            'vector2': vec2.tolist()
        }
        
        self.measurements.append(measurement)
        print(f"Angle measurement: {angle_deg:.{self.precision}f}°")
        
        return measurement
        
    def measure_angle_between_lines(self, line1_point1, line1_point2, line2_point1, line2_point2, label=None):
        """
        Measure angle between two lines
        """
        # Line direction vectors
        line1_vec = np.array(line1_point2) - np.array(line1_point1)
        line2_vec = np.array(line2_point2) - np.array(line2_point1)
        
        # Normalize vectors
        line1_unit = line1_vec / np.linalg.norm(line1_vec)
        line2_unit = line2_vec / np.linalg.norm(line2_vec)
        
        # Calculate angle
        cos_angle = np.dot(line1_unit, line2_unit)
        cos_angle = np.clip(cos_angle, -1.0, 1.0)
        
        angle_rad = np.arccos(abs(cos_angle))  # Always acute angle
        angle_deg = np.degrees(angle_rad)
        
        measurement = {
            'id': self._get_next_id(),
            'type': 'angle_between_lines',
            'line1_point1': np.array(line1_point1).tolist(),
            'line1_point2': np.array(line1_point2).tolist(),
            'line2_point1': np.array(line2_point1).tolist(),
            'line2_point2': np.array(line2_point2).tolist(),
            'angle_radians': angle_rad,
            'angle_degrees': angle_deg,
            'label': label or f"Line_Angle_{self.measurement_id_counter}",
            'precision': self.precision
        }
        
        self.measurements.append(measurement)
        print(f"Angle between lines: {angle_deg:.{self.precision}f}°")
        
        return measurement
        
    def measure_angle_between_planes(self, plane1_normal, plane2_normal, label=None):
        """
        Measure angle between two planes using their normal vectors
        """
        n1 = np.array(plane1_normal)
        n2 = np.array(plane2_normal)
        
        # Normalize normals
        n1_unit = n1 / np.linalg.norm(n1)
        n2_unit = n2 / np.linalg.norm(n2)
        
        # Calculate angle
        cos_angle = np.dot(n1_unit, n2_unit)
        cos_angle = np.clip(cos_angle, -1.0, 1.0)
        
        angle_rad = np.arccos(abs(cos_angle))  # Always acute angle
        angle_deg = np.degrees(angle_rad)
        
        measurement = {
            'id': self._get_next_id(),
            'type': 'angle_between_planes',
            'plane1_normal': n1.tolist(),
            'plane2_normal': n2.tolist(),
            'angle_radians': angle_rad,
            'angle_degrees': angle_deg,
            'label': label or f"Plane_Angle_{self.measurement_id_counter}",
            'precision': self.precision
        }
        
        self.measurements.append(measurement)
        print(f"Angle between planes: {angle_deg:.{self.precision}f}°")
        
        return measurement
        
    def measure_area_triangle(self, point1, point2, point3, label=None):
        """
        Measure area of triangle defined by three points
        """
        p1 = np.array(point1)
        p2 = np.array(point2)
        p3 = np.array(point3)
        
        # Calculate area using cross product
        vec1 = p2 - p1
        vec2 = p3 - p1
        
        cross_product = np.cross(vec1, vec2)
        area = 0.5 * np.linalg.norm(cross_product)
        
        # Calculate centroid
        centroid = (p1 + p2 + p3) / 3
        
        measurement = {
            'id': self._get_next_id(),
            'type': 'area_triangle',
            'point1': p1.tolist(),
            'point2': p2.tolist(),
            'point3': p3.tolist(),
            'area': area,
            'units': f"{self.units}²",
            'centroid': centroid.tolist(),
            'label': label or f"Triangle_Area_{self.measurement_id_counter}",
            'precision': self.precision
        }
        
        self.measurements.append(measurement)
        print(f"Triangle area: {area:.{self.precision}f} {self.units}²")
        
        return measurement
        
    def measure_area_polygon(self, vertices, label=None):
        """
        Measure area of polygon defined by vertices (must be coplanar)
        """
        vertices = np.array(vertices)
        n_vertices = len(vertices)
        
        if n_vertices < 3:
            raise ValueError("Polygon must have at least 3 vertices")
            
        # Calculate area using shoelace formula for 2D projection
        # First, find the best plane to project onto
        normal = self._calculate_polygon_normal(vertices)
        
        # Project vertices onto the plane
        projected_vertices = self._project_to_plane(vertices, normal)
        
        # Calculate area using shoelace formula
        area = 0.0
        for i in range(n_vertices):
            j = (i + 1) % n_vertices
            area += projected_vertices[i][0] * projected_vertices[j][1]
            area -= projected_vertices[j][0] * projected_vertices[i][1]
        area = abs(area) / 2.0
        
        # Calculate centroid
        centroid = np.mean(vertices, axis=0)
        
        measurement = {
            'id': self._get_next_id(),
            'type': 'area_polygon',
            'vertices': vertices.tolist(),
            'area': area,
            'units': f"{self.units}²",
            'centroid': centroid.tolist(),
            'normal': normal.tolist(),
            'label': label or f"Polygon_Area_{self.measurement_id_counter}",
            'precision': self.precision
        }
        
        self.measurements.append(measurement)
        print(f"Polygon area: {area:.{self.precision}f} {self.units}²")
        
        return measurement
        
    def measure_volume_tetrahedron(self, point1, point2, point3, point4, label=None):
        """
        Measure volume of tetrahedron defined by four points
        """
        p1 = np.array(point1)
        p2 = np.array(point2)
        p3 = np.array(point3)
        p4 = np.array(point4)
        
        # Calculate volume using scalar triple product
        vec1 = p2 - p1
        vec2 = p3 - p1
        vec3 = p4 - p1
        
        volume = abs(np.dot(vec1, np.cross(vec2, vec3))) / 6.0
        
        # Calculate centroid
        centroid = (p1 + p2 + p3 + p4) / 4
        
        measurement = {
            'id': self._get_next_id(),
            'type': 'volume_tetrahedron',
            'point1': p1.tolist(),
            'point2': p2.tolist(),
            'point3': p3.tolist(),
            'point4': p4.tolist(),
            'volume': volume,
            'units': f"{self.units}³",
            'centroid': centroid.tolist(),
            'label': label or f"Tetrahedron_Volume_{self.measurement_id_counter}",
            'precision': self.precision
        }
        
        self.measurements.append(measurement)
        print(f"Tetrahedron volume: {volume:.{self.precision}f} {self.units}³")
        
        return measurement
        
    def measure_volume_from_bitfield(self, bitfield, voxel_size=0.001, label=None):
        """
        Measure volume from RGDL bitfield
        """
        active_voxels = np.sum(bitfield)
        voxel_volume = voxel_size ** 3
        total_volume = active_voxels * voxel_volume
        
        # Convert to current units
        if self.units == 'mm':
            total_volume *= 1e9  # m³ to mm³
        elif self.units == 'cm':
            total_volume *= 1e6  # m³ to cm³
        elif self.units == 'in':
            total_volume *= 61023.7  # m³ to in³
        elif self.units == 'ft':
            total_volume *= 35.3147  # m³ to ft³
            
        # Calculate centroid
        indices = np.where(bitfield == 1)
        if len(indices[0]) > 0:
            centroid = [np.mean(indices[i]) * voxel_size for i in range(3)]
        else:
            centroid = [0, 0, 0]
            
        measurement = {
            'id': self._get_next_id(),
            'type': 'volume_bitfield',
            'active_voxels': int(active_voxels),
            'voxel_size': voxel_size,
            'volume': total_volume,
            'units': f"{self.units}³",
            'centroid': centroid,
            'bitfield_shape': bitfield.shape,
            'label': label or f"Bitfield_Volume_{self.measurement_id_counter}",
            'precision': self.precision
        }
        
        self.measurements.append(measurement)
        print(f"Bitfield volume: {total_volume:.{self.precision}f} {self.units}³")
        
        return measurement
        
    def create_dimensional_annotation(self, measurement_id, tolerance=None, note=None):
        """
        Create dimensional annotation with tolerances
        """
        measurement = self.get_measurement_by_id(measurement_id)
        if not measurement:
            print(f"Measurement with ID {measurement_id} not found")
            return None
            
        # Calculate tolerance if not provided
        if tolerance is None:
            tolerance = self._calculate_standard_tolerance(measurement)
            
        annotation = {
            'id': self._get_next_id(),
            'measurement_id': measurement_id,
            'tolerance': tolerance,
            'tolerance_class': self.tolerance_class,
            'note': note,
            'annotation_type': 'dimensional',
            'created_timestamp': self._get_timestamp()
        }
        
        self.annotations.append(annotation)
        print(f"Created dimensional annotation for measurement {measurement_id}")
        
        return annotation
        
    def create_geometric_tolerance_annotation(self, measurement_id, tolerance_type, tolerance_value, datum_references=None):
        """
        Create geometric tolerance annotation (GD&T)
        """
        valid_tolerance_types = [
            'straightness', 'flatness', 'circularity', 'cylindricity',
            'perpendicularity', 'angularity', 'parallelism',
            'position', 'concentricity', 'symmetry',
            'circular_runout', 'total_runout'
        ]
        
        if tolerance_type not in valid_tolerance_types:
            print(f"Invalid tolerance type. Valid types: {valid_tolerance_types}")
            return None
            
        measurement = self.get_measurement_by_id(measurement_id)
        if not measurement:
            print(f"Measurement with ID {measurement_id} not found")
            return None
            
        annotation = {
            'id': self._get_next_id(),
            'measurement_id': measurement_id,
            'tolerance_type': tolerance_type,
            'tolerance_value': tolerance_value,
            'datum_references': datum_references or [],
            'annotation_type': 'geometric_tolerance',
            'symbol': self._get_gdt_symbol(tolerance_type),
            'created_timestamp': self._get_timestamp()
        }
        
        self.annotations.append(annotation)
        print(f"Created {tolerance_type} tolerance annotation: ⌖{tolerance_value} {self.units}")
        
        return annotation
        
    def visualize_measurements_2d(self, measurements_to_show=None, save_path=None):
        """
        Create 2D visualization of measurements
        """
        if measurements_to_show is None:
            measurements_to_show = self.measurements
            
        fig, ax = plt.subplots(1, 1, figsize=(12, 8))
        
        for measurement in measurements_to_show:
            self._draw_measurement_2d(ax, measurement)
            
        ax.set_aspect('equal')
        ax.grid(True, alpha=0.3)
        ax.set_title('RGDL V3.1 Professional - Measurements')
        ax.set_xlabel(f'X ({self.units})')
        ax.set_ylabel(f'Y ({self.units})')
        
        # Add legend
        legend_elements = []
        for mtype in set(m['type'] for m in measurements_to_show):
            legend_elements.append(plt.Line2D([0], [0], color=self.measurement_style['line_color'], 
                                            label=mtype.replace('_', ' ').title()))
        ax.legend(handles=legend_elements)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            
        plt.show()
        return fig, ax
        
    def visualize_measurements_3d(self, measurements_to_show=None, save_path=None):
        """
        Create 3D visualization of measurements
        """
        if measurements_to_show is None:
            measurements_to_show = self.measurements
            
        fig = plt.figure(figsize=(12, 8))
        ax = fig.add_subplot(111, projection='3d')
        
        for measurement in measurements_to_show:
            self._draw_measurement_3d(ax, measurement)
            
        ax.set_title('RGDL V3.1 Professional - 3D Measurements')
        ax.set_xlabel(f'X ({self.units})')
        ax.set_ylabel(f'Y ({self.units})')
        ax.set_zlabel(f'Z ({self.units})')
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            
        plt.show()
        return fig, ax
        
    def export_measurement_report(self, filename, include_annotations=True):
        """
        Export comprehensive measurement report
        """
        report = {
            'title': 'RGDL V3.1 Professional Measurement Report',
            'timestamp': self._get_timestamp(),
            'units': self.units,
            'precision': self.precision,
            'tolerance_class': self.tolerance_class,
            'total_measurements': len(self.measurements),
            'measurements': self.measurements
        }
        
        if include_annotations:
            report['annotations'] = self.annotations
            report['total_annotations'] = len(self.annotations)
            
        # Calculate summary statistics
        distance_measurements = [m for m in self.measurements if 'distance' in m['type']]
        angle_measurements = [m for m in self.measurements if 'angle' in m['type']]
        area_measurements = [m for m in self.measurements if 'area' in m['type']]
        volume_measurements = [m for m in self.measurements if 'volume' in m['type']]
        
        report['summary'] = {
            'distance_measurements': len(distance_measurements),
            'angle_measurements': len(angle_measurements),
            'area_measurements': len(area_measurements),
            'volume_measurements': len(volume_measurements)
        }
        
        if distance_measurements:
            distances = [m['distance'] for m in distance_measurements]
            report['summary']['distance_stats'] = {
                'min': min(distances),
                'max': max(distances),
                'mean': np.mean(distances),
                'std': np.std(distances)
            }
            
        if angle_measurements:
            angles = [m['angle_degrees'] for m in angle_measurements]
            report['summary']['angle_stats'] = {
                'min': min(angles),
                'max': max(angles),
                'mean': np.mean(angles),
                'std': np.std(angles)
            }
            
        # Save report
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
            
        print(f"Measurement report exported to {filename}")
        return report
        
    def export_technical_drawing(self, filename, measurements_to_include=None):
        """
        Export technical drawing with dimensions
        """
        if measurements_to_include is None:
            measurements_to_include = self.measurements
            
        fig, ax = self.visualize_measurements_2d(measurements_to_include)
        
        # Add title block
        ax.text(0.02, 0.98, 'RGDL V3.1 Professional', transform=ax.transAxes, 
                fontsize=12, fontweight='bold', va='top')
        ax.text(0.02, 0.94, f'Units: {self.units}', transform=ax.transAxes, 
                fontsize=10, va='top')
        ax.text(0.02, 0.90, f'Tolerance Class: {self.tolerance_class}', transform=ax.transAxes, 
                fontsize=10, va='top')
        ax.text(0.02, 0.86, f'Date: {self._get_timestamp()}', transform=ax.transAxes, 
                fontsize=10, va='top')
                
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"Technical drawing exported to {filename}")
        
        return filename
        
    # Helper methods
    def _get_next_id(self):
        """Generate next measurement ID"""
        self.measurement_id_counter += 1
        return self.measurement_id_counter
        
    def _get_timestamp(self):
        """Get current timestamp"""
        from datetime import datetime
        return datetime.now().isoformat()
        
    def get_measurement_by_id(self, measurement_id):
        """Get measurement by ID"""
        for measurement in self.measurements:
            if measurement['id'] == measurement_id:
                return measurement
        return None
        
    def _calculate_polygon_normal(self, vertices):
        """Calculate normal vector for polygon"""
        n = len(vertices)
        normal = np.zeros(3)
        
        for i in range(n):
            v1 = vertices[i]
            v2 = vertices[(i + 1) % n]
            normal += np.cross(v1, v2)
            
        return normal / np.linalg.norm(normal)
        
    def _project_to_plane(self, vertices, normal):
        """Project 3D vertices to 2D plane"""
        # Create orthonormal basis for the plane
        normal = normal / np.linalg.norm(normal)
        
        # Find a vector not parallel to normal
        if abs(normal[0]) < 0.9:
            u = np.array([1, 0, 0])
        else:
            u = np.array([0, 1, 0])
            
        # Create orthonormal basis
        u = u - np.dot(u, normal) * normal
        u = u / np.linalg.norm(u)
        v = np.cross(normal, u)
        
        # Project vertices
        projected = []
        for vertex in vertices:
            x = np.dot(vertex, u)
            y = np.dot(vertex, v)
            projected.append([x, y])
            
        return np.array(projected)
        
    def _calculate_standard_tolerance(self, measurement):
        """Calculate standard tolerance based on measurement type and size"""
        if measurement['type'].startswith('distance'):
            value = measurement['distance']
        elif measurement['type'].startswith('angle'):
            return {'plus': 0.5, 'minus': 0.5, 'units': 'degrees'}  # ±0.5°
        else:
            return {'plus': 0.1, 'minus': 0.1, 'units': self.units}
            
        # ISO 2768 general tolerances for linear dimensions
        if value <= 0.5:
            tolerance = 0.1
        elif value <= 3:
            tolerance = 0.1
        elif value <= 6:
            tolerance = 0.1
        elif value <= 30:
            tolerance = 0.2
        elif value <= 120:
            tolerance = 0.3
        elif value <= 400:
            tolerance = 0.5
        else:
            tolerance = 0.8
            
        return {'plus': tolerance, 'minus': tolerance, 'units': self.units}
        
    def _get_gdt_symbol(self, tolerance_type):
        """Get GD&T symbol for tolerance type"""
        symbols = {
            'straightness': '⏤',
            'flatness': '⏥',
            'circularity': '○',
            'cylindricity': '⌭',
            'perpendicularity': '⊥',
            'angularity': '∠',
            'parallelism': '∥',
            'position': '⌖',
            'concentricity': '◎',
            'symmetry': '⌯',
            'circular_runout': '↗',
            'total_runout': '↗↗'
        }
        return symbols.get(tolerance_type, '?')
        
    def _draw_measurement_2d(self, ax, measurement):
        """Draw measurement in 2D plot"""
        if measurement['type'] == 'distance_points':
            p1 = measurement['point1'][:2]  # Take only x, y
            p2 = measurement['point2'][:2]
            
            # Draw dimension line
            ax.plot([p1[0], p2[0]], [p1[1], p2[1]], 
                   color=self.measurement_style['line_color'],
                   linestyle=self.measurement_style['dimension_line_style'])
            
            # Draw points
            ax.plot(p1[0], p1[1], 'o', color=self.measurement_style['arrow_color'])
            ax.plot(p2[0], p2[1], 'o', color=self.measurement_style['arrow_color'])
            
            # Add dimension text
            midpoint = measurement['midpoint'][:2]
            distance_text = f"{measurement['distance']:.{self.precision}f}"
            ax.text(midpoint[0], midpoint[1], distance_text, 
                   ha='center', va='bottom', fontsize=self.measurement_style['font_size'],
                   color=self.measurement_style['text_color'])
                   
    def _draw_measurement_3d(self, ax, measurement):
        """Draw measurement in 3D plot"""
        if measurement['type'] == 'distance_points':
            p1 = measurement['point1']
            p2 = measurement['point2']
            
            # Draw dimension line
            ax.plot([p1[0], p2[0]], [p1[1], p2[1]], [p1[2], p2[2]], 
                   color=self.measurement_style['line_color'],
                   linestyle=self.measurement_style['dimension_line_style'])
            
            # Draw points
            ax.scatter(p1[0], p1[1], p1[2], color=self.measurement_style['arrow_color'])
            ax.scatter(p2[0], p2[1], p2[2], color=self.measurement_style['arrow_color'])
            
            # Add dimension text
            midpoint = measurement['midpoint']
            distance_text = f"{measurement['distance']:.{self.precision}f}"
            ax.text(midpoint[0], midpoint[1], midpoint[2], distance_text, 
                   fontsize=self.measurement_style['font_size'],
                   color=self.measurement_style['text_color'])


# Integration with RGDL V3.1 Professional
class RGDLMeasurementIntegration:
    """
    Integration class for RGDL V3.1 Professional measurement system
    """
    
    def __init__(self, rgdl_system):
        self.rgdl_system = rgdl_system
        self.measurement_system = MeasurementSystem()
        
    def measure_bitfield_dimensions(self, bitfield, voxel_size=0.001):
        """
        Measure overall dimensions of bitfield geometry
        """
        # Find bounding box
        indices = np.where(bitfield == 1)
        if len(indices[0]) == 0:
            print("No active voxels in bitfield")
            return None
            
        min_coords = [np.min(indices[i]) * voxel_size for i in range(3)]
        max_coords = [np.max(indices[i]) * voxel_size for i in range(3)]
        
        # Measure dimensions
        length = self.measurement_system.measure_distance_points(
            [min_coords[0], min_coords[1], min_coords[2]],
            [max_coords[0], min_coords[1], min_coords[2]],
            "Length"
        )
        
        width = self.measurement_system.measure_distance_points(
            [min_coords[0], min_coords[1], min_coords[2]],
            [min_coords[0], max_coords[1], min_coords[2]],
            "Width"
        )
        
        height = self.measurement_system.measure_distance_points(
            [min_coords[0], min_coords[1], min_coords[2]],
            [min_coords[0], min_coords[1], max_coords[2]],
            "Height"
        )
        
        # Measure volume
        volume = self.measurement_system.measure_volume_from_bitfield(
            bitfield, voxel_size, "Total Volume"
        )
        
        return {
            'length': length,
            'width': width,
            'height': height,
            'volume': volume,
            'bounding_box': {
                'min': min_coords,
                'max': max_coords
            }
        }
        
    def create_measurement_report(self, output_dir="measurement_output"):
        """
        Create comprehensive measurement report
        """
        os.makedirs(output_dir, exist_ok=True)
        
        # Export JSON report
        json_path = os.path.join(output_dir, "measurement_report.json")
        report = self.measurement_system.export_measurement_report(json_path)
        
        # Export technical drawing
        drawing_path = os.path.join(output_dir, "technical_drawing.png")
        self.measurement_system.export_technical_drawing(drawing_path)
        
        # Export 3D visualization
        viz_path = os.path.join(output_dir, "measurements_3d.png")
        self.measurement_system.visualize_measurements_3d(save_path=viz_path)
        
        print(f"Measurement report created in {output_dir}")
        return output_dir


if __name__ == "__main__":
    # Example usage
    measurement_system = MeasurementSystem()
    
    # Set units and precision
    measurement_system.set_units("mm")
    measurement_system.set_precision(3)
    
    # Example measurements
    measurement_system.measure_distance_points([0, 0, 0], [10, 0, 0], "Length")
    measurement_system.measure_distance_points([0, 0, 0], [0, 5, 0], "Width")
    measurement_system.measure_angle_three_points([0, 0, 0], [10, 0, 0], [0, 5, 0], "Corner Angle")
    
    # Create annotations
    measurement_system.create_dimensional_annotation(1, tolerance={'plus': 0.1, 'minus': 0.1, 'units': 'mm'})
    measurement_system.create_geometric_tolerance_annotation(3, 'perpendicularity', 0.05, ['A'])
    
    # Visualize and export
    measurement_system.visualize_measurements_2d()
    measurement_system.export_measurement_report("measurement_report.json")
    
    print("Measurement system demonstration complete!")

