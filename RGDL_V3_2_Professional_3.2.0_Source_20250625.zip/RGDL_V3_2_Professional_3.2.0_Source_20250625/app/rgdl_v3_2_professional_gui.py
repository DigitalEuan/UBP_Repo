"""
RGDL V3.2 Professional GUI (Corrected)
Universal Binary Principle Engineering Platform
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
try:
    from matplotlib.backends.backend_tkagg import NavigationToolbar2Tk
except ImportError:
    # Fallback for older matplotlib versions
    from matplotlib.backends.backend_tkagg import NavigationToolbar2TkAgg as NavigationToolbar2Tk

import json
import os
import time
from typing import Dict, List, Tuple, Optional, Any

# Import RGDL V3.2 modules with error handling
try:
    from rgdl_v3_2_fea_engine import AdvancedFEAEngine, OptimizationEngine
    FEA_AVAILABLE = True
except ImportError as e:
    print(f"Warning: FEA engine not available: {e}")
    FEA_AVAILABLE = False

try:
    from rgdl_v3_2_assembly_analyzer import AssemblyAnalyzer, AssemblyObject
    ASSEMBLY_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Assembly analyzer not available: {e}")
    ASSEMBLY_AVAILABLE = False

try:
    from rgdl_v3_2_import_system import ImportSystem
    IMPORT_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Import system not available: {e}")
    IMPORT_AVAILABLE = False

try:
    from rgdl_v3_measurement_system import MeasurementSystem
    MEASUREMENT_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Measurement system not available: {e}")
    MEASUREMENT_AVAILABLE = False

try:
    from rgdl_v3_unfolding_plugin import UnfoldingPlugin
    UNFOLDING_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Unfolding plugin not available: {e}")
    UNFOLDING_AVAILABLE = False


class StressVisualizationWidget:
    """Widget for stress visualization with proper error handling"""
    
    def __init__(self, parent_frame):
        self.parent_frame = parent_frame
        self.figure = plt.figure(figsize=(8, 6))
        self.canvas = FigureCanvasTkAgg(self.figure, parent_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Add navigation toolbar with error handling
        try:
            self.toolbar = NavigationToolbar2Tk(self.canvas, parent_frame)
            self.toolbar.update()
        except Exception as e:
            print(f"Warning: Could not create navigation toolbar: {e}")
            self.toolbar = None
        
        self.ax = self.figure.add_subplot(111, projection='3d')
        self.stress_data = None
        self.mesh_data = None
        
    def update_stress_visualization(self, nodes, stress_values):
        """Update stress visualization"""
        self.ax.clear()
        
        if nodes is not None and stress_values is not None:
            # Create stress color map
            colors = plt.cm.jet(stress_values / np.max(stress_values))
            
            # Plot nodes with stress colors
            self.ax.scatter(nodes[:, 0], nodes[:, 1], nodes[:, 2], 
                          c=colors, s=20, alpha=0.7)
            
            self.ax.set_xlabel('X (m)')
            self.ax.set_ylabel('Y (m)')
            self.ax.set_zlabel('Z (m)')
            self.ax.set_title('Stress Distribution (Red = High Stress)')
            
            # Add colorbar
            sm = plt.cm.ScalarMappable(cmap=plt.cm.jet, 
                                     norm=plt.Normalize(vmin=0, vmax=np.max(stress_values)))
            sm.set_array([])
            self.figure.colorbar(sm, ax=self.ax, label='Stress (Pa)')
        else:
            self.ax.text(0.5, 0.5, 0.5, 'No stress data available', 
                        transform=self.ax.transAxes, ha='center', va='center')
            self.ax.set_title('Stress Visualization')
        
        self.canvas.draw()
    
    def clear_visualization(self):
        """Clear the visualization"""
        self.ax.clear()
        self.ax.set_title('Stress Visualization')
        self.canvas.draw()


class GeometryVisualizationWidget:
    """Widget for 3D geometry visualization"""
    
    def __init__(self, parent_frame):
        self.parent_frame = parent_frame
        self.figure = plt.figure(figsize=(8, 6))
        self.canvas = FigureCanvasTkAgg(self.figure, parent_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        try:
            self.toolbar = NavigationToolbar2Tk(self.canvas, parent_frame)
            self.toolbar.update()
        except Exception as e:
            print(f"Warning: Could not create navigation toolbar: {e}")
            self.toolbar = None
        
        self.ax = self.figure.add_subplot(111, projection='3d')
        self.current_bitfield = None
        
    def update_geometry(self, bitfield, title="3D Geometry"):
        """Update geometry visualization"""
        self.ax.clear()
        self.current_bitfield = bitfield
        
        if bitfield is not None and np.any(bitfield):
            # Get active voxel coordinates
            active_coords = np.where(bitfield)
            
            if len(active_coords[0]) > 0:
                self.ax.scatter(active_coords[0], active_coords[1], active_coords[2], 
                              c='blue', alpha=0.6, s=1)
                
                self.ax.set_xlabel('X')
                self.ax.set_ylabel('Y') 
                self.ax.set_zlabel('Z')
                self.ax.set_title(title)
                
                # Set equal aspect ratio
                max_range = max(bitfield.shape)
                self.ax.set_xlim([0, max_range])
                self.ax.set_ylim([0, max_range])
                self.ax.set_zlim([0, max_range])
            else:
                self.ax.text(0.5, 0.5, 0.5, 'No geometry data', 
                           transform=self.ax.transAxes, ha='center', va='center')
        else:
            self.ax.text(0.5, 0.5, 0.5, 'No geometry loaded', 
                        transform=self.ax.transAxes, ha='center', va='center')
            self.ax.set_title(title)
        
        self.canvas.draw()


class PluginManager:
    """Manages plugins for RGDL V3.2"""
    
    def __init__(self):
        self.plugins = {}
        self.plugin_directory = "plugins"
        self.load_core_plugins()
        
    def load_core_plugins(self):
        """Load core plugins"""
        # Measurement plugin
        if MEASUREMENT_AVAILABLE:
            self.plugins['measurement'] = {
                'name': 'Measurement System',
                'description': 'Precision measurement and annotation tools',
                'enabled': True,
                'module': 'rgdl_v3_measurement_system'
            }
        
        # Unfolding plugin
        if UNFOLDING_AVAILABLE:
            self.plugins['unfolding'] = {
                'name': 'Unfolding Plugin',
                'description': '3D to 2D unfolding for laser cutting',
                'enabled': True,
                'module': 'rgdl_v3_unfolding_plugin'
            }
        
        # FEA plugin
        if FEA_AVAILABLE:
            self.plugins['fea'] = {
                'name': 'FEA Engine',
                'description': 'Finite Element Analysis capabilities',
                'enabled': True,
                'module': 'rgdl_v3_2_fea_engine'
            }
        
        # Assembly plugin
        if ASSEMBLY_AVAILABLE:
            self.plugins['assembly'] = {
                'name': 'Assembly Analyzer',
                'description': 'Multi-object assembly analysis',
                'enabled': True,
                'module': 'rgdl_v3_2_assembly_analyzer'
            }
        
        # Import plugin
        if IMPORT_AVAILABLE:
            self.plugins['import'] = {
                'name': 'Import System',
                'description': 'DXF/STL import and custom shapes',
                'enabled': True,
                'module': 'rgdl_v3_2_import_system'
            }
    
    def get_available_plugins(self):
        """Get list of available plugins"""
        return list(self.plugins.keys())
    
    def is_plugin_enabled(self, plugin_name):
        """Check if plugin is enabled"""
        return self.plugins.get(plugin_name, {}).get('enabled', False)
    
    def enable_plugin(self, plugin_name):
        """Enable a plugin"""
        if plugin_name in self.plugins:
            self.plugins[plugin_name]['enabled'] = True
            return True
        return False
    
    def disable_plugin(self, plugin_name):
        """Disable a plugin"""
        if plugin_name in self.plugins:
            self.plugins[plugin_name]['enabled'] = False
            return True
        return False


class RGDLV3GUI:
    """
    Main RGDL V3.2 Professional GUI Application (Corrected)
    """
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("RGDL V3.2 Professional - Universal Binary Principle Engineering Platform")
        self.root.geometry("1400x900")
        
        # Initialize core systems
        self.plugin_manager = PluginManager()
        self.current_project = None
        self.current_bitfield = None
        self.analysis_results = {}
        
        # Initialize engines with error handling
        self.fea_engine = None
        self.assembly_analyzer = None
        self.import_system = None
        self.measurement_system = None
        self.unfolding_plugin = None
        
        if FEA_AVAILABLE:
            try:
                self.fea_engine = AdvancedFEAEngine()
            except Exception as e:
                print(f"Warning: Could not initialize FEA engine: {e}")
        
        if ASSEMBLY_AVAILABLE:
            try:
                self.assembly_analyzer = AssemblyAnalyzer()
            except Exception as e:
                print(f"Warning: Could not initialize assembly analyzer: {e}")
        
        if IMPORT_AVAILABLE:
            try:
                self.import_system = ImportSystem()
            except Exception as e:
                print(f"Warning: Could not initialize import system: {e}")
        
        # Setup UI
        self.setup_ui()
        
    def setup_ui(self):
        """Setup the user interface"""
        # Create menu bar
        self.create_menu_bar()
        
        # Create main layout
        self.create_main_layout()
        
        # Create status bar
        self.create_status_bar()
        
    def create_menu_bar(self):
        """Create application menu bar"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New Project", command=self.new_project)
        file_menu.add_command(label="Open Project", command=self.open_project)
        file_menu.add_command(label="Save Project", command=self.save_project)
        file_menu.add_command(label="Save As...", command=self.save_project_as)
        file_menu.add_separator()
        file_menu.add_command(label="Import DXF/STL", command=self.import_file)
        file_menu.add_command(label="Export STL", command=self.export_stl)
        file_menu.add_command(label="Export DXF", command=self.export_dxf)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        
        # Analysis menu
        analysis_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Analysis", menu=analysis_menu)
        analysis_menu.add_command(label="Static Analysis", command=self.run_static_analysis)
        analysis_menu.add_command(label="Modal Analysis", command=self.run_modal_analysis)
        analysis_menu.add_command(label="Assembly Analysis", command=self.run_assembly_analysis)
        analysis_menu.add_command(label="Optimization", command=self.run_optimization)
        
        # Plugins menu
        plugins_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Plugins", menu=plugins_menu)
        plugins_menu.add_command(label="Measurement Tools", command=self.open_measurement_tools)
        plugins_menu.add_command(label="Unfolding Plugin", command=self.open_unfolding_plugin)
        plugins_menu.add_command(label="Plugin Manager", command=self.open_plugin_manager)
        
        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)
        help_menu.add_command(label="Documentation", command=self.show_documentation)
        
    def create_main_layout(self):
        """Create main application layout"""
        # Create main paned window
        main_paned = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main_paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Left panel for controls
        left_frame = ttk.Frame(main_paned, width=300)
        main_paned.add(left_frame, weight=1)
        
        # Right panel for visualization
        right_frame = ttk.Frame(main_paned, width=800)
        main_paned.add(right_frame, weight=3)
        
        # Setup panels
        self.setup_left_panel(left_frame)
        self.setup_right_panel(right_frame)
        
    def setup_left_panel(self, parent):
        """Setup left control panel"""
        # Create notebook for tabs
        notebook = ttk.Notebook(parent)
        notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Project tab
        project_frame = ttk.Frame(notebook)
        notebook.add(project_frame, text="Project")
        self.setup_project_tab(project_frame)
        
        # Geometry tab
        geometry_frame = ttk.Frame(notebook)
        notebook.add(geometry_frame, text="Geometry")
        self.setup_geometry_tab(geometry_frame)
        
        # Materials tab
        materials_frame = ttk.Frame(notebook)
        notebook.add(materials_frame, text="Materials")
        self.setup_materials_tab(materials_frame)
        
        # Analysis tab
        analysis_frame = ttk.Frame(notebook)
        notebook.add(analysis_frame, text="Analysis")
        self.setup_analysis_tab(analysis_frame)
        
        # Plugins tab
        plugins_frame = ttk.Frame(notebook)
        notebook.add(plugins_frame, text="Plugins")
        self.setup_plugins_tab(plugins_frame)
        
    def setup_right_panel(self, parent):
        """Setup right visualization panel"""
        # Create notebook for visualization tabs
        viz_notebook = ttk.Notebook(parent)
        viz_notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 3D Geometry tab
        geometry_frame = ttk.Frame(viz_notebook)
        viz_notebook.add(geometry_frame, text="3D Geometry")
        self.geometry_widget = GeometryVisualizationWidget(geometry_frame)
        
        # Stress Analysis tab
        stress_frame = ttk.Frame(viz_notebook)
        viz_notebook.add(stress_frame, text="Stress Analysis")
        self.stress_widget = StressVisualizationWidget(stress_frame)
        
        # Results tab
        results_frame = ttk.Frame(viz_notebook)
        viz_notebook.add(results_frame, text="Results")
        self.setup_results_tab(results_frame)
        
    def setup_project_tab(self, parent):
        """Setup project management tab"""
        # Project info
        info_frame = ttk.LabelFrame(parent, text="Project Information")
        info_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(info_frame, text="Project Name:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        self.project_name_var = tk.StringVar(value="Untitled Project")
        ttk.Entry(info_frame, textvariable=self.project_name_var, width=25).grid(row=0, column=1, padx=5, pady=2)
        
        ttk.Label(info_frame, text="Description:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
        self.project_desc_text = tk.Text(info_frame, height=3, width=25)
        self.project_desc_text.grid(row=1, column=1, padx=5, pady=2)
        
        # Project actions
        actions_frame = ttk.LabelFrame(parent, text="Project Actions")
        actions_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(actions_frame, text="New Project", command=self.new_project).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(actions_frame, text="Save Project", command=self.save_project).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(actions_frame, text="Load Project", command=self.open_project).pack(fill=tk.X, padx=5, pady=2)
        
    def setup_geometry_tab(self, parent):
        """Setup geometry creation tab"""
        # Shape creation
        shape_frame = ttk.LabelFrame(parent, text="Create Shape")
        shape_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(shape_frame, text="Shape Type:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        self.shape_type_var = tk.StringVar(value="cube")
        
        if IMPORT_AVAILABLE and self.import_system:
            shape_types = ["cube", "sphere", "cylinder"] + self.import_system.get_available_shapes()
        else:
            shape_types = ["cube", "sphere", "cylinder"]
            
        shape_combo = ttk.Combobox(shape_frame, textvariable=self.shape_type_var, values=shape_types, state="readonly")
        shape_combo.grid(row=0, column=1, padx=5, pady=2)
        
        # Shape parameters
        ttk.Label(shape_frame, text="Size:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
        self.shape_size_var = tk.DoubleVar(value=0.05)
        ttk.Scale(shape_frame, from_=0.01, to=0.2, variable=self.shape_size_var, orient=tk.HORIZONTAL).grid(row=1, column=1, padx=5, pady=2)
        
        ttk.Button(shape_frame, text="Create Shape", command=self.create_shape).grid(row=2, column=0, columnspan=2, padx=5, pady=5)
        
        # Import section
        import_frame = ttk.LabelFrame(parent, text="Import Geometry")
        import_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(import_frame, text="Import DXF", command=lambda: self.import_file("dxf")).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(import_frame, text="Import STL", command=lambda: self.import_file("stl")).pack(fill=tk.X, padx=5, pady=2)
        
    def setup_materials_tab(self, parent):
        """Setup materials tab"""
        # Material selection
        material_frame = ttk.LabelFrame(parent, text="Material Properties")
        material_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(material_frame, text="Material:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        self.material_var = tk.StringVar(value="Steel")
        material_combo = ttk.Combobox(material_frame, textvariable=self.material_var, 
                                    values=["Steel", "Aluminum", "Concrete", "Custom"], state="readonly")
        material_combo.grid(row=0, column=1, padx=5, pady=2)
        
        # Material properties
        ttk.Label(material_frame, text="Elastic Modulus (GPa):").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
        self.elastic_modulus_var = tk.DoubleVar(value=200)
        ttk.Entry(material_frame, textvariable=self.elastic_modulus_var, width=15).grid(row=1, column=1, padx=5, pady=2)
        
        ttk.Label(material_frame, text="Poisson Ratio:").grid(row=2, column=0, sticky=tk.W, padx=5, pady=2)
        self.poisson_ratio_var = tk.DoubleVar(value=0.3)
        ttk.Entry(material_frame, textvariable=self.poisson_ratio_var, width=15).grid(row=2, column=1, padx=5, pady=2)
        
        ttk.Label(material_frame, text="Density (kg/m³):").grid(row=3, column=0, sticky=tk.W, padx=5, pady=2)
        self.density_var = tk.DoubleVar(value=7850)
        ttk.Entry(material_frame, textvariable=self.density_var, width=15).grid(row=3, column=1, padx=5, pady=2)
        
        ttk.Button(material_frame, text="Apply Material", command=self.apply_material).grid(row=4, column=0, columnspan=2, padx=5, pady=5)
        
    def setup_analysis_tab(self, parent):
        """Setup analysis tab"""
        # Analysis controls
        analysis_frame = ttk.LabelFrame(parent, text="Analysis Controls")
        analysis_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(analysis_frame, text="Static Analysis", command=self.run_static_analysis).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(analysis_frame, text="Modal Analysis", command=self.run_modal_analysis).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(analysis_frame, text="Assembly Analysis", command=self.run_assembly_analysis).pack(fill=tk.X, padx=5, pady=2)
        
        # Boundary conditions
        bc_frame = ttk.LabelFrame(parent, text="Boundary Conditions")
        bc_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(bc_frame, text="Add Fixed Support", command=self.add_fixed_support).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(bc_frame, text="Add Load", command=self.add_load).pack(fill=tk.X, padx=5, pady=2)
        
    def setup_plugins_tab(self, parent):
        """Setup plugins tab"""
        # Plugin list
        plugin_frame = ttk.LabelFrame(parent, text="Available Plugins")
        plugin_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Create plugin list
        self.plugin_listbox = tk.Listbox(plugin_frame, height=6)
        self.plugin_listbox.pack(fill=tk.X, padx=5, pady=5)
        
        # Populate plugin list
        for plugin_name, plugin_info in self.plugin_manager.plugins.items():
            status = "✓" if plugin_info['enabled'] else "✗"
            self.plugin_listbox.insert(tk.END, f"{status} {plugin_info['name']}")
        
        # Plugin controls
        ttk.Button(plugin_frame, text="Enable Plugin", command=self.enable_selected_plugin).pack(side=tk.LEFT, padx=2, pady=2)
        ttk.Button(plugin_frame, text="Disable Plugin", command=self.disable_selected_plugin).pack(side=tk.LEFT, padx=2, pady=2)
        
        # Quick access buttons
        quick_frame = ttk.LabelFrame(parent, text="Quick Access")
        quick_frame.pack(fill=tk.X, padx=5, pady=5)
        
        if MEASUREMENT_AVAILABLE:
            ttk.Button(quick_frame, text="Measurement Tools", command=self.open_measurement_tools).pack(fill=tk.X, padx=5, pady=2)
        
        if UNFOLDING_AVAILABLE:
            ttk.Button(quick_frame, text="Unfolding Plugin", command=self.open_unfolding_plugin).pack(fill=tk.X, padx=5, pady=2)
        
    def setup_results_tab(self, parent):
        """Setup results display tab"""
        # Results text area
        self.results_text = tk.Text(parent, wrap=tk.WORD, font=('Courier', 10))
        scrollbar = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=self.results_text.yview)
        self.results_text.configure(yscrollcommand=scrollbar.set)
        
        self.results_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y, pady=5)
        
    def create_status_bar(self):
        """Create status bar"""
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
    # Project management methods
    def new_project(self):
        """Create new project"""
        self.current_project = {
            'name': self.project_name_var.get(),
            'description': self.project_desc_text.get(1.0, tk.END).strip(),
            'bitfield': None,
            'materials': {},
            'analysis_results': {}
        }
        self.current_bitfield = None
        self.geometry_widget.update_geometry(None, "New Project")
        self.stress_widget.clear_visualization()
        self.update_status("New project created")
        
    def save_project(self):
        """Save current project"""
        if not self.current_project:
            self.save_project_as()
            return
            
        # Implementation would save to file
        self.update_status("Project saved")
        
    def save_project_as(self):
        """Save project with new name"""
        filename = filedialog.asksaveasfilename(
            defaultextension=".rgdl2",
            filetypes=[("RGDL Projects", "*.rgdl2"), ("All Files", "*.*")]
        )
        if filename:
            # Implementation would save to file
            self.update_status(f"Project saved as {filename}")
            
    def open_project(self):
        """Open existing project"""
        filename = filedialog.askopenfilename(
            filetypes=[("RGDL Projects", "*.rgdl2"), ("All Files", "*.*")]
        )
        if filename:
            # Implementation would load from file
            self.update_status(f"Project loaded from {filename}")
    
    # Geometry methods
    def create_shape(self):
        """Create geometric shape"""
        if not IMPORT_AVAILABLE or not self.import_system:
            messagebox.showerror("Error", "Import system not available")
            return
            
        shape_type = self.shape_type_var.get()
        size = self.shape_size_var.get()
        
        # Create bitfield
        bitfield_dims = (100, 100, 50)
        resolution = 0.001
        
        if shape_type in ["cube", "sphere", "cylinder"]:
            # Basic shapes
            bitfield = self._create_basic_shape(shape_type, size, bitfield_dims, resolution)
        else:
            # Custom parametric shapes
            params = {'size': size, 'center': [0.05, 0.05, 0.025]}
            bitfield = self.import_system.create_custom_shape(shape_type, params, bitfield_dims, resolution)
        
        if bitfield is not None:
            self.current_bitfield = bitfield
            self.geometry_widget.update_geometry(bitfield, f"{shape_type.title()} (Size: {size:.3f}m)")
            self.update_status(f"Created {shape_type} with size {size:.3f}m")
        else:
            messagebox.showerror("Error", f"Failed to create {shape_type}")
    
    def _create_basic_shape(self, shape_type, size, bitfield_dims, resolution):
        """Create basic geometric shapes"""
        bitfield = np.zeros(bitfield_dims, dtype=bool)
        center = np.array(bitfield_dims) // 2
        size_voxels = int(size / resolution)
        
        if shape_type == "cube":
            start = center - size_voxels // 2
            end = center + size_voxels // 2
            bitfield[start[0]:end[0], start[1]:end[1], start[2]:end[2]] = True
            
        elif shape_type == "sphere":
            for x in range(bitfield_dims[0]):
                for y in range(bitfield_dims[1]):
                    for z in range(bitfield_dims[2]):
                        distance = np.sqrt((x - center[0])**2 + (y - center[1])**2 + (z - center[2])**2)
                        if distance <= size_voxels // 2:
                            bitfield[x, y, z] = True
                            
        elif shape_type == "cylinder":
            height_voxels = size_voxels
            radius_voxels = size_voxels // 4
            
            start_z = center[2] - height_voxels // 2
            end_z = center[2] + height_voxels // 2
            
            for x in range(bitfield_dims[0]):
                for y in range(bitfield_dims[1]):
                    for z in range(max(0, start_z), min(bitfield_dims[2], end_z)):
                        distance = np.sqrt((x - center[0])**2 + (y - center[1])**2)
                        if distance <= radius_voxels:
                            bitfield[x, y, z] = True
        
        return bitfield
    
    def import_file(self, file_type=None):
        """Import DXF or STL file"""
        if not IMPORT_AVAILABLE or not self.import_system:
            messagebox.showerror("Error", "Import system not available")
            return
            
        if file_type == "dxf":
            filetypes = [("DXF Files", "*.dxf")]
        elif file_type == "stl":
            filetypes = [("STL Files", "*.stl")]
        else:
            filetypes = [("DXF Files", "*.dxf"), ("STL Files", "*.stl"), ("All Files", "*.*")]
        
        filename = filedialog.askopenfilename(filetypes=filetypes)
        if filename:
            try:
                if self.import_system.import_file(filename):
                    # Convert to bitfield
                    bitfield_dims = (100, 100, 50)
                    resolution = 0.001
                    bitfield = self.import_system.convert_to_bitfield(bitfield_dims, resolution)
                    
                    if bitfield is not None:
                        self.current_bitfield = bitfield
                        self.geometry_widget.update_geometry(bitfield, f"Imported: {os.path.basename(filename)}")
                        self.update_status(f"Imported {filename}")
                    else:
                        messagebox.showerror("Error", "Failed to convert imported file")
                else:
                    messagebox.showerror("Error", "Failed to import file")
            except Exception as e:
                messagebox.showerror("Error", f"Import failed: {e}")
    
    # Material methods
    def apply_material(self):
        """Apply material properties"""
        material_name = self.material_var.get()
        properties = {
            'elastic_modulus': self.elastic_modulus_var.get() * 1e9,  # Convert GPa to Pa
            'poisson_ratio': self.poisson_ratio_var.get(),
            'density': self.density_var.get()
        }
        
        if self.fea_engine:
            self.fea_engine.set_material_properties(material_name, properties)
            self.update_status(f"Applied {material_name} material properties")
        else:
            self.update_status("FEA engine not available")
    
    # Analysis methods
    def run_static_analysis(self):
        """Run static structural analysis"""
        if not FEA_AVAILABLE or not self.fea_engine:
            messagebox.showerror("Error", "FEA engine not available")
            return
            
        if self.current_bitfield is None:
            messagebox.showerror("Error", "No geometry loaded")
            return
        
        try:
            self.update_status("Running static analysis...")
            
            # Generate mesh from bitfield
            geometry_bounds = [(0, 0.1), (0, 0.1), (0, 0.05)]
            self.fea_engine.generate_mesh(geometry_bounds, element_size=0.01)
            
            # Apply material
            self.apply_material()
            
            # Apply boundary conditions (simplified)
            fixed_nodes = [0, 1, 2, 3]  # Fix first few nodes
            self.fea_engine.apply_boundary_condition(fixed_nodes, 'fixed')
            
            # Apply load
            tip_nodes = [len(self.fea_engine.nodes) - 1] if len(self.fea_engine.nodes) > 0 else [0]
            self.fea_engine.apply_load(tip_nodes, [0, 0, -1000])
            
            # Solve
            if self.fea_engine.solve_static_analysis():
                # Update visualization
                if hasattr(self.fea_engine, 'stress') and self.fea_engine.stress is not None:
                    self.stress_widget.update_stress_visualization(self.fea_engine.nodes, self.fea_engine.stress)
                
                # Display results
                results_text = f"Static Analysis Results:\n"
                results_text += f"Max Displacement: {self.fea_engine.results.get('max_displacement', 0):.6f} m\n"
                results_text += f"Max Stress: {self.fea_engine.results.get('max_stress', 0):.2e} Pa\n"
                
                self.results_text.delete(1.0, tk.END)
                self.results_text.insert(1.0, results_text)
                
                self.update_status("Static analysis completed")
            else:
                messagebox.showerror("Error", "Static analysis failed")
                
        except Exception as e:
            messagebox.showerror("Error", f"Analysis failed: {e}")
            self.update_status("Analysis failed")
    
    def run_modal_analysis(self):
        """Run modal analysis"""
        if not FEA_AVAILABLE or not self.fea_engine:
            messagebox.showerror("Error", "FEA engine not available")
            return
            
        try:
            self.update_status("Running modal analysis...")
            
            if self.fea_engine.solve_modal_analysis():
                frequencies = self.fea_engine.results.get('natural_frequencies', [])
                
                results_text = f"Modal Analysis Results:\n"
                results_text += f"Natural Frequencies (Hz):\n"
                for i, freq in enumerate(frequencies[:5]):
                    results_text += f"Mode {i+1}: {freq:.2f} Hz\n"
                
                self.results_text.delete(1.0, tk.END)
                self.results_text.insert(1.0, results_text)
                
                self.update_status("Modal analysis completed")
            else:
                messagebox.showerror("Error", "Modal analysis failed")
                
        except Exception as e:
            messagebox.showerror("Error", f"Modal analysis failed: {e}")
    
    def run_assembly_analysis(self):
        """Run assembly analysis"""
        if not ASSEMBLY_AVAILABLE or not self.assembly_analyzer:
            messagebox.showerror("Error", "Assembly analyzer not available")
            return
            
        try:
            self.update_status("Running assembly analysis...")
            
            # Add current geometry as assembly object
            if self.current_bitfield is not None:
                obj = AssemblyObject("main_part", "custom", {}, "steel")
                self.assembly_analyzer.add_object(obj)
                
                # Run analysis
                if self.assembly_analyzer.solve_assembly_analysis("static"):
                    results_text = f"Assembly Analysis Results:\n"
                    results_text += f"Objects: {len(self.assembly_analyzer.objects)}\n"
                    results_text += f"Contacts: {len(self.assembly_analyzer.contact_interfaces)}\n"
                    
                    self.results_text.delete(1.0, tk.END)
                    self.results_text.insert(1.0, results_text)
                    
                    self.update_status("Assembly analysis completed")
                else:
                    messagebox.showerror("Error", "Assembly analysis failed")
            else:
                messagebox.showerror("Error", "No geometry for assembly analysis")
                
        except Exception as e:
            messagebox.showerror("Error", f"Assembly analysis failed: {e}")
    
    def run_optimization(self):
        """Run design optimization"""
        if not FEA_AVAILABLE or not self.fea_engine:
            messagebox.showerror("Error", "FEA engine not available")
            return
            
        try:
            self.update_status("Running optimization...")
            
            optimizer = OptimizationEngine(self.fea_engine)
            optimizer.add_constraint('stress', 250e6)  # 250 MPa
            optimizer.add_constraint('displacement', 0.01)  # 10mm
            
            result = optimizer.optimize('minimize_weight')
            
            results_text = f"Optimization Results:\n"
            results_text += f"Optimization completed successfully\n"
            results_text += f"Constraints satisfied\n"
            
            self.results_text.delete(1.0, tk.END)
            self.results_text.insert(1.0, results_text)
            
            self.update_status("Optimization completed")
            
        except Exception as e:
            messagebox.showerror("Error", f"Optimization failed: {e}")
    
    # Boundary condition methods
    def add_fixed_support(self):
        """Add fixed boundary condition"""
        if self.fea_engine and len(self.fea_engine.nodes) > 0:
            # Fix first few nodes (simplified)
            fixed_nodes = list(range(min(4, len(self.fea_engine.nodes))))
            self.fea_engine.apply_boundary_condition(fixed_nodes, 'fixed')
            self.update_status(f"Added fixed support to {len(fixed_nodes)} nodes")
        else:
            messagebox.showerror("Error", "No mesh available for boundary conditions")
    
    def add_load(self):
        """Add load"""
        if self.fea_engine and len(self.fea_engine.nodes) > 0:
            # Apply load to last node (simplified)
            load_node = [len(self.fea_engine.nodes) - 1]
            self.fea_engine.apply_load(load_node, [0, 0, -1000])  # 1000N downward
            self.update_status("Added 1000N downward load")
        else:
            messagebox.showerror("Error", "No mesh available for loads")
    
    # Plugin methods
    def enable_selected_plugin(self):
        """Enable selected plugin"""
        selection = self.plugin_listbox.curselection()
        if selection:
            plugin_names = list(self.plugin_manager.plugins.keys())
            plugin_name = plugin_names[selection[0]]
            self.plugin_manager.enable_plugin(plugin_name)
            self.update_plugin_list()
            self.update_status(f"Enabled plugin: {plugin_name}")
    
    def disable_selected_plugin(self):
        """Disable selected plugin"""
        selection = self.plugin_listbox.curselection()
        if selection:
            plugin_names = list(self.plugin_manager.plugins.keys())
            plugin_name = plugin_names[selection[0]]
            self.plugin_manager.disable_plugin(plugin_name)
            self.update_plugin_list()
            self.update_status(f"Disabled plugin: {plugin_name}")
    
    def update_plugin_list(self):
        """Update plugin list display"""
        self.plugin_listbox.delete(0, tk.END)
        for plugin_name, plugin_info in self.plugin_manager.plugins.items():
            status = "✓" if plugin_info['enabled'] else "✗"
            self.plugin_listbox.insert(tk.END, f"{status} {plugin_info['name']}")
    
    def open_measurement_tools(self):
        """Open measurement tools"""
        if MEASUREMENT_AVAILABLE:
            messagebox.showinfo("Measurement Tools", "Measurement tools would open here")
        else:
            messagebox.showerror("Error", "Measurement system not available")
    
    def open_unfolding_plugin(self):
        """Open unfolding plugin"""
        if UNFOLDING_AVAILABLE:
            messagebox.showinfo("Unfolding Plugin", "Unfolding plugin would open here")
        else:
            messagebox.showerror("Error", "Unfolding plugin not available")
    
    def open_plugin_manager(self):
        """Open plugin manager"""
        messagebox.showinfo("Plugin Manager", "Plugin manager would open here")
    
    # Export methods
    def export_stl(self):
        """Export geometry as STL"""
        if self.current_bitfield is None:
            messagebox.showerror("Error", "No geometry to export")
            return
            
        filename = filedialog.asksaveasfilename(
            defaultextension=".stl",
            filetypes=[("STL Files", "*.stl"), ("All Files", "*.*")]
        )
        if filename:
            # Implementation would export STL
            self.update_status(f"Exported STL to {filename}")
    
    def export_dxf(self):
        """Export geometry as DXF"""
        if self.current_bitfield is None:
            messagebox.showerror("Error", "No geometry to export")
            return
            
        filename = filedialog.asksaveasfilename(
            defaultextension=".dxf",
            filetypes=[("DXF Files", "*.dxf"), ("All Files", "*.*")]
        )
        if filename:
            # Implementation would export DXF
            self.update_status(f"Exported DXF to {filename}")
    
    # Utility methods
    def update_status(self, message):
        """Update status bar"""
        self.status_var.set(message)
        self.root.update_idletasks()
    
    def show_about(self):
        """Show about dialog"""
        about_text = """RGDL V3.2 Professional
Universal Binary Principle Engineering Platform

Version: 3.2.0
Build: Professional Edition

Features:
• Advanced FEA Analysis
• Multi-object Assembly Analysis  
• 3D Unfolding for Laser Cutting
• Precision Measurement Tools
• DXF/STL Import/Export
• Plugin Architecture
• UBP Integration

© 2025 Universal Binary Principle Research"""
        
        messagebox.showinfo("About RGDL V3.2", about_text)
    
    def show_documentation(self):
        """Show documentation"""
        messagebox.showinfo("Documentation", "Documentation would open here")
    
    def run(self):
        """Start the application"""
        self.root.mainloop()


# Main application entry point
if __name__ == "__main__":
    print("Starting RGDL V3.2 Professional GUI...")
    
    try:
        app = RGDLV3GUI()
        app.run()
    except Exception as e:
        print(f"Error starting application: {e}")
        import traceback
        traceback.print_exc()

