#!/usr/bin/env python3
"""
RGDL V3.2 Professional - Standalone Installation System
Universal Binary Principle Engineering Platform

This installer creates a complete, standalone installation of RGDL V3.2
with automatic dependency management and virtual environment setup.
"""

import os
import sys
import subprocess
import platform
import json
import shutil
import urllib.request
import zipfile
import tarfile
from pathlib import Path
import tempfile

class RGDLInstaller:
    """
    Professional installer for RGDL V3.2 with dependency management
    """
    
    def __init__(self):
        self.version = "3.2.0"
        self.platform_system = platform.system().lower()
        self.python_version = f"{sys.version_info.major}.{sys.version_info.minor}"
        
        # Installation paths
        self.install_dir = None
        self.venv_dir = None
        self.app_dir = None
        
        # Dependencies
        self.python_dependencies = [
            "numpy>=1.21.0",
            "scipy>=1.7.0",
            "matplotlib>=3.5.0",
            "trimesh>=3.15.0",
            "networkx>=2.6.0",
            "Pillow>=8.3.0",
            "requests>=2.26.0"
        ]
        
        self.optional_dependencies = [
            "vtk>=9.0.0",  # For advanced 3D visualization
            "pyvista>=0.32.0",  # For mesh processing
            "scikit-learn>=1.0.0",  # For optimization algorithms
            "pandas>=1.3.0",  # For data analysis
            "openpyxl>=3.0.0"  # For Excel export
        ]
        
        # System dependencies by platform
        self.system_dependencies = {
            'linux': ['python3-tk', 'python3-dev', 'build-essential'],
            'darwin': [],  # macOS
            'windows': []
        }
        
        self.installation_log = []
        
    def log(self, message, level="INFO"):
        """Log installation messages"""
        log_entry = f"[{level}] {message}"
        self.installation_log.append(log_entry)
        print(log_entry)
        
    def check_python_version(self):
        """Check if Python version is compatible"""
        self.log("Checking Python version...")
        
        if sys.version_info < (3, 8):
            self.log("ERROR: Python 3.8 or higher is required", "ERROR")
            return False
            
        self.log(f"Python {self.python_version} detected - Compatible")
        return True
        
    def check_system_requirements(self):
        """Check system requirements"""
        self.log("Checking system requirements...")
        
        # Check available disk space (minimum 500MB)
        if shutil.disk_usage('.').free < 500 * 1024 * 1024:
            self.log("ERROR: Insufficient disk space (minimum 500MB required)", "ERROR")
            return False
            
        # Check if we can create virtual environments
        try:
            import venv
            self.log("Virtual environment support available")
        except ImportError:
            self.log("ERROR: Python venv module not available", "ERROR")
            return False
            
        return True
        
    def get_installation_directory(self):
        """Get installation directory from user or use default"""
        if self.platform_system == 'windows':
            default_dir = os.path.join(os.environ.get('PROGRAMFILES', 'C:\\Program Files'), 'RGDL_V3_2')
        else:
            default_dir = os.path.join(os.path.expanduser('~'), 'RGDL_V3_2')
            
        print(f"\\nDefault installation directory: {default_dir}")
        user_input = input("Press Enter to use default, or enter custom path: ").strip()
        
        if user_input:
            self.install_dir = os.path.abspath(user_input)
        else:
            self.install_dir = default_dir
            
        self.venv_dir = os.path.join(self.install_dir, 'venv')
        self.app_dir = os.path.join(self.install_dir, 'app')
        
        self.log(f"Installation directory: {self.install_dir}")
        return True
        
    def create_installation_directory(self):
        """Create installation directory structure"""
        self.log("Creating installation directory structure...")
        
        try:
            # Create main directories
            os.makedirs(self.install_dir, exist_ok=True)
            os.makedirs(self.app_dir, exist_ok=True)
            os.makedirs(os.path.join(self.install_dir, 'plugins'), exist_ok=True)
            os.makedirs(os.path.join(self.install_dir, 'projects'), exist_ok=True)
            os.makedirs(os.path.join(self.install_dir, 'examples'), exist_ok=True)
            os.makedirs(os.path.join(self.install_dir, 'docs'), exist_ok=True)
            os.makedirs(os.path.join(self.install_dir, 'logs'), exist_ok=True)
            
            self.log("Directory structure created successfully")
            return True
            
        except Exception as e:
            self.log(f"ERROR: Failed to create directories: {e}", "ERROR")
            return False
            
    def create_virtual_environment(self):
        """Create Python virtual environment"""
        self.log("Creating Python virtual environment...")
        
        try:
            # Create virtual environment
            subprocess.run([
                sys.executable, '-m', 'venv', self.venv_dir
            ], check=True, capture_output=True)
            
            self.log("Virtual environment created successfully")
            return True
            
        except subprocess.CalledProcessError as e:
            self.log(f"ERROR: Failed to create virtual environment: {e}", "ERROR")
            return False
            
    def get_venv_python(self):
        """Get path to Python executable in virtual environment"""
        if self.platform_system == 'windows':
            return os.path.join(self.venv_dir, 'Scripts', 'python.exe')
        else:
            return os.path.join(self.venv_dir, 'bin', 'python')
            
    def get_venv_pip(self):
        """Get path to pip executable in virtual environment"""
        if self.platform_system == 'windows':
            return os.path.join(self.venv_dir, 'Scripts', 'pip.exe')
        else:
            return os.path.join(self.venv_dir, 'bin', 'pip')
            
    def install_python_dependencies(self):
        """Install Python dependencies in virtual environment"""
        self.log("Installing Python dependencies...")
        
        pip_path = self.get_venv_pip()
        
        try:
            # Upgrade pip first
            subprocess.run([
                pip_path, 'install', '--upgrade', 'pip'
            ], check=True, capture_output=True)
            
            # Install core dependencies
            for dependency in self.python_dependencies:
                self.log(f"Installing {dependency}...")
                subprocess.run([
                    pip_path, 'install', dependency
                ], check=True, capture_output=True)
                
            self.log("Core dependencies installed successfully")
            
            # Install optional dependencies (with error handling)
            self.log("Installing optional dependencies...")
            for dependency in self.optional_dependencies:
                try:
                    self.log(f"Installing {dependency}...")
                    subprocess.run([
                        pip_path, 'install', dependency
                    ], check=True, capture_output=True)
                except subprocess.CalledProcessError:
                    self.log(f"WARNING: Failed to install optional dependency {dependency}", "WARNING")
                    
            return True
            
        except subprocess.CalledProcessError as e:
            self.log(f"ERROR: Failed to install dependencies: {e}", "ERROR")
            return False
            
    def install_system_dependencies(self):
        """Install system dependencies"""
        if self.platform_system not in self.system_dependencies:
            self.log("No system dependencies required for this platform")
            return True
            
        deps = self.system_dependencies[self.platform_system]
        if not deps:
            return True
            
        self.log("Installing system dependencies...")
        
        try:
            if self.platform_system == 'linux':
                # Try to install with apt (Ubuntu/Debian)
                subprocess.run([
                    'sudo', 'apt-get', 'update'
                ], check=True, capture_output=True)
                
                subprocess.run([
                    'sudo', 'apt-get', 'install', '-y'
                ] + deps, check=True, capture_output=True)
                
            self.log("System dependencies installed successfully")
            return True
            
        except subprocess.CalledProcessError as e:
            self.log(f"WARNING: Failed to install system dependencies: {e}", "WARNING")
            self.log("You may need to install system dependencies manually", "WARNING")
            return True  # Continue installation
            
    def copy_application_files(self):
        """Copy RGDL application files to installation directory"""
        self.log("Copying application files...")
        
        # List of core application files
        app_files = [
            'rgdl_v3_2_fea_engine.py',
            'rgdl_v3_2_assembly_analyzer.py',
            'rgdl_v3_2_import_system.py',
            'rgdl_v3_2_professional_gui.py',
            'rgdl_v3_2_plugin_system.py',
            'rgdl_v3_measurement_system.py',
            'rgdl_v3_unfolding_plugin.py'
        ]
        
        try:
            # Copy core files
            for filename in app_files:
                if os.path.exists(filename):
                    shutil.copy2(filename, self.app_dir)
                    self.log(f"Copied {filename}")
                else:
                    self.log(f"WARNING: {filename} not found", "WARNING")
                    
            # Copy additional files if they exist
            additional_files = [
                'README.md',
                'LICENSE',
                'requirements.txt'
            ]
            
            for filename in additional_files:
                if os.path.exists(filename):
                    shutil.copy2(filename, self.install_dir)
                    
            self.log("Application files copied successfully")
            return True
            
        except Exception as e:
            self.log(f"ERROR: Failed to copy application files: {e}", "ERROR")
            return False
            
    def create_launcher_scripts(self):
        """Create launcher scripts for easy application startup"""
        self.log("Creating launcher scripts...")
        
        try:
            # Create main launcher script
            if self.platform_system == 'windows':
                launcher_path = os.path.join(self.install_dir, 'RGDL_V3_2.bat')
                launcher_content = f'''@echo off
cd /d "{self.app_dir}"
"{self.get_venv_python()}" rgdl_v3_2_professional_gui.py
pause
'''
            else:
                launcher_path = os.path.join(self.install_dir, 'RGDL_V3_2.sh')
                launcher_content = f'''#!/bin/bash
cd "{self.app_dir}"
"{self.get_venv_python()}" rgdl_v3_2_professional_gui.py
'''
                
            with open(launcher_path, 'w') as f:
                f.write(launcher_content)
                
            # Make executable on Unix systems
            if self.platform_system != 'windows':
                os.chmod(launcher_path, 0o755)
                
            # Create desktop shortcut (Linux)
            if self.platform_system == 'linux':
                desktop_path = os.path.join(os.path.expanduser('~'), 'Desktop', 'RGDL_V3_2.desktop')
                desktop_content = f'''[Desktop Entry]
Version=1.0
Type=Application
Name=RGDL V3.2 Professional
Comment=Universal Binary Principle Engineering Platform
Exec={launcher_path}
Icon={os.path.join(self.install_dir, 'icon.png')}
Terminal=false
Categories=Engineering;Science;
'''
                try:
                    with open(desktop_path, 'w') as f:
                        f.write(desktop_content)
                    os.chmod(desktop_path, 0o755)
                    self.log("Desktop shortcut created")
                except:
                    self.log("Could not create desktop shortcut", "WARNING")
                    
            self.log("Launcher scripts created successfully")
            return True
            
        except Exception as e:
            self.log(f"ERROR: Failed to create launcher scripts: {e}", "ERROR")
            return False
            
    def create_configuration_files(self):
        """Create configuration files"""
        self.log("Creating configuration files...")
        
        try:
            # Main configuration
            config = {
                'version': self.version,
                'installation_path': self.install_dir,
                'python_path': self.get_venv_python(),
                'plugin_directory': os.path.join(self.install_dir, 'plugins'),
                'project_directory': os.path.join(self.install_dir, 'projects'),
                'log_directory': os.path.join(self.install_dir, 'logs'),
                'auto_save': True,
                'check_updates': True
            }
            
            config_path = os.path.join(self.install_dir, 'config.json')
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2)
                
            # Plugin configuration
            plugin_config = {
                'enabled_plugins': [
                    'fea_plugin',
                    'assembly_plugin',
                    'import_plugin',
                    'measurement_plugin',
                    'unfolding_plugin'
                ],
                'plugin_paths': [
                    os.path.join(self.install_dir, 'plugins')
                ]
            }
            
            plugin_config_path = os.path.join(self.install_dir, 'plugins', 'plugin_config.json')
            with open(plugin_config_path, 'w') as f:
                json.dump(plugin_config, f, indent=2)
                
            self.log("Configuration files created successfully")
            return True
            
        except Exception as e:
            self.log(f"ERROR: Failed to create configuration files: {e}", "ERROR")
            return False
            
    def create_uninstaller(self):
        """Create uninstaller script"""
        self.log("Creating uninstaller...")
        
        try:
            if self.platform_system == 'windows':
                uninstaller_path = os.path.join(self.install_dir, 'uninstall.bat')
                uninstaller_content = f'''@echo off
echo Uninstalling RGDL V3.2 Professional...
echo This will remove all files in {self.install_dir}
pause
rmdir /s /q "{self.install_dir}"
echo RGDL V3.2 has been uninstalled.
pause
'''
            else:
                uninstaller_path = os.path.join(self.install_dir, 'uninstall.sh')
                uninstaller_content = f'''#!/bin/bash
echo "Uninstalling RGDL V3.2 Professional..."
echo "This will remove all files in {self.install_dir}"
read -p "Continue? (y/N): " confirm
if [[ $confirm == [yY] ]]; then
    rm -rf "{self.install_dir}"
    echo "RGDL V3.2 has been uninstalled."
else
    echo "Uninstallation cancelled."
fi
'''
                
            with open(uninstaller_path, 'w') as f:
                f.write(uninstaller_content)
                
            if self.platform_system != 'windows':
                os.chmod(uninstaller_path, 0o755)
                
            self.log("Uninstaller created successfully")
            return True
            
        except Exception as e:
            self.log(f"ERROR: Failed to create uninstaller: {e}", "ERROR")
            return False
            
    def test_installation(self):
        """Test the installation"""
        self.log("Testing installation...")
        
        try:
            # Test Python environment
            result = subprocess.run([
                self.get_venv_python(), '-c', 
                'import numpy, scipy, matplotlib; print("Dependencies OK")'
            ], capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                self.log("Python environment test passed")
            else:
                self.log(f"Python environment test failed: {result.stderr}", "ERROR")
                return False
                
            # Test application import
            test_script = f'''
import sys
sys.path.insert(0, "{self.app_dir}")
try:
    import rgdl_v3_2_plugin_system
    print("Plugin system import OK")
except ImportError as e:
    print(f"Plugin system import failed: {{e}}")
    sys.exit(1)
'''
            
            result = subprocess.run([
                self.get_venv_python(), '-c', test_script
            ], capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                self.log("Application import test passed")
            else:
                self.log(f"Application import test failed: {result.stderr}", "WARNING")
                
            self.log("Installation test completed")
            return True
            
        except Exception as e:
            self.log(f"ERROR: Installation test failed: {e}", "ERROR")
            return False
            
    def save_installation_log(self):
        """Save installation log"""
        log_path = os.path.join(self.install_dir, 'logs', 'installation.log')
        
        try:
            with open(log_path, 'w') as f:
                f.write(f"RGDL V3.2 Installation Log\\n")
                f.write(f"Installation Date: {__import__('datetime').datetime.now()}\\n")
                f.write(f"Platform: {self.platform_system}\\n")
                f.write(f"Python Version: {self.python_version}\\n")
                f.write(f"Installation Directory: {self.install_dir}\\n\\n")
                
                for entry in self.installation_log:
                    f.write(entry + '\\n')
                    
            self.log(f"Installation log saved to {log_path}")
            
        except Exception as e:
            self.log(f"WARNING: Could not save installation log: {e}", "WARNING")
            
    def run_installation(self):
        """Run the complete installation process"""
        print("=" * 60)
        print("RGDL V3.2 Professional Installation")
        print("Universal Binary Principle Engineering Platform")
        print("=" * 60)
        
        # Pre-installation checks
        if not self.check_python_version():
            return False
            
        if not self.check_system_requirements():
            return False
            
        # Get installation preferences
        if not self.get_installation_directory():
            return False
            
        print(f"\\nInstalling RGDL V3.2 to: {self.install_dir}")
        confirm = input("Continue with installation? (y/N): ").strip().lower()
        if confirm != 'y':
            print("Installation cancelled.")
            return False
            
        # Installation steps
        steps = [
            ("Creating installation directory", self.create_installation_directory),
            ("Creating virtual environment", self.create_virtual_environment),
            ("Installing system dependencies", self.install_system_dependencies),
            ("Installing Python dependencies", self.install_python_dependencies),
            ("Copying application files", self.copy_application_files),
            ("Creating launcher scripts", self.create_launcher_scripts),
            ("Creating configuration files", self.create_configuration_files),
            ("Creating uninstaller", self.create_uninstaller),
            ("Testing installation", self.test_installation)
        ]
        
        for step_name, step_function in steps:
            print(f"\\n{step_name}...")
            if not step_function():
                print(f"Installation failed at step: {step_name}")
                return False
                
        # Save installation log
        self.save_installation_log()
        
        # Installation complete
        print("\\n" + "=" * 60)
        print("INSTALLATION COMPLETED SUCCESSFULLY!")
        print("=" * 60)
        print(f"RGDL V3.2 has been installed to: {self.install_dir}")
        print(f"\\nTo start RGDL V3.2:")
        
        if self.platform_system == 'windows':
            print(f"  Double-click: {os.path.join(self.install_dir, 'RGDL_V3_2.bat')}")
        else:
            print(f"  Run: {os.path.join(self.install_dir, 'RGDL_V3_2.sh')}")
            
        print(f"\\nDocumentation: {os.path.join(self.install_dir, 'docs')}")
        print(f"Examples: {os.path.join(self.install_dir, 'examples')}")
        print(f"Logs: {os.path.join(self.install_dir, 'logs')}")
        
        return True


class RGDLPackageBuilder:
    """
    Build distribution packages for RGDL V3.2
    """
    
    def __init__(self):
        self.version = "3.2.0"
        self.build_dir = "build"
        self.dist_dir = "dist"
        
    def create_source_package(self):
        """Create source distribution package"""
        print("Creating source package...")
        
        # Create build directory
        os.makedirs(self.build_dir, exist_ok=True)
        os.makedirs(self.dist_dir, exist_ok=True)
        
        # Package name
        package_name = f"RGDL_V3_2_Professional_{self.version}_Source"
        package_dir = os.path.join(self.build_dir, package_name)
        
        # Create package directory
        os.makedirs(package_dir, exist_ok=True)
        
        # Copy files
        files_to_copy = [
            'rgdl_v3_2_fea_engine.py',
            'rgdl_v3_2_assembly_analyzer.py',
            'rgdl_v3_2_import_system.py',
            'rgdl_v3_2_professional_gui.py',
            'rgdl_v3_2_plugin_system.py',
            'rgdl_v3_measurement_system.py',
            'rgdl_v3_unfolding_plugin.py',
            'rgdl_v3_2_installer.py'
        ]
        
        for filename in files_to_copy:
            if os.path.exists(filename):
                shutil.copy2(filename, package_dir)
                
        # Create archive
        archive_path = os.path.join(self.dist_dir, f"{package_name}.zip")
        shutil.make_archive(archive_path[:-4], 'zip', self.build_dir, package_name)
        
        print(f"Source package created: {archive_path}")
        return archive_path
        
    def create_installer_package(self):
        """Create installer package with embedded dependencies"""
        print("Creating installer package...")
        
        # This would create a self-extracting installer
        # For now, we'll create a comprehensive package
        
        package_name = f"RGDL_V3_2_Professional_{self.version}_Installer"
        package_dir = os.path.join(self.build_dir, package_name)
        
        os.makedirs(package_dir, exist_ok=True)
        
        # Copy installer and all files
        installer_content = '''#!/usr/bin/env python3
"""
RGDL V3.2 Professional Self-Extracting Installer
"""

import os
import sys

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import and run installer
from rgdl_v3_2_installer import RGDLInstaller

if __name__ == "__main__":
    installer = RGDLInstaller()
    installer.run_installation()
'''
        
        with open(os.path.join(package_dir, 'install.py'), 'w') as f:
            f.write(installer_content)
            
        # Copy all application files
        app_files = [
            'rgdl_v3_2_fea_engine.py',
            'rgdl_v3_2_assembly_analyzer.py',
            'rgdl_v3_2_import_system.py',
            'rgdl_v3_2_professional_gui.py',
            'rgdl_v3_2_plugin_system.py',
            'rgdl_v3_measurement_system.py',
            'rgdl_v3_unfolding_plugin.py',
            'rgdl_v3_2_installer.py'
        ]
        
        for filename in app_files:
            if os.path.exists(filename):
                shutil.copy2(filename, package_dir)
                
        # Create README for installer
        readme_content = '''# RGDL V3.2 Professional Installer

## Installation Instructions

### Windows:
1. Extract this package to a temporary directory
2. Open Command Prompt as Administrator
3. Navigate to the extracted directory
4. Run: python install.py

### Linux/macOS:
1. Extract this package to a temporary directory
2. Open terminal
3. Navigate to the extracted directory
4. Run: python3 install.py

## System Requirements

- Python 3.8 or higher
- 500MB free disk space
- Internet connection (for dependencies)

## Features

- Automatic virtual environment creation
- Dependency management
- Desktop shortcuts (Linux)
- Uninstaller included
- Plugin architecture
- Professional GUI interface

## Support

For support and documentation, visit the installation directory after setup.
'''
        
        with open(os.path.join(package_dir, 'README.txt'), 'w') as f:
            f.write(readme_content)
            
        # Create archive
        archive_path = os.path.join(self.dist_dir, f"{package_name}.zip")
        shutil.make_archive(archive_path[:-4], 'zip', self.build_dir, package_name)
        
        print(f"Installer package created: {archive_path}")
        return archive_path


# Main execution
if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == '--build-package':
        # Build distribution packages
        builder = RGDLPackageBuilder()
        source_pkg = builder.create_source_package()
        installer_pkg = builder.create_installer_package()
        
        print("\\nPackage building completed:")
        print(f"Source package: {source_pkg}")
        print(f"Installer package: {installer_pkg}")
        
    else:
        # Run installer
        installer = RGDLInstaller()
        success = installer.run_installation()
        
        if success:
            print("\\nInstallation completed successfully!")
            sys.exit(0)
        else:
            print("\\nInstallation failed!")
            sys.exit(1)

