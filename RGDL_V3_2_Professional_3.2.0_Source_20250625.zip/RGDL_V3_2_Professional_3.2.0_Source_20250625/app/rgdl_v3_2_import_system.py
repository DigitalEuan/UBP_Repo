"""
RGDL V3.2 Professional - Import System (Corrected)
Universal Binary Principle Engineering Platform
"""

import numpy as np
import json
import os
from typing import Dict, List, Tuple, Optional, Any

class DXFImporter:
    """Import DXF files and convert to RGDL geometry"""
    
    def __init__(self):
        self.entities = []
        self.layers = {}
        self.blocks = {}
        
    def import_dxf(self, filepath):
        """Import DXF file"""
        print(f"Importing DXF file: {filepath}")
        
        if not os.path.exists(filepath):
            print(f"Error: File {filepath} not found")
            return False
        
        try:
            # Simplified DXF parsing - real implementation would use ezdxf or similar
            with open(filepath, 'r') as f:
                content = f.read()
            
            # Parse basic DXF structure
            self._parse_dxf_content(content)
            
            print(f"DXF imported successfully: {len(self.entities)} entities")
            return True
            
        except Exception as e:
            print(f"Error importing DXF: {e}")
            return False
    
    def _parse_dxf_content(self, content):
        """Parse DXF content (simplified)"""
        lines = content.split('\n')
        current_entity = None
        
        for i, line in enumerate(lines):
            line = line.strip()
            
            if line == "LINE":
                current_entity = {"type": "line", "points": []}
            elif line == "CIRCLE":
                current_entity = {"type": "circle", "center": None, "radius": None}
            elif line == "ARC":
                current_entity = {"type": "arc", "center": None, "radius": None, "angles": []}
            elif line.startswith("10") and current_entity:  # X coordinate
                if i + 1 < len(lines):
                    x = float(lines[i + 1].strip())
                    if "points" in current_entity:
                        current_entity["points"].append([x, 0, 0])
            elif current_entity and line == "0":  # End of entity
                if current_entity:
                    self.entities.append(current_entity)
                current_entity = None
    
    def convert_to_bitfield(self, bitfield_dims, resolution):
        """Convert DXF entities to bitfield representation"""
        bitfield = np.zeros(bitfield_dims, dtype=bool)
        
        for entity in self.entities:
            if entity["type"] == "line":
                self._rasterize_line(entity, bitfield, resolution)
            elif entity["type"] == "circle":
                self._rasterize_circle(entity, bitfield, resolution)
        
        return bitfield
    
    def _rasterize_line(self, line_entity, bitfield, resolution):
        """Rasterize line into bitfield"""
        if len(line_entity["points"]) >= 2:
            start = line_entity["points"][0]
            end = line_entity["points"][1]
            
            # Simple line rasterization
            steps = int(np.linalg.norm(np.array(end) - np.array(start)) / resolution) + 1
            for i in range(steps):
                t = i / max(1, steps - 1)
                point = np.array(start) * (1 - t) + np.array(end) * t
                
                # Convert to bitfield indices
                x_idx = int(point[0] / resolution)
                y_idx = int(point[1] / resolution)
                z_idx = int(point[2] / resolution)
                
                if (0 <= x_idx < bitfield.shape[0] and 
                    0 <= y_idx < bitfield.shape[1] and 
                    0 <= z_idx < bitfield.shape[2]):
                    bitfield[x_idx, y_idx, z_idx] = True
    
    def _rasterize_circle(self, circle_entity, bitfield, resolution):
        """Rasterize circle into bitfield"""
        # Simplified circle rasterization
        if circle_entity["center"] and circle_entity["radius"]:
            center = circle_entity["center"]
            radius = circle_entity["radius"]
            
            # Generate circle points
            n_points = int(2 * np.pi * radius / resolution) + 1
            for i in range(n_points):
                angle = 2 * np.pi * i / n_points
                x = center[0] + radius * np.cos(angle)
                y = center[1] + radius * np.sin(angle)
                z = center[2]
                
                # Convert to bitfield indices
                x_idx = int(x / resolution)
                y_idx = int(y / resolution)
                z_idx = int(z / resolution)
                
                if (0 <= x_idx < bitfield.shape[0] and 
                    0 <= y_idx < bitfield.shape[1] and 
                    0 <= z_idx < bitfield.shape[2]):
                    bitfield[x_idx, y_idx, z_idx] = True


class STLImporter:
    """Import STL files and convert to RGDL geometry"""
    
    def __init__(self):
        self.vertices = []
        self.faces = []
        self.normals = []
        
    def import_stl(self, filepath):
        """Import STL file"""
        print(f"Importing STL file: {filepath}")
        
        if not os.path.exists(filepath):
            print(f"Error: File {filepath} not found")
            return False
        
        try:
            if filepath.lower().endswith('.stl'):
                return self._import_ascii_stl(filepath)
            else:
                print("Error: Unsupported file format")
                return False
                
        except Exception as e:
            print(f"Error importing STL: {e}")
            return False
    
    def _import_ascii_stl(self, filepath):
        """Import ASCII STL file"""
        vertices = []
        faces = []
        normals = []
        
        with open(filepath, 'r') as f:
            lines = f.readlines()
        
        current_face_vertices = []
        current_normal = None
        
        for line in lines:
            line = line.strip()
            
            if line.startswith('facet normal'):
                parts = line.split()
                if len(parts) >= 4:
                    current_normal = [float(parts[2]), float(parts[3]), float(parts[4])]
                    
            elif line.startswith('vertex'):
                parts = line.split()
                if len(parts) >= 4:
                    vertex = [float(parts[1]), float(parts[2]), float(parts[3])]
                    vertices.append(vertex)
                    current_face_vertices.append(len(vertices) - 1)
                    
            elif line.startswith('endfacet'):
                if len(current_face_vertices) == 3 and current_normal:
                    faces.append(current_face_vertices.copy())
                    normals.append(current_normal)
                current_face_vertices = []
                current_normal = None
        
        self.vertices = np.array(vertices)
        self.faces = np.array(faces)
        self.normals = np.array(normals)
        
        print(f"STL imported: {len(self.vertices)} vertices, {len(self.faces)} faces")
        return True
    
    def convert_to_bitfield(self, bitfield_dims, resolution):
        """Convert STL mesh to bitfield representation"""
        bitfield = np.zeros(bitfield_dims, dtype=bool)
        
        # Voxelize the mesh
        for face in self.faces:
            if len(face) >= 3:
                v1 = self.vertices[face[0]]
                v2 = self.vertices[face[1]]
                v3 = self.vertices[face[2]]
                
                self._rasterize_triangle(v1, v2, v3, bitfield, resolution)
        
        return bitfield
    
    def _rasterize_triangle(self, v1, v2, v3, bitfield, resolution):
        """Rasterize triangle into bitfield"""
        # Simple triangle rasterization
        # Find bounding box
        min_coords = np.minimum(np.minimum(v1, v2), v3)
        max_coords = np.maximum(np.maximum(v1, v2), v3)
        
        # Convert to bitfield indices
        min_idx = (min_coords / resolution).astype(int)
        max_idx = (max_coords / resolution).astype(int) + 1
        
        # Clamp to bitfield bounds
        min_idx = np.maximum(min_idx, 0)
        max_idx = np.minimum(max_idx, bitfield.shape)
        
        # Fill triangle area (simplified)
        for x in range(min_idx[0], max_idx[0]):
            for y in range(min_idx[1], max_idx[1]):
                for z in range(min_idx[2], max_idx[2]):
                    if (x < bitfield.shape[0] and y < bitfield.shape[1] and z < bitfield.shape[2]):
                        bitfield[x, y, z] = True


class CustomShapeBuilder:
    """Build custom parametric shapes"""
    
    def __init__(self):
        self.available_shapes = [
            "parametric_beam",
            "parametric_plate", 
            "parametric_cylinder",
            "parametric_torus",
            "parametric_helix",
            "parametric_gear",
            "parametric_spring",
            "parametric_bracket"
        ]
        
    def get_available_shapes(self):
        """Get list of available custom shapes"""
        return self.available_shapes.copy()
    
    def create_parametric_shape(self, shape_type, parameters, bitfield_dims, resolution):
        """Create parametric shape in bitfield"""
        print(f"Creating custom shape: {shape_type}")
        
        if shape_type not in self.available_shapes:
            print(f"Error: Unknown shape type {shape_type}")
            return None
        
        bitfield = np.zeros(bitfield_dims, dtype=bool)
        
        if shape_type == "parametric_beam":
            return self._create_beam(parameters, bitfield, resolution)
        elif shape_type == "parametric_plate":
            return self._create_plate(parameters, bitfield, resolution)
        elif shape_type == "parametric_cylinder":
            return self._create_cylinder(parameters, bitfield, resolution)
        elif shape_type == "parametric_gear":
            return self._create_gear(parameters, bitfield, resolution)
        elif shape_type == "parametric_spring":
            return self._create_spring(parameters, bitfield, resolution)
        else:
            # Default simple shape
            return self._create_simple_shape(parameters, bitfield, resolution)
    
    def _create_beam(self, params, bitfield, resolution):
        """Create parametric beam"""
        length = params.get('length', 0.1)
        width = params.get('width', 0.02)
        height = params.get('height', 0.01)
        center = params.get('center', [0.05, 0.05, 0.05])
        
        # Convert to bitfield indices
        center_idx = np.array(center) / resolution
        length_idx = int(length / resolution)
        width_idx = int(width / resolution)
        height_idx = int(height / resolution)
        
        # Fill beam volume
        start_x = int(center_idx[0] - length_idx // 2)
        end_x = int(center_idx[0] + length_idx // 2)
        start_y = int(center_idx[1] - width_idx // 2)
        end_y = int(center_idx[1] + width_idx // 2)
        start_z = int(center_idx[2] - height_idx // 2)
        end_z = int(center_idx[2] + height_idx // 2)
        
        for x in range(max(0, start_x), min(bitfield.shape[0], end_x)):
            for y in range(max(0, start_y), min(bitfield.shape[1], end_y)):
                for z in range(max(0, start_z), min(bitfield.shape[2], end_z)):
                    bitfield[x, y, z] = True
        
        active_voxels = np.sum(bitfield)
        print(f"Custom shape created successfully")
        print(f"Created beam with {active_voxels} active voxels")
        return bitfield
    
    def _create_plate(self, params, bitfield, resolution):
        """Create parametric plate"""
        length = params.get('length', 0.1)
        width = params.get('width', 0.08)
        thickness = params.get('thickness', 0.005)
        center = params.get('center', [0.05, 0.05, 0.05])
        
        return self._create_beam({
            'length': length,
            'width': width, 
            'height': thickness,
            'center': center
        }, bitfield, resolution)
    
    def _create_cylinder(self, params, bitfield, resolution):
        """Create parametric cylinder"""
        radius = params.get('radius', 0.02)
        height = params.get('height', 0.08)
        center = params.get('center', [0.05, 0.05, 0.05])
        
        center_idx = np.array(center) / resolution
        radius_idx = radius / resolution
        height_idx = int(height / resolution)
        
        start_z = int(center_idx[2] - height_idx // 2)
        end_z = int(center_idx[2] + height_idx // 2)
        
        for x in range(bitfield.shape[0]):
            for y in range(bitfield.shape[1]):
                for z in range(max(0, start_z), min(bitfield.shape[2], end_z)):
                    dx = x - center_idx[0]
                    dy = y - center_idx[1]
                    distance = np.sqrt(dx*dx + dy*dy)
                    
                    if distance <= radius_idx:
                        bitfield[x, y, z] = True
        
        active_voxels = np.sum(bitfield)
        print(f"Custom shape created successfully")
        print(f"Created cylinder with {active_voxels} active voxels")
        return bitfield
    
    def _create_gear(self, params, bitfield, resolution):
        """Create parametric gear"""
        outer_radius = params.get('outer_radius', 0.03)
        inner_radius = params.get('inner_radius', 0.01)
        thickness = params.get('thickness', 0.01)
        teeth = params.get('teeth', 12)
        center = params.get('center', [0.05, 0.05, 0.05])
        
        center_idx = np.array(center) / resolution
        outer_radius_idx = outer_radius / resolution
        inner_radius_idx = inner_radius / resolution
        thickness_idx = int(thickness / resolution)
        
        start_z = int(center_idx[2] - thickness_idx // 2)
        end_z = int(center_idx[2] + thickness_idx // 2)
        
        for x in range(bitfield.shape[0]):
            for y in range(bitfield.shape[1]):
                for z in range(max(0, start_z), min(bitfield.shape[2], end_z)):
                    dx = x - center_idx[0]
                    dy = y - center_idx[1]
                    distance = np.sqrt(dx*dx + dy*dy)
                    angle = np.arctan2(dy, dx)
                    
                    # Create gear teeth
                    tooth_angle = 2 * np.pi / teeth
                    tooth_phase = (angle % tooth_angle) / tooth_angle
                    
                    if tooth_phase < 0.5:  # Tooth
                        max_radius = outer_radius_idx
                    else:  # Gap
                        max_radius = outer_radius_idx * 0.8
                    
                    if inner_radius_idx <= distance <= max_radius:
                        bitfield[x, y, z] = True
        
        active_voxels = np.sum(bitfield)
        print(f"Custom shape created successfully")
        print(f"Created gear with {active_voxels} active voxels")
        return bitfield
    
    def _create_spring(self, params, bitfield, resolution):
        """Create parametric spring"""
        radius = params.get('radius', 0.02)
        pitch = params.get('pitch', 0.01)
        turns = params.get('turns', 5)
        wire_radius = params.get('wire_radius', 0.002)
        center = params.get('center', [0.05, 0.05, 0.05])
        
        center_idx = np.array(center) / resolution
        radius_idx = radius / resolution
        wire_radius_idx = wire_radius / resolution
        total_height = turns * pitch
        height_idx = int(total_height / resolution)
        
        start_z = int(center_idx[2] - height_idx // 2)
        
        # Generate spring helix
        n_points = int(turns * 50)  # Points along helix
        for i in range(n_points):
            t = i / n_points
            angle = 2 * np.pi * turns * t
            
            # Helix center line
            helix_x = center_idx[0] + radius_idx * np.cos(angle)
            helix_y = center_idx[1] + radius_idx * np.sin(angle)
            helix_z = start_z + t * height_idx
            
            # Fill wire cross-section
            for dx in range(-int(wire_radius_idx), int(wire_radius_idx) + 1):
                for dy in range(-int(wire_radius_idx), int(wire_radius_idx) + 1):
                    for dz in range(-int(wire_radius_idx), int(wire_radius_idx) + 1):
                        if dx*dx + dy*dy + dz*dz <= wire_radius_idx*wire_radius_idx:
                            x = int(helix_x + dx)
                            y = int(helix_y + dy)
                            z = int(helix_z + dz)
                            
                            if (0 <= x < bitfield.shape[0] and 
                                0 <= y < bitfield.shape[1] and 
                                0 <= z < bitfield.shape[2]):
                                bitfield[x, y, z] = True
        
        active_voxels = np.sum(bitfield)
        print(f"Custom shape created successfully")
        print(f"Created spring with {active_voxels} active voxels")
        return bitfield
    
    def _create_simple_shape(self, params, bitfield, resolution):
        """Create simple default shape"""
        size = params.get('size', 0.05)
        center = params.get('center', [0.05, 0.05, 0.05])
        
        return self._create_beam({
            'length': size,
            'width': size,
            'height': size,
            'center': center
        }, bitfield, resolution)


class ImportSystem:
    """
    Main import system class that coordinates all importers
    """
    
    def __init__(self):
        self.dxf_importer = DXFImporter()
        self.stl_importer = STLImporter()
        self.shape_builder = CustomShapeBuilder()
        
    def import_file(self, filepath, file_type=None):
        """Import file based on extension or specified type"""
        if file_type is None:
            file_type = os.path.splitext(filepath)[1].lower()
        
        if file_type in ['.dxf']:
            return self.dxf_importer.import_dxf(filepath)
        elif file_type in ['.stl']:
            return self.stl_importer.import_stl(filepath)
        else:
            print(f"Unsupported file type: {file_type}")
            return False
    
    def convert_to_bitfield(self, bitfield_dims, resolution, source_type="auto"):
        """Convert imported data to bitfield"""
        if source_type == "dxf" or (source_type == "auto" and self.dxf_importer.entities):
            return self.dxf_importer.convert_to_bitfield(bitfield_dims, resolution)
        elif source_type == "stl" or (source_type == "auto" and len(self.stl_importer.vertices) > 0):
            return self.stl_importer.convert_to_bitfield(bitfield_dims, resolution)
        else:
            print("No imported data to convert")
            return None
    
    def create_custom_shape(self, shape_type, parameters, bitfield_dims, resolution):
        """Create custom parametric shape"""
        return self.shape_builder.create_parametric_shape(shape_type, parameters, bitfield_dims, resolution)
    
    def get_available_shapes(self):
        """Get list of available custom shapes"""
        return self.shape_builder.get_available_shapes()


# Test and demonstration
if __name__ == "__main__":
    print("RGDL V3.2 Import and Custom Shape System (Corrected)")
    print("=" * 60)
    
    # Create import system
    import_system = ImportSystem()
    
    print("DXF Importer initialized")
    print("STL Importer initialized") 
    print("Custom Shape Builder initialized")
    
    print(f"\nAvailable custom shapes:")
    for shape in import_system.get_available_shapes():
        print(f"  - {shape}")
    
    # Test custom shape creation
    bitfield_dims = (100, 100, 50)
    resolution = 0.001  # 1mm
    
    # Create gear
    gear_params = {
        'outer_radius': 0.03,
        'inner_radius': 0.01,
        'thickness': 0.01,
        'teeth': 12,
        'center': [0.05, 0.05, 0.025]
    }
    
    gear_bitfield = import_system.create_custom_shape("parametric_gear", gear_params, bitfield_dims, resolution)
    
    # Create spring
    spring_params = {
        'radius': 0.02,
        'pitch': 0.01,
        'turns': 5,
        'wire_radius': 0.002,
        'center': [0.05, 0.05, 0.025]
    }
    
    spring_bitfield = import_system.create_custom_shape("parametric_spring", spring_params, bitfield_dims, resolution)
    
    print("\nImport and Custom Shape System ready for use")

