#!/usr/bin/env python3
"""
RGDL V3.2 Professional Installer
Universal Binary Principle Engineering Platform
"""

import os
import sys
import subprocess
from pathlib import Path

def main():
    print("=" * 60)
    print("RGDL V3.2 Professional Installation")
    print("Universal Binary Principle Engineering Platform")
    print("=" * 60)
    
    # Check Python version
    if sys.version_info < (3, 8):
        print("ERROR: Python 3.8 or higher is required")
        print(f"Current version: {sys.version}")
        return False
        
    # Import and run installer
    try:
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'app'))
        from rgdl_v3_2_installer import RGDLInstaller
        
        installer = RGDLInstaller()
        return installer.run_installation()
        
    except ImportError as e:
        print(f"ERROR: Could not import installer: {e}")
        print("Please ensure all files are present and try again.")
        return False
    except Exception as e:
        print(f"ERROR: Installation failed: {e}")
        return False

if __name__ == "__main__":
    success = main()
    if success:
        print("\nInstallation completed successfully!")
        input("Press Enter to exit...")
    else:
        print("\nInstallation failed!")
        input("Press Enter to exit...")
    sys.exit(0 if success else 1)
