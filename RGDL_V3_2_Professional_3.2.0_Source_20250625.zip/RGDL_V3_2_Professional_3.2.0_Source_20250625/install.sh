#!/bin/bash
echo "RGDL V3.2 Professional Installation"
echo "==================================="
echo
python3 install.py
read -p "Press Enter to exit..."
