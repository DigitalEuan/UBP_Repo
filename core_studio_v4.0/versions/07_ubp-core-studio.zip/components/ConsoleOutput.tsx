
import React, { useEffect, useRef } from 'react';

interface ConsoleOutputProps {
  output: string;
  hideHeader?: boolean;
}

export const ConsoleOutput: React.FC<ConsoleOutputProps> = ({ output, hideHeader }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [output]);

  return (
    <div className="flex flex-col h-full bg-black border border-gray-800 rounded-lg overflow-hidden font-mono shadow-inner">
      {!hideHeader && (
        <div className="px-4 py-2 bg-gray-900 border-b border-gray-800 flex justify-between items-center">
          <span className="text-xs uppercase tracking-wider text-gray-500 font-bold">System Output</span>
          <div className="flex gap-2">
              <div className="w-2 h-2 rounded-full bg-red-500 opacity-50"></div>
              <div className="w-2 h-2 rounded-full bg-yellow-500 opacity-50"></div>
              <div className="w-2 h-2 rounded-full bg-green-500 opacity-50"></div>
          </div>
        </div>
      )}
      <div 
        ref={scrollRef}
        className="flex-1 p-4 overflow-y-auto whitespace-pre-wrap text-sm text-green-400 font-medium"
      >
        {output || <span className="text-gray-600 italic">Ready for execution...</span>}
      </div>
    </div>
  );
};
