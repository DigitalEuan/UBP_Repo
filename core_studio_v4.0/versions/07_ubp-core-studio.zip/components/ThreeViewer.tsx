import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { Scene3DData } from '../types';

interface ThreeViewerProps {
  data: Scene3DData;
}

export const ThreeViewer: React.FC<ThreeViewerProps> = ({ data }) => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!mountRef.current) return;

    // Setup Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x111111);
    
    // Add grid/axes for context
    const gridHelper = new THREE.GridHelper(20, 20, 0x444444, 0x222222);
    scene.add(gridHelper);
    const axesHelper = new THREE.AxesHelper(2);
    scene.add(axesHelper);

    // Setup Camera
    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight;
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    camera.position.set(5, 5, 5);

    // Setup Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    mountRef.current.appendChild(renderer.domElement);

    // Setup Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(5, 10, 7);
    scene.add(dirLight);

    // --- Parse and Add Data ---

    // Points
    if (data.points) {
        const geometry = new THREE.BufferGeometry();
        const positions: number[] = [];
        const colors: number[] = [];
        const sizes: number[] = [];
        
        data.points.forEach(p => {
            positions.push(p.x, p.y, p.z);
            const c = new THREE.Color(p.color || '#ffffff');
            colors.push(c.r, c.g, c.b);
            sizes.push(p.size || 0.2); // Not directly supported by PointsMaterial sizeAttenuation without shader, using uniform size for simplicity or specialized mapping
        });

        geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

        const material = new THREE.PointsMaterial({ 
            size: 0.2, 
            vertexColors: true,
            sizeAttenuation: true 
        });
        const pointsObj = new THREE.Points(geometry, material);
        scene.add(pointsObj);
    }

    // Lines
    if (data.lines) {
        data.lines.forEach(line => {
             const points = [];
             points.push(new THREE.Vector3(...line.start));
             points.push(new THREE.Vector3(...line.end));
             const geometry = new THREE.BufferGeometry().setFromPoints(points);
             const material = new THREE.LineBasicMaterial({ color: line.color || '#ffffff' });
             const lineObj = new THREE.Line(geometry, material);
             scene.add(lineObj);
        });
    }

    // Spheres
    if (data.spheres) {
        data.spheres.forEach(s => {
            const geometry = new THREE.SphereGeometry(s.r, 16, 16);
            const material = new THREE.MeshStandardMaterial({ color: s.color || '#ffffff' });
            const sphere = new THREE.Mesh(geometry, material);
            sphere.position.set(s.x, s.y, s.z);
            scene.add(sphere);
        });
    }

    // --- Animation Loop ---
    let animationId: number;
    const animate = () => {
      animationId = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Handle Resize
    const handleResize = () => {
        if (!mountRef.current) return;
        const w = mountRef.current.clientWidth;
        const h = mountRef.current.clientHeight;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationId);
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
      // Dispose geometries/materials to avoid leaks would go here in full prod
    };
  }, [data]);

  return <div ref={mountRef} className="w-full h-full relative" />;
};