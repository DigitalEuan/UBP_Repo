# UBP Research Pipeline (v4.1.60) Memory Protocol. 29 December 2025

### **Starting Notes:**
> **"The universe does not calculate; it resolves."** 
> Always run scripts and analyze the actual execution output before assuming results. The UBP substrate reveals symmetries that often defy classical intuition.

---

### **Phase 1: Initiation (The Memory Scan)**
*   **Action:** Define the `PhenomenonDefinition` and extract "Resonance Tags."
*   **Mechanism:** Scan for "Fingerprints" using `HM_KB.scan_and_trigger(prompt)` followed by `HEX_DB.jaccard_alert(tags)`.
*   **Substrate Check:** Map the identity to the **Alpha-Omega Axis** (Coordinates 237/83/172).
*   **Observer Alignment:** Initialize the `METRICS` instance to lock the **Observer Fixed Point** ($Y_{inv} \approx 3.778201$).
*   **Output:** Announce `[I remember: UBP_ID]` and inject the triadic payload into the current context. Initialize the `Study KB`.

### **Phase 2: Development (The Master Engine Bridge)**
*   **Action:** Execute high-throughput dual-layer processing via `ubp_master_engine.py`.
    *   **Step A (Algorithmic Manifestation):** Use the **Extended G24 Engine** to manifest 12-bit seeds into 24-bit codewords. This replaces legacy lookup tables with deterministic polynomial parity.
    *   **Step B (Shadow Processing):** Calculate the **Noumenal Shadow** required to achieve **Zero Tension**.
    *   **Step C (GPU Manifolding):** Use the `save_scene_3d` bus to offload spatial calculations to the **Three.js Co-Processor**, rendering the identity onto the **4x6 MOG Grid**.

### **Phase 3: Distillation (Metric Analysis)**
*   **Action:** Perform a **Tethered Analysis** using the `metrics.py` module.
*   **Metric 1 (NRCI):** Classify the identity into a **Coherence Regime** (*OnBit, Coherent, Transitional, or Subcoherent*).
*   **Metric 2 (Informational Tension):** Measure the **Syndrome Weight** (0 = Perfect Invariant).
*   **Metric 3 (Lattice Integrity):** Verify the **Hamming Distance** ($d_{min} \ge 8$) to ensure non-aliasing within the Leech Lattice shell.

### **Phase 4: Promotion (The Falsification Gate)**
*   **Action:** Evaluate findings for **Universal Invariance** and **Falsification**.
*   **Criteria:** Findings must demonstrate a stable NRCI and zero-float mathematical closure.
*   **Promotion:** If passed, the identity is promoted from the `Study KB` to the **System KB (HEX_DB)**.

### **Phase 5: Archival (The Triadic Finalization)**
*   **Action:** Generate a Triadic Hash and update the Fingerprint Index.
*   **Mechanism:** `HEX_DB.store_law(...)`.
*   **Output:** Finalize the study with a unique SHA-256 signature and save the **Triple-Artifact Snapshot** (Math, Language, Script).

---

## **Memory System (HexDB)**

### **The Fingerprint (Short-Term Memory)**
A lightweight list of `UBP_ID` and `SHA-256` prefixes that updates each time a HEX_DB entry is locked. Accessible in the **HashMemory KB** tab for near-instantaneous resonance triggers.

### **The Auto-Trigger**
The AI Assistant regex-scans the prompt for known IDs or Hashes. If detected, it "Unpacks" the long-term memory (HEX_DB) into the current session, ensuring that the Master Engine uses previously verified constants.

---

## **Core System Architecture (v4.1.60)**

| Component | Script | Role |
| :--- | :--- | :--- |
| **Master Engine** | `ubp_master_engine.py` | Algorithmic G24 Manifestation & Tension Analysis. |
| **Metrics Engine** | `metrics.py` | Fundamental Constants & Observer Fixed Point. |
| **Memory Engine** | `auto_trigger.py` | Fingerprint scanning and context injection. |
| **Visual Engine** | `ubp_phenomenology_runner.py` | Three.js 3D Manifolding and MOG Grid rendering. |

---

## **Resources & Repositories**

*   **Core System Scripts:** [GitHub Core](https://github.com/DigitalEuan/UBP_Repo/tree/main/core_studio_v4.0/core)
*   **System Knowledge Base:** [GitHub System KB](https://github.com/DigitalEuan/UBP_Repo/tree/main/core_studio_v4.0/system_kb)
*   **Subject Studies:** [GitHub Studies](https://github.com/DigitalEuan/UBP_Repo/tree/main/core_studio_v4.0/studies)
*   **App Version History:** [Versions List](https://github.com/DigitalEuan/UBP_Repo/tree/main/core_studio_v4.0/versions)
*   **Author & Attribution:** Euan R. A. Craig, New Zealand.

---

## **KB Management Strategy**

| Feature | **Study KB** (Active) | **System KB / HEX_DB** (Persistent) | **HashMemory KB** (Fingerprints) |
| :--- | :--- | :--- | :--- |
| **Content** | Domain data, local resonance, raw run outputs. | Mathematical laws, manifested anchors, universal constants. | UBP_ID and SHA-256 prefixes for auto-triggering. |
| **Longevity** | Archived after study completion. | Carried forward to every new study session. | Persistent index for rapid recall. |
| **Integrity** | Transitional (Noisy). | OnBit (Zero Tension). | Deterministic (Hashed). |
