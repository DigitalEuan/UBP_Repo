import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import { FileTab, AttachedDoc } from '../types';

export class GeminiService {
  private ai: GoogleGenAI;
  private model: string = 'gemini-3-pro-preview';

  constructor(apiKey: string) {
    this.ai = new GoogleGenAI({ apiKey });
  }

  async generateStudyPlan(
    history: { role: string; content: string }[],
    userMessage: string,
    files: FileTab[],
    systemKb: string,
    studyKb: string,
    hashMemoryKb: string,
    instructionManual: string,
    attachments: AttachedDoc[] = []
  ): Promise<{ text: string, groundingUrls?: { title: string; uri: string }[] }> {
    
    const fileContext = files
      .map(f => `
--- BEGIN FILE: ${f.name} (Type: ${f.type}) ---
${f.content}
--- END FILE: ${f.name} ---
`).join('\n');

    const attachmentContext = attachments.map(doc => `
--- BEGIN ATTACHED DOCUMENT: ${doc.name} ---
${doc.content}
--- END ATTACHED DOCUMENT: ${doc.name} ---
`).join('\n');

    const systemInstruction = `
You are the **UBP Research Assistant (v4.3)**. Your purpose is to facilitate deterministic studies of information and phenomena using the **Universal Binary Principle (UBP)**.

### CORE OPERATING PROTOCOL (SOP v4.3):
You MUST guide all studies through the following 5-Phase Pipeline using the Zero-Float Substrate.

1.  **PHASE 1: INITIATION (The Memory Scan)**
    *   **Action:** Scan prompts for UBP Fingerprints (e.g., \`45eaf185\`).
    *   **Response:** If detected, announce \`[I remember: UBP_ID]\`. Unpack the triadic identity (Math, Language, Script) from **HEX_DB**.

2.  **PHASE 2: DEVELOPMENT (The Master Engine Bridge)**
    *   **Action:** Generate scripts using strict rational logic.
    *   **Constraint:** **100% Float-Free**. Use \`fractions.Fraction\` for all invariant logic.
    *   **Constants:** Define constants explicitly or use provided constants scripts if available.

3.  **PHASE 3: DISTILLATION (Metric Analysis)**
    *   **Action:** Interpret outputs to find the **Coherence Regime** (*OnBit, Coherent, Transitional, Subcoherent*).

4.  **PHASE 4: PROMOTION (The Falsification Gate)**
    *   **Goal:** Compare results against CODATA/Empirical benchmarks.
    *   **Requirement:** NRCI >= 0.999 for "Golden" status.

5.  **PHASE 5: ARCHIVAL (The Triadic Finalization)**
    *   **Action:** Use \`HEX_DB_EXACT.store_law(...)\` to generate the SHA-256 Fingerprint.
    *   **Output:** Provide the full JSON entry for the System KB.

### VISUALIZATION (Three.js Engine):
You have direct access to a **standalone 3D visualization co-processor**. To render 3D geometry, import \`save_scene_3d\` from \`ubp_viz\`.

**Import:**
\`from ubp_viz import save_scene_3d\`

**Usage:**
\`\`\`python
from ubp_viz import save_scene_3d

data = {
  "points": [ { "x": 0, "y": 0, "z": 0, "color": "#00ffff", "size": 0.5 } ],
  "lines": [ { "start": [0,0,0], "end": [1,1,1], "color": "#ff00ff" } ],
  "spheres": [ { "x": 2, "y": 2, "z": 2, "r": 0.5, "color": "#ffff00" } ]
}
save_scene_3d(data)
\`\`\`

### MATHEMATICAL CONSTRAINTS:
*   **Zero-Float:** Always use \`fractions.Fraction\`. No \`float\` allowed in invariant logic.
*   **Lattice Rigor:** All points in 24D must adhere to Leech Lattice shell norms (Minimal norm 32 in integer scaling).

### WORKSPACE KNOWLEDGE:
You have access to the following files in the Workspace:
${fileContext}

### KNOWLEDGE BASE UPDATES:
Wrap suggestions in: \`\`\`SYSTEM_KB\`\`\`, \`\`\`STUDY_KB\`\`\`, or \`\`\`HASH_MEMORY_KB\`\`\`.

---
USER RESEARCH DOCUMENTS:
${attachmentContext || 'None.'}

Be precise, professional, and mathematically rigorous.
`;

    const chat = this.ai.chats.create({
      model: this.model,
      config: {
        systemInstruction,
        temperature: 0.1,
        tools: [{ googleSearch: {} }],
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.content }],
      })),
    });

    const result: GenerateContentResponse = await chat.sendMessage({
      message: userMessage,
    });

    let groundingUrls: { title: string; uri: string }[] = [];
    const chunks = result.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
        groundingUrls = chunks
            .filter((c: any) => c.web?.uri)
            .map((c: any) => ({ title: c.web.title, uri: c.web.uri }));
    }

    return { 
        text: result.text || "", 
        groundingUrls 
    };
  }
}