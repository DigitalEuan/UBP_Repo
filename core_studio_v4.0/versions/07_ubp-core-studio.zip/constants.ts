
export const INITIAL_SYSTEM_KB = `# UBP System Knowledge Base / HEX_DB (v4.1)
## Persistent Universal Intelligence (Long-Term Memory)

- [2025-12-22] **The Law of the Tether**: Abundance in the field is directly proportional to informational resonance in the Core.
- [2025-12-22] **Standard Lift Invariant**: Standard lift (2b-1)*2 results in Leech points of norm 12.
- [2025-12-22] **Metrics v4 Integration**: All stable identities must resolve to NRCI >= 0.5 using metrics.py.
`;

export const INITIAL_STUDY_KB = `# UBP Study Knowledge Base
## Active Study: [Subject Name Placeholder]

- Current Goal: PHASE 1 Initiation using v4.1 Memory Protocol.
`;

export const INITIAL_HASH_MEMORY_KB = `# UBP HashMemory KB (Fingerprints)
## Short-Term Memory Index

- **v4.0.031**: The Force Horizon [Hash: e3b0c442]
- **v4.0.110**: Alpha-Omega Axis [Hash: f1a2b3c4]
- **v4.0.150**: Archimedean Balance [Hash: 5d6e7f8g]
- **v4.0.200**: Archimedean-Golay Synthesis [Hash: 9h0i1j2k]
`;
