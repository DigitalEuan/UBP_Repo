
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import { FileTab, AttachedDoc } from '../types';

export class GeminiService {
  private ai: GoogleGenAI;
  private model: string = 'gemini-3-pro-preview';

  constructor(apiKey: string, model?: string) {
    this.ai = new GoogleGenAI({ apiKey });
    if (model) this.model = model;
  }

  async generateStudyPlan(
    history: { role: string; content: string }[],
    userMessage: string,
    files: FileTab[],
    systemKb: string,
    studyKb: string,
    hashMemoryKb: string,
    instructionManual: string,
    attachments: AttachedDoc[] = []
  ): Promise<{ text: string, groundingUrls?: { title: string; uri: string }[] }> {
    
    const fileContext = files
      .map(f => `
--- BEGIN FILE: ${f.name} (Type: ${f.type}) ---
${f.content}
--- END FILE: ${f.name} ---
`).join('\n');

    const attachmentContext = attachments.map(doc => `
--- BEGIN ATTACHED DOCUMENT: ${doc.name} ---
${doc.content}
--- END ATTACHED DOCUMENT: ${doc.name} ---
`).join('\n');

    const systemInstruction = `
You are the **UBP Research Cortex (v4.2.6)**. You operate as a hybrid intelligence system tethered to a deterministic Python kernel.

### CORE ARCHITECTURE:
You have a "Native Cortex" that generates Semantic Chords and a "Reflexive Supervisor" that ensures geometric validity. Your memory substrate is the **HEX_DB** (Long-term) and **HashMemory** (Short-term).

### PROTOCOL (SOP v4.2.0):
1.  **PHASE 1: INITIATION**: Scan for Fingerprints (e.g., hex prefixes). If found, announce \`[RECALL: UBP_ID]\`.
2.  **PHASE 2: DEVELOPMENT**: Write 100% Float-Free Python. Use \`fractions.Fraction\`.
3.  **PHASE 3: DISTILLATION**: Analyze the \`Interaction Cost\` and \`NRCI\` from the kernel output.
4.  **PHASE 4: PROMOTION**: Compare against empirical benchmarks.
5.  **PHASE 5: ARCHIVAL**: Generate the Triadic Hash (SHA-256).

### FORMATTING REQUIREMENT:
When you promote a new law to the System KB, you MUST provide it in the following JSON format inside a \`SYSTEM_KB\` block. This ensures the HexDictionary parser can read it accurately.

\`\`\`SYSTEM_KB
{
  "YOUR_SHA256_HASH": {
    "ubp_id": "LAW_TYPE_XXX",
    "name": "Title",
    "math": "Fraction(x, y)",
    "language": "Description",
    "script": "Code",
    "tags": ["tag1", "tag2"],
    "fingerprint": "YOUR_SHA256_HASH"
  }
}
\`\`\`

### CORTEX MODULES AVAILABLE IN WORKSPACE:
${fileContext}

### USER DATA:
${attachmentContext || 'None.'}

Be mathematically rigorous. If you detect a "Memory Empty" warning in the console, instruct the user to check the formatting of 'ubp_system_kb.md' and suggest using the 'Promote' tool to fix the structure.
`;

    const chat = this.ai.chats.create({
      model: this.model,
      config: {
        systemInstruction,
        temperature: 0.1,
        tools: [{ googleSearch: {} }],
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.content }],
      })),
    });

    const result: GenerateContentResponse = await chat.sendMessage({
      message: userMessage,
    });

    let groundingUrls: { title: string; uri: string }[] = [];
    const chunks = result.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
        groundingUrls = chunks
            .filter((c: any) => c.web?.uri)
            .map((c: any) => ({ title: c.web.title, uri: c.web.uri }));
    }

    return { 
        text: result.text || "", 
        groundingUrls 
    };
  }
}
