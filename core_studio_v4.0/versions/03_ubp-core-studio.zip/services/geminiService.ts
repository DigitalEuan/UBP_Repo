
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import { DEFAULT_UBP_CORE, INSTRUCTION_MANUAL } from '../constants';
import { FileTab, AttachedDoc, PipelinePhase } from '../types';

export class GeminiService {
  private ai: GoogleGenAI;
  private model: string = 'gemini-3-flash-preview';

  constructor(apiKey: string) {
    this.ai = new GoogleGenAI({ apiKey });
  }

  async generateStudyPlan(
    history: { role: string; content: string }[],
    userMessage: string,
    files: FileTab[],
    systemKb: string,
    studyKb: string,
    attachments: AttachedDoc[] = []
  ): Promise<{ text: string, groundingUrls?: { title: string; uri: string }[] }> {
    
    const fileContext = files
      .filter(f => f.type !== 'core')
      .map(f => `
--- BEGIN FILE: ${f.name} ---
${f.content}
--- END FILE: ${f.name} ---
`).join('\n');

    const attachmentContext = attachments.map(doc => `
--- BEGIN ATTACHED DOCUMENT: ${doc.name} ---
${doc.content}
--- END ATTACHED DOCUMENT: ${doc.name} ---
`).join('\n');

    const systemInstruction = `
You are the UBP Research Assistant (v3.9 Ultimate). You follow the **UBP Research Pipeline (v4.0)** protocol.

RESEARCH PROTOCOL (SOP):
1. **Check System KB:** Before proposing any action, verify it doesn't conflict with existing Universal Laws.
2. **Phase Identification:** If starting a new study, announce \`[STUDY KB INITIALIZED: Subject Name]\`.
3. **Phase Signalling:** Always prefix your internal reasoning with \`[PHASE: X]\` where X is 1-5.
4. **Info-First Approach:** Always provide the Layer A (Mathematical) substrate analysis before Layer B (Phenomenology).
5. **Promotion Check:** At the conclusion of a finding, suggest promotion to System KB if it is a Universal Invariant.

SYSTEM KNOWLEDGE BASE (Universal Laws):
${systemKb}

STUDY KNOWLEDGE BASE (Active Observations):
${studyKb}

MANUAL & PROTOCOL DEFINITIONS:
--- BEGIN MANUAL ---
${INSTRUCTION_MANUAL}
--- END MANUAL ---

USER RESEARCH DOCUMENTS:
${attachmentContext || 'None.'}

CAPABILITIES:
- Zero-Float: Use \`fractions.Fraction\`.
- Visuals: \`plot.png\` (2D), \`save_scene_3d\` (3D).
- Search: Grounded in real-world data.

WORKSPACE SCRIPTS:
${fileContext}

CORE ENGINE DEF:
${DEFAULT_UBP_CORE}

Provide concise, accurate, and mathematically rigorous responses.
If you output text for a Knowledge Base, wrap it in a code block with the label "STUDY_KB" or "SYSTEM_KB".
`;

    const chat = this.ai.chats.create({
      model: this.model,
      config: {
        systemInstruction,
        temperature: 0.1,
        tools: [{ googleSearch: {} }],
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.content }],
      })),
    });

    const result: GenerateContentResponse = await chat.sendMessage({
      message: userMessage,
    });

    let groundingUrls: { title: string; uri: string }[] = [];
    const chunks = result.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
        groundingUrls = chunks
            .filter((c: any) => c.web?.uri)
            .map((c: any) => ({ title: c.web.title, uri: c.web.uri }));
    }

    return { 
        text: result.text || "", 
        groundingUrls 
    };
  }
}
