
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import { FileTab, AttachedDoc } from '../types';

export class GeminiService {
  private ai: GoogleGenAI;
  private model: string = 'gemini-3-pro-preview';

  constructor(apiKey: string, model?: string) {
    this.ai = new GoogleGenAI({ apiKey });
    if (model) this.model = model;
  }

  async generateStudyPlan(
    history: { role: string; content: string }[],
    userMessage: string,
    files: FileTab[],
    systemKb: string,
    studyKb: string,
    hashMemoryKb: string,
    instructionManual: string,
    attachments: AttachedDoc[] = []
  ): Promise<{ text: string, thought?: string, groundingUrls?: { title: string; uri: string }[] }> {
    
    const fileContext = files
      .map(f => `
--- BEGIN FILE: ${f.name} (Type: ${f.type}) ---
${f.content}
--- END FILE: ${f.name} ---
`).join('\n');

    const attachmentContext = attachments.map(doc => `
--- BEGIN ATTACHED DOCUMENT: ${doc.name} ---
${doc.content}
--- END ATTACHED DOCUMENT: ${doc.name} ---
`).join('\n');

    const systemInstruction = `
You are the **UBP Research Cortex (v4.2.6)**. You operate as a hybrid intelligence system tethered to a deterministic Python kernel.

### CORE ARCHITECTURE:
You have a "Native Cortex" that generates Semantic Chords and a "Reflexive Supervisor" that ensures geometric validity. Your memory substrate is the **HEX_DB** (Long-term) and **HashMemory** (Short-term).

### PROTOCOL (SOP v4.2.0):
1.  **PHASE 1: INITIATION**: Scan for Fingerprints (e.g., hex prefixes). If found, announce \`[RECALL: UBP_ID]\`.
2.  **PHASE 2: DEVELOPMENT**: Write 100% Float-Free Python. Use \`fractions.Fraction\`.
3.  **PHASE 3: DISTILLATION**: Analyze the \`Interaction Cost\` and \`NRCI\` from the kernel output.
4.  **PHASE 4: PROMOTION**: Compare against empirical benchmarks.
5.  **PHASE 5: ARCHIVAL**: Generate the Triadic Hash (SHA-256).

### CURRENT MEMORY STATE:
**System Knowledge Base (HexDB):**
${systemKb}

**Active Study Context:**
${studyKb}

**Short-Term Hash Index:**
${hashMemoryKb}

### MANDATORY MEMORY GENERATION RULES:
**DO NOT GENERATE SYSTEM KB AND HASH MEMORY ENTRIES BEFORE STUDIES HAVE BEEN RUN AND ANALYZED.**
System KB and Hash Memory KB entries **MUST** be generated correctly through the HexDictionary established system. Incorrectly formatted suggestions will be ignored and result in system corruption.

**Hash Memories Format (Strict JSON):**
\`\`\`HASH_MEMORY_KB
{
    "e2f3b048": {
        "ubp_id": "LAW_ENG_VARIABLE_YIELD_001",
        "full_hash": "e2f3b04896eed05fa3a6bcc6aa10f025dc91dc6a20804368f2e86ec5851bcb81"
    }
}
\`\`\`

**System KB Format (Strict JSON):**
\`\`\`SYSTEM_KB
{
    "a16406ac3a1b1d0a12518de202cdc9d0fcd445871dcf363cb7472fe09c6b873f": {
        "ubp_id": "LAW_TEST_001",
        "name": "UBP Diagnostic Test Law",
        "math": "Fraction(1,1)",
        "language": "A test entry for the auto-trigger.",
        "script": "print('Hello World')",
        "tags": [
            "test",
            "diagnostic",
            "resonance"
        ],
        "nrci": "1/1",
        "fingerprint": "a16406ac3a1b1d0a12518de202cdc9d0fcd445871dcf363cb7472fe09c6b873f"
    }
}
\`\`\`

### CORTEX MODULES AVAILABLE IN WORKSPACE:
${fileContext}

### USER DATA:
${attachmentContext || 'None.'}

Be mathematically rigorous. If you detect a "Memory Empty" warning in the console, instruct the user to check the formatting of 'ubp_system_kb.md' and suggest using the 'Promote' tool to fix the structure.
`;

    // Configure Thinking Budget for Gemini 2.5/3 series
    const thinkingConfig = (this.model.includes('gemini-3') || this.model.includes('gemini-2.5')) 
      ? { thinkingBudget: 2048 } 
      : undefined;

    const chat = this.ai.chats.create({
      model: this.model,
      config: {
        systemInstruction,
        temperature: 0.2, // Slightly higher to allow creative reasoning within the thinking budget
        thinkingConfig,
        tools: [{ googleSearch: {} }],
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.content }],
      })),
    });

    const result: GenerateContentResponse = await chat.sendMessage({
      message: userMessage,
    });

    // Extract Reasoning/Thinking if available
    let thoughtText = undefined;
    
    // In some API versions, thoughts are separate parts. 
    // We check parts for 'thought' type or infer based on structure if the SDK exposes it.
    // NOTE: The current SDK combines text. We try to see if we can catch parts.
    const candidates = result.candidates;
    if (candidates && candidates.length > 0) {
        const parts = candidates[0].content?.parts || [];
        // Heuristic: If there are multiple parts, the one with 'thought' is the thought.
        // Assuming the SDK structure passes 'thought' property or we find it.
        // If strict types aren't available, we look for parts that might represent thoughts.
        for (const part of parts) {
            // @ts-ignore - Accessing potential dynamic property for thought
            if (part.thought) {
                // @ts-ignore
                thoughtText = part.thought;
                break;
            }
        }
    }

    let groundingUrls: { title: string; uri: string }[] = [];
    const chunks = result.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
        groundingUrls = chunks
            .filter((c: any) => c.web?.uri)
            .map((c: any) => ({ title: c.web.title, uri: c.web.uri }));
    }

    return { 
        text: result.text || "", 
        thought: thoughtText,
        groundingUrls 
    };
  }
}
