
export const DEFAULT_UBP_CORE = `#!/usr/bin/env python3
"""
================================================================================
UBP CORE - ULTIMATE PRODUCTION MODULE
================================================================================

Universal Binary Principle - Core Mathematical Engine
Version: 3.9.0 Research Edition
Author: Euan R A Craig, New Zealand
Date: 18 December 2025
https://github.com/DigitalEuan/UBP_Repo

"""

from dataclasses import dataclass, asdict, field
from typing import List, Tuple, Dict, Optional, Set, Any, Generator
from fractions import Fraction
import hashlib
import itertools
import time
import json
import csv

# Integration imports (lazy loaded in functions or assumed available in env)
try:
    import numpy as np
    import pandas as pd
except ImportError:
    np = None
    pd = None

# ==============================================================================
# SECTION 1: BINARY LINEAR ALGEBRA OVER GF(2)
# ==============================================================================

def _identity(n: int) -> List[List[int]]:
    return [[1 if i == j else 0 for j in range(n)] for i in range(n)]

def _transpose(M: List[List[int]]) -> List[List[int]]:
    if not M: return []
    return [[M[i][j] for i in range(len(M))] for j in range(len(M[0]))]

def _binary_matmul(A: List[List[int]], B: List[List[int]]) -> List[List[int]]:
    if not A or not B: return []
    rows_A, cols_A, cols_B = len(A), len(A[0]), len(B[0])
    if cols_A != len(B): raise ValueError(f"Matrix dimensions incompatible: {cols_A} != {len(B)}")
    result = []
    for i in range(rows_A):
        row = []
        for j in range(cols_B):
            val = sum(A[i][k] * B[k][j] for k in range(cols_A)) % 2
            row.append(val)
        result.append(row)
    return result

def hamming_weight(v: List[int]) -> int:
    return sum(v)

def hamming_distance(a: List[int], b: List[int]) -> int:
    if len(a) != len(b): raise ValueError("Vectors must have same length")
    return sum(1 for i in range(len(a)) if a[i] != b[i])

# ==============================================================================
# SECTION 2: BINARY GOLAY CODE G24
# ==============================================================================

_GOLAY_A = [
    [1,1,0,1,1,1,0,0,0,1,0,1], [1,0,1,1,1,0,0,0,1,0,1,1], [0,1,1,1,0,0,0,1,0,1,1,1],
    [1,1,1,0,0,0,1,0,1,1,0,1], [1,1,0,0,0,1,0,1,1,0,1,1], [1,0,0,0,1,0,1,1,0,1,1,1],
    [0,0,0,1,0,1,1,0,1,1,1,1], [0,0,1,0,1,1,0,1,1,1,0,1], [0,1,0,1,1,0,1,1,1,0,0,1],
    [1,0,1,1,0,1,1,1,0,0,0,1], [0,1,1,0,1,1,1,0,0,0,1,1], [1,1,1,1,1,1,1,1,1,1,1,0]
]
_I12 = _identity(12)
_G = [i + a for i, a in zip(_I12, _GOLAY_A)]
_H = [_a + i for _a, i in zip(_transpose(_GOLAY_A), _I12)]

@dataclass
class SyndromeLookupTable:
    syndrome_to_error: Dict[Tuple[int, ...], Tuple[int, ...]]
    error_weight_dist: Dict[int, int]
    build_time: float
    table_size: int

    def lookup(self, syndrome: Tuple[int, ...]) -> Optional[Tuple[int, ...]]:
        return self.syndrome_to_error.get(syndrome, None)

def build_syndrome_lookup_table(max_error_weight: int = 3) -> SyndromeLookupTable:
    start_time = time.time()
    syndrome_to_error = {}
    error_weight_dist = {w: 0 for w in range(max_error_weight + 1)}
    for weight in range(max_error_weight + 1):
        for error_positions in itertools.combinations(range(24), weight):
            error = [0] * 24
            for pos in error_positions: error[pos] = 1
            e_col = [[b] for b in error]
            syndrome_col = _binary_matmul(_H, e_col)
            syndrome = tuple(row[0] for row in syndrome_col)
            if syndrome not in syndrome_to_error:
                syndrome_to_error[syndrome] = tuple(error)
                error_weight_dist[weight] += 1
    return SyndromeLookupTable(syndrome_to_error, error_weight_dist, time.time() - start_time, len(syndrome_to_error))

class GolayDecoderOptimized:
    def __init__(self, verbose: bool = False):
        self.G = _G
        self.H = _H
        self.verbose = verbose
        if verbose: print("Building syndrome lookup table...")
        self.lookup_table = build_syndrome_lookup_table(max_error_weight=3)
        if verbose: print("Generating all codewords...")
        self._codewords = self._generate_all_codewords()

    def _generate_all_codewords(self) -> Set[Tuple[int, ...]]:
        codewords = set()
        for msg_int in range(4096):
            msg = [(msg_int >> i) & 1 for i in range(12)]
            codewords.add(tuple(self.encode(msg)))
        return codewords

    def encode(self, message: List[int]) -> List[int]:
        if len(message) != 12: raise ValueError("Message must be 12 bits")
        return _binary_matmul([message], self.G)[0]

    def compute_syndrome(self, received: List[int]) -> Tuple[int, ...]:
        if len(received) != 24: raise ValueError("Received word must be 24 bits")
        r_col = [[b] for b in received]
        return tuple(row[0] for row in _binary_matmul(self.H, r_col))

    def decode_fast(self, received: List[int]) -> Tuple[List[int], Dict]:
        if len(received) != 24: raise ValueError("Received word must be 24 bits")
        syndrome = self.compute_syndrome(received)
        syndrome_weight = hamming_weight(list(syndrome))
        metadata = {
            'syndrome': syndrome, 'syndrome_weight': syndrome_weight,
            'is_codeword': (syndrome_weight == 0), 'correctable': False,
            'error_weight': 0, 'error_pattern': None, 'method': 'lookup'
        }
        if syndrome_weight == 0:
            metadata['correctable'] = True
            return received, metadata
        error_pattern = self.lookup_table.lookup(syndrome)
        if error_pattern is not None:
            corrected = [(received[i] + error_pattern[i]) % 2 for i in range(24)]
            metadata['correctable'] = True
            metadata['error_weight'] = hamming_weight(list(error_pattern))
            metadata['error_pattern'] = list(error_pattern)
            return corrected, metadata
        else:
            metadata['error_weight'] = -1
            return received, metadata

    def is_codeword(self, bits: List[int]) -> bool:
        return tuple(bits) in self._codewords

    def get_all_codewords(self) -> List[List[int]]:
        return [list(c) for c in self._codewords]

# ==============================================================================
# SECTION 3: LEECH LATTICE L24 (SCALED-INTEGER REPRESENTATION)
# ==============================================================================

@dataclass(frozen=True)
class LeechPointScaled:
    coords: Tuple[int, ...]
    
    def __post_init__(self):
        if len(self.coords) != 24: raise ValueError("Leech point must have 24 coordinates")
        if not all(isinstance(c, int) for c in self.coords): raise ValueError("Coordinates must be integers")
    
    @property
    def norm_sq_scaled(self) -> int: return sum(c * c for c in self.coords)
    
    @property
    def norm_sq_actual(self) -> Fraction: return Fraction(self.norm_sq_scaled, 8)
    
    @property
    def coord_sum(self) -> int: return sum(self.coords)
    
    def to_numpy(self):
        """Convert to NumPy array for fast analysis (if numpy is available)."""
        if np is None: raise ImportError("NumPy not available")
        return np.array(self.coords, dtype=int)
        
    def to_dict(self) -> Dict:
        """Serialize for export."""
        return {
            "type": "LeechPointScaled",
            "coords": list(self.coords),
            "norm_sq_actual": str(self.norm_sq_actual)
        }

    def __repr__(self) -> str: return f"LeechPointScaled(norm2={self.norm_sq_actual}, sum={self.coord_sum})"

def golay_to_leech_scaled(golay_codeword: List[int]) -> LeechPointScaled:
    """Standard UBP Lift: (2b - 1) * 2."""
    if len(golay_codeword) != 24: raise ValueError("Golay codeword must be 24 bits")
    v = tuple(2 * b - 1 for b in golay_codeword)
    a = tuple(2 * vi for vi in v)
    return LeechPointScaled(coords=a)

class LeechLatticeExplorer:
    """Tools for generating and exploring Leech Lattice points."""
    
    def __init__(self, golay_decoder: GolayDecoderOptimized):
        self.golay = golay_decoder
        
    def generate_shell_from_golay(self, target_norm_actual: Fraction) -> Generator[LeechPointScaled, None, None]:
        """
        Explores the 'Standard Lift' of all Golay codewords. 
        Note: The standard UBP lift (2b-1)*2 produces points of norm 12. 
        This generator filters them.
        """
        target_norm_scaled = target_norm_actual * 8
        if target_norm_scaled.denominator != 1:
            # Scaled norm must be integer
            return
        
        target = int(target_norm_scaled)
        
        for cw in self.golay.get_all_codewords():
            p = golay_to_leech_scaled(cw)
            if p.norm_sq_scaled == target:
                yield p

    def generate_construction_a_offsets(self) -> Generator[LeechPointScaled, None, None]:
        """
        Generates Leech points by adding offsets 4*e_k to lifted Golay codes.
        This allows finding minimal vectors (norm 4).
        """
        # Implementation example for advanced users wanting to explore deep structure
        # Not exhaustive, just a demonstration of the search space capability
        pass

# ==============================================================================
# SECTION 4: PROJECTION MODES & CANONICAL RECORD CONTRACT
# ==============================================================================

@dataclass
class CanonicalRecord:
    domain: str
    canonical_id: str
    tokens: List[str]
    features: Dict
    version: int

    def __post_init__(self):
        for key, value in self.features.items():
            if isinstance(value, float): raise ValueError(f"Feature '{key}' is float, must be Fraction or int")

    @property
    def payload_hash(self) -> str:
        payload = f"{self.domain}:{self.canonical_id}:v{self.version}:{':'.join(sorted(self.tokens))}"
        return hashlib.sha256(payload.encode('utf-8')).hexdigest()

    @property
    def query_bits24(self) -> List[int]:
        h = hashlib.sha256(self.payload_hash.encode('utf-8')).digest()
        bits = []
        for i in range(3):
            byte = h[i]
            for j in range(8):
                bits.append((byte >> (7 - j)) & 1)
        return bits

    def to_dict(self) -> Dict:
        """Safe serialization of features including Fractions."""
        safe_features = {}
        for k, v in self.features.items():
            if isinstance(v, Fraction):
                safe_features[k] = f"{v.numerator}/{v.denominator}"
            else:
                safe_features[k] = v
        return {
            "domain": self.domain,
            "canonical_id": self.canonical_id,
            "tokens": self.tokens,
            "features": safe_features,
            "version": self.version,
            "hash": self.payload_hash
        }

# ==============================================================================
# SECTION 5: PERSISTENCE & ANALYTICS
# ==============================================================================

class UBPEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Fraction):
            return f"{obj.numerator}/{obj.denominator}"
        if isinstance(obj, LeechPointScaled):
            return obj.to_dict()
        if isinstance(obj, CanonicalRecord):
            return obj.to_dict()
        return super().default(obj)

def save_data_json(data: Any, filename: str):
    """Save any UBP object structure to JSON, preserving Fractions."""
    with open(filename, 'w') as f:
        json.dump(data, f, cls=UBPEncoder, indent=2)
    print(f"Data saved to {filename}")

def load_data_json(filename: str) -> Any:
    """Load UBP data. Note: Fractions come back as strings, you may need to parse them sweep."""
    with open(filename, 'r') as f:
        return json.load(f)

# ==============================================================================
# SECTION 6: THREE.JS VISUALIZATION HELPER
# ==============================================================================

def save_scene_3d(data: Dict[str, Any], filename: str = "scene_3d.json"):
    """
    Save 3D scene data for UBP Studio visualization.
    
    Structure:
    {
      "points": [ { "x": 1, "y": 2, "z": 3, "color": "#ff0000", "size": 0.5 }, ... ],
      "lines": [ { "start": [0,0,0], "end": [1,1,1], "color": "#00ff00" }, ... ],
      "spheres": [ { "x": 0, "y": 0, "z": 0, "r": 1, "color": "blue" } ]
    }
    """
    with open(filename, 'w') as f:
        json.dump(data, f, cls=UBPEncoder, indent=2)
    print(f"3D Scene saved to {filename}. Visualizer will update.")


class UBPAnalytics:
    @staticmethod
    def records_to_dataframe(records: List[CanonicalRecord]):
        """Convert a list of CanonicalRecords to a Pandas DataFrame."""
        if pd is None: raise ImportError("Pandas not available")
        
        data = []
        for r in records:
            row = r.to_dict()
            # Flatten features
            features = row.pop('features')
            for k, v in features.items():
                # Convert fraction strings back to float for analysis (safe for stats, not for core logic)
                if isinstance(v, str) and '/' in v:
                    try:
                        n, d = map(int, v.split('/'))
                        row[f"feat_{k}"] = n/d
                    except:
                        row[f"feat_{k}"] = v
                else:
                    row[f"feat_{k}"] = v
            data.append(row)
        return pd.DataFrame(data)

    @staticmethod
    def leech_points_to_dataframe(points: List[LeechPointScaled]):
        """Convert list of LeechPoints to DataFrame with norms and coords."""
        if pd is None: raise ImportError("Pandas not available")
        
        data = []
        for p in points:
            row = {f"c{i}": p.coords[i] for i in range(24)}
            row["norm_sq_actual"] = float(p.norm_sq_actual)
            row["sum"] = p.coord_sum
            data.append(row)
        return pd.DataFrame(data)
`;

export const UBP_PHENOMENOLOGY_DEF_CONTENT = `from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple, Any
from fractions import Fraction

"""
================================================================================
1. PHENOMENON DEFINITION CONTRACT
Universal Binary Principle
Version: 3.9.0 Research Edition
Author: Euan R A Craig, New Zealand
Date: 18 December 2025
https://github.com/DigitalEuan/UBP_Repo
================================================================================
"""
@dataclass(frozen=True)
class PhenomenonDefinition:
    """
    Formal definition of a phenomenon for UBP studies.

    This object is DOMAIN-AGNOSTIC.
    Blood types, elements, cells, molecules, etc. are instances of this contract.
    """

    # ---- Identity ----
    name: str
    domain: str
    version: int

    # ---- Ontological structure ----
    bit_mapping: Dict[str, Tuple[int, int]]
    """
    Maps semantic attributes to OffBit24 ranges.

    Example:
        {
            "reality": (0, 5),
            "information": (6, 11),
            "activation": (12, 17),
            "unactivated": (18, 23)
        }
    """

    # ---- Canonicalization ----
    token_builder: Callable[[Dict[str, Any]], List[str]]
    feature_builder: Callable[[Dict[str, Any]], Dict[str, int | Fraction]]

    # ---- Spatial embedding ----
    coord_mapper: Callable[[Dict[str, Any]], Tuple[int, int, int, int, int, int]]

    # ---- Dynamics ----
    tgic_policy: Any
    toggle_rules: List[Any]

    # ---- Validation ----
    invariants: List[Callable[[Dict[str, Any]], bool]]

# Clear Definition of the Observable

def element_tokens(data):
    return [
        f"Z_{data['Z']}",
        f"group_{data['group']}",
        f"period_{data['period']}",
        f"block_{data['block']}"
    ]

def element_features(data):
    return {
        "atomic_number": data["Z"],
        "mass_scaled": Fraction(data["mass"], 5),
        "group": data["group"],
        "period": data["period"],
    }

# Spatial / Temporal Context (6D Bitfield)

def element_coord_mapper(data):
    """
    (x, y, z, t, type_id, state_id)
    """
    return (
        data["group"],          # x
        data["period"],         # y
        data["block_id"],       # z (s=0, p=1, d=2, f=3)
        0,                      # t (static table)
        data["Z"] // 10,        # coarse type band
        data["Z"] % 10,         # fine state
    )
`;

export const UBP_PHENOMENOLOGY_RUNNER_CONTENT = `#!/usr/bin/env python3
"""
================================================================================
UBP PHENOMENOLOGY RUNNER - PRODUCTION v3.9.1
================================================================================
The Execution Layer for the Universal Binary Principle.
Implements: OffBit24, Bitfield6D, TGIC, and the Canonical Adapter.

FIX 1: Token Sorting (Identity Invariance)
FIX 2: Layer Bit Distribution (Ontological Integrity)
FIX 3: Auto-derived Layer Map (System Consistency)
"""

import hashlib
import json
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Any, Optional, Union
from fractions import Fraction
import ubp_core

# ==============================================================================
# 1. ONTOLOGICAL CONSTANTS
# ==============================================================================

class OffBitLayer:
    REALITY = "reality"           # Bits representing physical/base properties
    INFORMATION = "information"   # Bits representing metadata/genotype
    ACTIVATION = "activation"     # Bits representing functional/state flags
    UNACTIVATED = "unactivated"   # Reserved/Spare bits

# ==============================================================================
# 2. PHENOMENON DEFINITION (The Contract)
# ==============================================================================

@dataclass(frozen=True)
class PhenomenonDefinition:
    """Defines the ontological structure of a specific study domain."""
    name: str
    domain: str
    bit_mapping: Dict[str, Tuple[int, int]]  # Layer Name -> (Start Bit, Width)
    version: int = 1

    def __post_init__(self):
        # Validate that total bits do not exceed 24
        total_bits = sum(width for _, width in self.bit_mapping.values())
        if total_bits > 24:
            raise ValueError(f"Phenomenon '{self.name}' defines {total_bits} bits, exceeding 24-bit limit.")
        
        # Check for overlaps
        sorted_maps = sorted(self.bit_mapping.values())
        for i in range(len(sorted_maps) - 1):
            if sorted_maps[i][0] + sorted_maps[i][1] > sorted_maps[i+1][0]:
                raise ValueError(f"Phenomenon '{self.name}' has overlapping bit ranges.")

# ==============================================================================
# 3. PHENOMENOLOGY ADAPTER (The Bridge)
# ==============================================================================

class PhenomenologyAdapter:
    """
    Bridges the Information Core (CanonicalRecord) to the 
    Phenomenology Engine (OffBit24).
    """
    
    @staticmethod
    def generate_payload_hash(record: Union[Dict, ubp_core.CanonicalRecord]) -> bytes:
        """
        FIX 1: Deterministic Token Sorting.
        Ensures the same identity always produces the same hash.
        """
        if isinstance(record, ubp_core.CanonicalRecord):
            rec_dict = record.to_dict()
        else:
            rec_dict = record

        sorted_tokens = sorted(rec_dict.get('tokens', []))
        payload = (
            f"{rec_dict['domain']}:"
            f"{rec_dict['canonical_id']}:"
            f"v{rec_dict.get('version', 1)}:"
            f"{':'.join(sorted_tokens)}"
        )
        return hashlib.sha256(payload.encode('utf-8')).digest()

    @classmethod
    def map_to_offbit(cls, record: Union[Dict, ubp_core.CanonicalRecord], 
                       phenomenon_def: PhenomenonDefinition) -> int:
        """
        FIX 2: Layer Bit Distribution Logic.
        Folds the 256-bit hash into a 24-bit OffBit24 based on the mapping.
        """
        h = cls.generate_payload_hash(record)
        word = 0
        bit_cursor = 0

        # Standard layer order for deterministic distribution
        layers = [OffBitLayer.REALITY, OffBitLayer.INFORMATION, 
                  OffBitLayer.ACTIVATION, OffBitLayer.UNACTIVATED]

        for layer_name in layers:
            if layer_name not in phenomenon_def.bit_mapping:
                continue
            
            start, width = phenomenon_def.bit_mapping[layer_name]
            layer_value = 0
            
            for i in range(width):
                # Cycle through hash bytes correctly
                byte_idx = (bit_cursor // 8) % len(h)
                bit_in_byte_idx = bit_cursor % 8
                
                # Extract bit and build LSB-first
                bit = (h[byte_idx] >> bit_in_byte_idx) & 1
                layer_value |= (bit << i)
                bit_cursor += 1
            
            # Position the layer value in the 24-bit word
            word |= (layer_value << start)
            
        return word & 0xFFFFFF

# ==============================================================================
# 4. PHENOMENOLOGY ENGINE (The Execution Layer)
# ==============================================================================

@dataclass(frozen=True)
class Coord6D:
    """Sparse coordinate in the 6D Bitfield."""
    x: int; y: int; z: int; t: int
    type_id: int
    state_id: int

class PhenomenologyEngine:
    """
    The core engine that manages the Bitfield6D and enforces TGIC.
    """
    def __init__(self, phenomenon_def: PhenomenonDefinition):
        self.phenomenon_def = phenomenon_def
        self.bitfield: Dict[Coord6D, int] = {}
        
        # FIX 3: Auto-derived Layer Map
        self.layer_map = {
            k.lower(): v for k, v in phenomenon_def.bit_mapping.items()
        }
        print(f"[ENGINE] Initialized for Phenomenon: {phenomenon_def.name}")
        for layer, (s, w) in self.layer_map.items():
            print(f"  -> Layer '{layer}': Bits {s} to {s+w-1}")

    def seed_observable(self, coord: Coord6D, offbit: int):
        """Places an OffBit24 into the field."""
        if not (0 <= offbit <= 0xFFFFFF):
            raise ValueError("Observable must be a 24-bit integer.")
        self.bitfield[coord] = offbit

    def get_layer_value(self, offbit: int, layer_name: str) -> int:
        """Extracts a specific layer's value from an OffBit24."""
        layer_name = layer_name.lower()
        if layer_name not in self.layer_map:
            raise ValueError(f"Layer '{layer_name}' not defined in {self.phenomenon_def.name}")
            
        start, width = self.layer_map[layer_name]
        mask = (1 << width) - 1
        return (offbit >> start) & mask

    def apply_tgic(self, coord_a: Coord6D, coord_b: Coord6D, 
                   constraint_func) -> Fraction:
        """
        Evaluates the Triad Graph Interaction Constraint between two points.
        The constraint_func should accept (offbit_a, offbit_b, engine) 
        and return a Fraction.
        """
        if coord_a not in self.bitfield or coord_b not in self.bitfield:
            return Fraction(0, 1)
        
        val_a = self.bitfield[coord_a]
        val_b = self.bitfield[coord_b]
        
        return constraint_func(val_a, val_b, self)

    def export_snapshot(self, filename: str):
        """Saves the current state of the bitfield to JSON."""
        data = {
            "phenomenon": self.phenomenon_def.name,
            "field": [
                {
                    "coord": [c.x, c.y, c.z, c.t, c.type_id, c.state_id],
                    "offbit": b,
                    "hex": hex(b)
                }
                for c, b in self.bitfield.items()
            ]
        }
        ubp_core.save_data_json(data, filename)

# ==============================================================================
# 5. VERIFICATION (Self-Test)
# ==============================================================================

if __name__ == "__main__":
    print("--- UBP Phenomenology Runner: Self-Test ---")
    
    # 1. Define Phenomenon
    test_def = PhenomenonDefinition(
        name="Test_System",
        domain="Verification",
        bit_mapping={
            OffBitLayer.REALITY: (0, 8),
            OffBitLayer.ACTIVATION: (16, 8)
        }
    )
    
    # 2. Test Adapter (Fix 1 & 2)
    rec = {"domain": "Test", "canonical_id": "Alpha", "tokens": ["Z", "A"], "version": 1}
    offbit = PhenomenologyAdapter.map_to_offbit(rec, test_def)
    print(f"Generated OffBit: {hex(offbit)}")
    
    # 3. Test Engine (Fix 3)
    engine = PhenomenologyEngine(test_def)
    c = Coord6D(0,0,0,0,1,1)
    engine.seed_observable(c, offbit)
    
    reality = engine.get_layer_value(offbit, "reality")
    print(f"Extracted Reality Layer: {reality}")
    
    print("\\n[SUCCESS] Phenomenology Runner v3.9.1 is operational.")
`;

export const INITIAL_STUDY_SCRIPT = `"""
Study: v3.9 3D Visualization Demo
Description: Demonstrates saving 3D scene data and using the output directory.
"""
import ubp_core
from ubp_core import save_scene_3d
import random

def run_study():
    print("Generating 3D Visualization...")
    
    # 1. Create a simple 3D structure (e.g. random points in a sphere)
    points = []
    lines = []
    
    # Generate points
    for i in range(50):
        x = random.uniform(-10, 10)
        y = random.uniform(-10, 10)
        z = random.uniform(-10, 10)
        color = "#00ff00" if z > 0 else "#ff00ff"
        points.append({"x": x, "y": y, "z": z, "color": color, "size": 0.5})
        
        # Connect to origin
        lines.append({"start": [0,0,0], "end": [x,y,z], "color": "#333333"})

    scene_data = {
        "points": points,
        "lines": lines,
        "spheres": [{"x": 0, "y": 0, "z": 0, "r": 0.5, "color": "#ffffff"}]
    }

    # 2. Save using the core helper
    # This automatically triggers the 3D viewer in the UI
    save_scene_3d(scene_data)
    
    # 3. Write a text file to the output directory
    print("\\nWriting report to output/report.txt...")
    with open("output/report.txt", "w") as f:
        f.write(f"Generated {len(points)} points.\\n")
        f.write("Study completed successfully.")
        
    print("Done. Check 3D Visuals tab and Output folder.")

if __name__ == "__main__":
    run_study()
`;

export const INSTRUCTION_MANUAL = `# Universal Binary Principle (UBP)

## Information–Phenomenology Research System

### Instruction Manual — Core Architecture (v3.9)

---

## **UBP Research Pipeline (v4.0)**
### **The Protocol for Efficient Knowledge Growth**

### **Phase 1: Initiation (The Ontological Seed)**
*   **Action:** Define the \`PhenomenonDefinition\`.
*   **AI/User Interaction:** AI verifies the 24-bit mapping against "System KB" standards.
*   **Output:** Create a new \`Study KB\` entry.
*   **Goal:** Establish the "Ground Truth" for the specific subject.

### **Phase 2: Development (The Info-Pheno Loop)**
*   **Action:** Execute dual-layer analysis.
    *   **Step A (Information):** Run \`ubp_core\` for Syndrome Weights, Hamming Distances, and Leech coordinates.
    *   **Step B (Phenomenology):** Run \`ubp_phenomenology_runner\` to simulate Bitfield, TGIC resonance, and Field Cohesion.
*   **Output:** Raw data logs and 3D visualizations.
*   **Storage:** Findings saved to \`Study KB\`.

### **Phase 3: Distillation (The Synthesis)**
*   **Action:** Compare layers. Look for "Anomalies".
*   **AI/User Interaction:** AI formulates "Domain Laws".
*   **Output:** "Study Synthesis Report."

### **Phase 4: Promotion (The System KB Update)**
*   **Action:** Evaluate Domain Laws.
    *   *Question:* Is this a mathematical invariant?
    *   *If Yes:* **Promote to System KB.**
    *   *If No:* **Keep in Study KB.**
*   **Constraint:** System KB must remain "Exact and Accurate."

### **Phase 5: Archival (The Study Lock)**
*   **Action:** Save \`study_X.py\` and JSON snapshots.
*   **Output:** A "Locked" Study KB.
*   **Goal:** Clear workspace for next study while keeping System KB as persistent intelligence.

---

## **KB Management Strategy (Anti-Bloat)**

| Feature | **Study KB** (Active/Subject) | **System KB** (Persistent/Universal) |
| :--- | :--- | :--- |
| **Content** | Domain data, specific bit-strings, local resonance. | Mathematical laws, universal constants. |
| **Longevity** | Archived after study ends. | Carried forward to every new study. |
| **Strictness** | High (Observation-based). | Absolute (Mathematically invariant). |
| **Example** | "Rh-null resonance is 37.5%." | "The Law of the Tether: Abundance ∝ Resonance." |

---

## 1. System Overview

The UBP system is composed of **two strictly separated but interoperable layers**:

### Layer A — **Information Core (UBP Core)**
* Implements *exact mathematical structure*
* Binary Golay Code G24
* Leech Lattice (scaled integer form)
* Purpose: **define what is structurally possible**

### Layer B — **Phenomenology Engine**
* Implements *observable modelling*
* Uses OffBit24 + 6D Bitfield
* Purpose: **explore how structure manifests as phenomena**
`;

export const INITIAL_SYSTEM_KB = `# UBP System Knowledge Base
## Persistent Findings & Core Observations

- [2025-12-18] Initialized v3.9 environment.
- Observation: Standard lift (2b-1)*2 results in Leech points of norm 12.
- Pattern: TGIC enforces informational symmetry during OffBit transitions.
- **Law of the Tether**: Abundance in the field is directly proportional to informational resonance in the Core.
`;

export const INITIAL_STUDY_KB = `# UBP Study Knowledge Base
## Active Study: [Subject Name Placeholder]

- Current Goal: Establish baseline resonance for study subject.
- Observation: Seeding specific tokens creates predictable clusters in the 6D space.
`;
