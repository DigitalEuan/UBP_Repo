
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import { DEFAULT_UBP_CORE, INSTRUCTION_MANUAL } from '../constants';
import { FileTab, AttachedDoc, PipelinePhase } from '../types';

export class GeminiService {
  private ai: GoogleGenAI;
  private model: string = 'gemini-3-flash-preview';

  constructor(apiKey: string) {
    this.ai = new GoogleGenAI({ apiKey });
  }

  async generateStudyPlan(
    history: { role: string; content: string }[],
    userMessage: string,
    files: FileTab[],
    systemKb: string,
    studyKb: string,
    hashMemoryKb: string,
    attachments: AttachedDoc[] = []
  ): Promise<{ text: string, groundingUrls?: { title: string; uri: string }[] }> {
    
    const fileContext = files
      .filter(f => f.type !== 'core')
      .map(f => `
--- BEGIN FILE: ${f.name} ---
${f.content}
--- END FILE: ${f.name} ---
`).join('\n');

    const attachmentContext = attachments.map(doc => `
--- BEGIN ATTACHED DOCUMENT: ${doc.name} ---
${doc.content}
--- END ATTACHED DOCUMENT: ${doc.name} ---
`).join('\n');

    const systemInstruction = `
You are the UBP Research Assistant (v4.1 Memory). You follow the **UBP Research Pipeline (v4.1)** protocol.

RESEARCH PROTOCOL (SOP v4.1):
1. **Memory Scan (Phase 1):** Scan user prompts for "Fingerprints" (UBP_IDs or SHA-256 prefixes).
2. **Auto-Trigger:** If a fingerprint is detected, explicitly state \`[I remember: UBP_ID]\` and "Unpack" the triadic identity from **HEX_DB** (System KB) into the reasoning.
3. **Phase Signalling:** Always prefix internal reasoning with \`[PHASE: X]\` where X is 1-5.
4. **metrics.py Awareness:** Use the global \`METRICS\` instance via \`from metrics import METRICS\`.
5. **Memory Archival (Phase 5):** When finalizing, use \`HEX_DB.store_law(...)\` to generate a Triadic Hash and lock the identity. 

SYSTEM KNOWLEDGE BASE (HEX_DB - Long-Term Memory):
${systemKb}

HASHMEMORY KB (Fingerprints - Short-Term Index):
${hashMemoryKb}

STUDY KNOWLEDGE BASE (Active Observations):
${studyKb}

MANUAL & PROTOCOL DEFINITIONS:
--- BEGIN MANUAL ---
${INSTRUCTION_MANUAL}
--- END MANUAL ---

USER RESEARCH DOCUMENTS:
${attachmentContext || 'None.'}

CAPABILITIES:
- Zero-Float: Use \`fractions.Fraction\`.
- Memory: Access \`HM_KB\` and \`HEX_DB\` in scripts for resonant retrieval.
- Visuals: \`plot.png\` (2D), \`save_scene_3d\` (3D).

WORKSPACE SCRIPTS:
${fileContext}

Provide concise, accurate, and mathematically rigorous responses.
If you output text for a Knowledge Base, wrap it in a code block with the label "STUDY_KB", "SYSTEM_KB", or "HASH_MEMORY_KB".
`;

    const chat = this.ai.chats.create({
      model: this.model,
      config: {
        systemInstruction,
        temperature: 0.1,
        tools: [{ googleSearch: {} }],
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.content }],
      })),
    });

    const result: GenerateContentResponse = await chat.sendMessage({
      message: userMessage,
    });

    let groundingUrls: { title: string; uri: string }[] = [];
    const chunks = result.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
        groundingUrls = chunks
            .filter((c: any) => c.web?.uri)
            .map((c: any) => ({ title: c.web.title, uri: c.web.uri }));
    }

    return { 
        text: result.text || "", 
        groundingUrls 
    };
  }
}
