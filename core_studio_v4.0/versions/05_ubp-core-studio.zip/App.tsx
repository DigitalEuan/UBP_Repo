
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { pyodideService } from './services/pyodideService';
import { GeminiService } from './services/geminiService';
import { 
    DEFAULT_UBP_CORE, 
    METRICS_PY_CONTENT,
    HEX_DICTIONARY_V4_CONTENT,
    AUTO_TRIGGER_PY_CONTENT,
    UBP_PHENOMENOLOGY_DEF_CONTENT, 
    UBP_PHENOMENOLOGY_RUNNER_CONTENT, 
    INITIAL_STUDY_SCRIPT,
    INSTRUCTION_MANUAL,
    INITIAL_SYSTEM_KB,
    INITIAL_STUDY_KB,
    INITIAL_HASH_MEMORY_KB
} from './constants';
import { ChatMessage, FileTab, Scene3DData, RightPanelTab, AttachedDoc, MobileTab } from './types';
import { CodeEditor } from './components/CodeEditor';
import { ConsoleOutput } from './components/ConsoleOutput';
import { ChatInterface } from './components/ChatInterface';
import { ThreeViewer } from './components/ThreeViewer';

const UBPLogo = () => (
  <svg width="34" height="34" viewBox="0 0 100 100" className="drop-shadow-md">
    <defs>
      <clipPath id="hexClip">
        <polygon points="50,5 93.3,30 93.3,70 50,95 6.7,70 6.7,30" />
      </clipPath>
    </defs>
    <g clipPath="url(#hexClip)">
      <polygon points="50,50 6.7,30 50,5" fill="#E31E24" />
      <polygon points="50,50 50,5 93.3,30" fill="#F7941D" />
      <polygon points="50,50 93.3,30 93.3,70" fill="#FFF200" />
      <polygon points="50,50 93.3,70 50,95" fill="#39B54A" />
      <polygon points="50,50 50,95 6.7,70" fill="#00AEEF" />
      <polygon points="50,50 6.7,70 6.7,30" fill="#662D91" />
    </g>
    <polygon points="50,5 93.3,30 93.3,70 50,95 6.7,70 6.7,30" fill="none" stroke="black" strokeWidth="7" strokeLinejoin="round" />
    <path d="M38,25 L38,75 M38,35 L65,50 M38,50 L65,65" fill="none" stroke="black" strokeWidth="6" strokeLinecap="round" />
  </svg>
);

const App: React.FC = () => {
  const [apiKey, setApiKey] = useState(process.env.API_KEY || '');
  const [showKeyInput, setShowKeyInput] = useState(false);
  const [isPyodideReady, setIsPyodideReady] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);
  const [activeMobileTab, setActiveMobileTab] = useState<MobileTab>('assistant');
  
  const [activeTabId, setActiveTabId] = useState<string>('study_1.py');
  const [files, setFiles] = useState<FileTab[]>([
    { name: 'ubp_core.py', content: DEFAULT_UBP_CORE, type: 'core' },
    { name: 'metrics.py', content: METRICS_PY_CONTENT, type: 'core' },
    { name: 'hex_dictionary_v4.py', content: HEX_DICTIONARY_V4_CONTENT, type: 'core' },
    { name: 'auto_trigger.py', content: AUTO_TRIGGER_PY_CONTENT, type: 'core' },
    { name: 'ubp_phenomenology_def.py', content: UBP_PHENOMENOLOGY_DEF_CONTENT, type: 'core' },
    { name: 'ubp_phenomenology_runner.py', content: UBP_PHENOMENOLOGY_RUNNER_CONTENT, type: 'core' },
    { name: 'study_1.py', content: INITIAL_STUDY_SCRIPT, type: 'script' }
  ]);
  const [fileList, setFileList] = useState<string[]>([]);
  
  const [systemKb, setSystemKb] = useState(INITIAL_SYSTEM_KB);
  const [studyKb, setStudyKb] = useState(INITIAL_STUDY_KB);
  const [hashMemoryKb, setHashMemoryKb] = useState(INITIAL_HASH_MEMORY_KB);
  
  const [consoleOutput, setConsoleOutput] = useState('');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [scene3dData, setScene3dData] = useState<Scene3DData | null>(null);
  const [activeOutputTab, setActiveOutputTab] = useState<'console' | 'visual'>('console');
  const [activeVisualTab, setActiveVisualTab] = useState<'2D' | '3D'>('2D');
  
  const [editorHeightPercent, setEditorHeightPercent] = useState(60);
  const [rightView, setRightView] = useState<RightPanelTab>('editor');
  const isDraggingSplit = useRef(false);

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      content: 'Welcome to UBP Core Studio v4.1 Ultimate. Research Pipeline Protocol (SOP v4.1) active. Memory System (HexDB) online. Standing by for PHASE 1: INITIATION.',
      timestamp: Date.now()
    }
  ]);
  const [isChatLoading, setIsChatLoading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const loadStudyRef = useRef<HTMLInputElement>(null);
  const importSystemKbRef = useRef<HTMLInputElement>(null);
  const importStudyKbRef = useRef<HTMLInputElement>(null);
  const importHashKbRef = useRef<HTMLInputElement>(null);
  const rightPanelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchKbs = async () => {
      try {
        const sysUrl = 'https://raw.githubusercontent.com/DigitalEuan/UBP_Repo/main/core_studio_v4.0/system_kb/ubp_system_kb.md';
        const hashUrl = 'https://raw.githubusercontent.com/DigitalEuan/UBP_Repo/main/core_studio_v4.0/system_kb/hash_memory_kb.md';
        
        const [sysRes, hashRes] = await Promise.all([
            fetch(sysUrl),
            fetch(hashUrl)
        ]);

        if (sysRes.ok) {
          const content = await sysRes.text();
          setSystemKb(content);
          setConsoleOutput(prev => prev + "[SYSTEM] Successfully synchronized System Knowledge Base (HEX_DB) from GitHub.\n");
        }
        if (hashRes.ok) {
          const content = await hashRes.text();
          setHashMemoryKb(content);
          setConsoleOutput(prev => prev + "[SYSTEM] Successfully synchronized HashMemory KB (Fingerprints) from GitHub.\n");
        }
      } catch (e) {
        setConsoleOutput(prev => prev + "[WARNING] Failed to sync Knowledge Bases from GitHub. Using local fallback.\n");
      }
    };
    fetchKbs();
  }, []);

  const initKernel = async (isRestart: boolean = false) => {
    try {
      if (isRestart) {
        setIsPyodideReady(false);
        pyodideService.reset();
        setConsoleOutput(prev => prev + "\n[SYSTEM] Terminating existing kernel and restarting...\n");
      } else {
        setConsoleOutput("Initializing Pyodide Runtime & Loading Matplotlib...\n");
      }
      await pyodideService.initialize();
      setIsPyodideReady(true);
      setConsoleOutput(prev => prev + "Pyodide Ready.\nWriting default files...\n");
      for (const f of files) await pyodideService.writeFile(f.name, f.content);
      await refreshFileList();
      setConsoleOutput(prev => prev + "System ready.\n");
    } catch (err) { setConsoleOutput(prev => prev + `Error initializing runtime: ${err}\n`); }
  };

  useEffect(() => { initKernel(); }, []);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
        if (!isDraggingSplit.current || !rightPanelRef.current) return;
        const panelRect = rightPanelRef.current.getBoundingClientRect();
        const relativeY = e.clientY - panelRect.top;
        const newPercent = (relativeY / panelRect.height) * 100;
        if (newPercent > 20 && newPercent < 80) setEditorHeightPercent(newPercent);
    };
    const handleMouseUp = () => { isDraggingSplit.current = false; document.body.style.cursor = 'default'; };
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => { window.removeEventListener('mousemove', handleMouseMove); window.removeEventListener('mouseup', handleMouseUp); };
  }, []);

  const refreshFileList = async () => {
    if (isPyodideReady) {
      const list = await pyodideService.listFiles();
      setFileList(list);
    }
  };

  const handleCodeChange = async (newCode: string) => {
    if (rightView === 'editor') {
        setFiles(prev => prev.map(f => f.name === activeTabId ? { ...f, content: newCode } : f));
        if (isPyodideReady) await pyodideService.writeFile(activeTabId, newCode);
    } else if (rightView === 'system_kb') {
        setSystemKb(newCode);
    } else if (rightView === 'study_kb') {
        setStudyKb(newCode);
    } else if (rightView === 'hash_memory_kb') {
        setHashMemoryKb(newCode);
    }
  };

  const runStudy = async () => {
    if (!isPyodideReady) return;
    setIsExecuting(true);
    setConsoleOutput(prev => prev + `\n\n--- Executing ${activeTabId} ---\n`);
    setGeneratedImage(null);
    setScene3dData(null);
    setActiveOutputTab('console');
    
    try {
      for (const f of files) await pyodideService.writeFile(f.name, f.content);
      const codeToRun = files.find(f => f.name === activeTabId)?.content || '';
      const result = await pyodideService.runPython(codeToRun);
      if (result.stdout) setConsoleOutput(prev => prev + result.stdout);
      if (result.stderr) setConsoleOutput(prev => prev + `\n[STDERR]\n${result.stderr}`);
      if (result.error) setConsoleOutput(prev => prev + `\n[SYSTEM ERROR]\n${result.error}`);
      
      let hasVisual = false;
      if (result.image) { 
          setGeneratedImage(result.image); 
          setActiveVisualTab('2D'); 
          hasVisual = true;
      }
      if (result.scene3d) { 
          setScene3dData(result.scene3d); 
          setActiveVisualTab('3D'); 
          hasVisual = true;
      }
      
      if (hasVisual) {
          setActiveOutputTab('visual');
      }
      
      setConsoleOutput(prev => prev + "\n--- Execution Finished ---");
    } catch (e: any) { setConsoleOutput(prev => prev + `\n[EXECUTION FAILED] ${e.message}\n`); }
    finally { setIsExecuting(false); await refreshFileList(); }
  };

  const stopExecution = () => {
    setConsoleOutput(prev => prev + "\n[SYSTEM] Attempting to stop execution via kernel reset...\n");
    initKernel(true);
    setIsExecuting(false);
  };

  const deleteTab = async (name: string) => {
    if (!confirm(`Are you sure you want to delete ${name}?`)) return;
    setFiles(prev => prev.filter(f => f.name !== name));
    if (activeTabId === name) {
        const remaining = files.filter(f => f.name !== name);
        if (remaining.length > 0) setActiveTabId(remaining[0].name);
    }
    if (isPyodideReady) { try { await pyodideService.deleteFile(name); await refreshFileList(); } catch (e) { } }
  };

  const handleSendMessage = async (text: string, attachments: AttachedDoc[] = []) => {
    if (!apiKey) { alert("Please enter a Google Gemini API Key first."); return; }
    const newUserMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: text + (attachments.length > 0 ? ` [Attached: ${attachments.map(a => a.name).join(', ')}]` : ''),
      timestamp: Date.now(),
      attachments: attachments
    };
    setChatMessages(prev => [...prev, newUserMsg]);
    setIsChatLoading(true);
    try {
      const gemini = new GeminiService(apiKey);
      const history = chatMessages.map(m => ({ role: m.role, content: m.content }));
      const { text: responseText, groundingUrls } = await gemini.generateStudyPlan(
        history, text, files, systemKb, studyKb, hashMemoryKb, attachments
      );
      setChatMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'model',
        content: responseText,
        timestamp: Date.now(),
        groundingUrls: groundingUrls
      }]);
    } catch (err: any) {
      setChatMessages(prev => [...prev, {
        id: Date.now().toString(), role: 'model', content: `Error: ${err.message}`, isError: true, timestamp: Date.now()
      }]);
    } finally { setIsChatLoading(false); }
  };

  const handleExtractToKB = (target: 'system' | 'study' | 'hash', content: string) => {
    const timestamp = new Date().toISOString().split('T')[0];
    const formattedContent = `\n- [${timestamp}] ${content}\n`;
    if (target === 'system') {
      setSystemKb(prev => prev + formattedContent);
      setRightView('system_kb');
    } else if (target === 'study') {
      setStudyKb(prev => prev + formattedContent);
      setRightView('study_kb');
    } else {
      setHashMemoryKb(prev => prev + formattedContent);
      setRightView('hash_memory_kb');
    }
  };

  const createNewTabFromChat = (code: string) => {
    const newFileName = `study_${files.length}.py`;
    const newFile: FileTab = { name: newFileName, content: code, type: 'script' };
    setFiles(prev => [...prev, newFile]);
    setActiveTabId(newFileName);
    if (isPyodideReady) pyodideService.writeFile(newFileName, code);
    setRightView('editor');
    if (window.innerWidth < 768) setActiveMobileTab('studio');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !isPyodideReady) return;
    const reader = new FileReader();
    reader.onload = async (evt) => {
        const arrayBuffer = evt.target?.result as ArrayBuffer;
        const uint8View = new Uint8Array(arrayBuffer);
        await pyodideService.writeBinaryFile(file.name, uint8View);
        if (file.name.endsWith('.py')) {
            const textContent = new TextDecoder().decode(uint8View);
            setFiles(prev => [...prev, { name: file.name, content: textContent, type: 'script' }]);
            setActiveTabId(file.name);
        }
        await refreshFileList();
        setConsoleOutput(prev => prev + `\n[SYSTEM] Uploaded ${file.name}.\n`);
    };
    reader.readAsArrayBuffer(file);
  };

  const downloadRuntimeFile = async (name: string) => {
     if (!isPyodideReady) return;
     const data = await pyodideService.readBinaryFile(name);
     if (!data) return;
     const blob = new Blob([data], { type: 'application/octet-stream' });
     const url = URL.createObjectURL(blob);
     const a = document.createElement('a');
     a.href = url;
     a.download = name.split('/').pop()!;
     a.click();
     URL.revokeObjectURL(url);
  };

  const saveStudy = () => {
    const studyState = { 
        version: '4.1.0', 
        timestamp: Date.now(), 
        activeTabId, 
        files, 
        systemKb, 
        studyKb, 
        hashMemoryKb,
        chatMessages 
    };
    const blob = new Blob([JSON.stringify(studyState, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ubp_study_v4_1_${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleLoadStudy = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (evt) => {
        try {
            const json = JSON.parse(evt.target?.result as string);
            setFiles(json.files);
            if (json.activeTabId) setActiveTabId(json.activeTabId);
            if (json.chatMessages) setChatMessages(json.chatMessages);
            if (json.systemKb) setSystemKb(json.systemKb);
            if (json.studyKb) setStudyKb(json.studyKb);
            if (json.hashMemoryKb) setHashMemoryKb(json.hashMemoryKb);
            if (isPyodideReady) { for (const f of json.files) await pyodideService.writeFile(f.name, f.content); await refreshFileList(); }
            setConsoleOutput(prev => prev + `\n[SYSTEM] Study loaded.\n`);
        } catch (err) { setConsoleOutput(prev => prev + `\n[ERROR] Load failed: ${err}\n`); }
    };
    reader.readAsText(file);
  };

  const exportKb = (content: string, name: string) => {
    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${name}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportKb = (e: React.ChangeEvent<HTMLInputElement>, setter: (v: string) => void, label: string) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => { setter(evt.target?.result as string); setConsoleOutput(prev => prev + `\n[SYSTEM] ${label} Knowledge Base imported.\n`); };
    reader.readAsText(file);
  };

  return (
    <div className="flex flex-col h-screen bg-black text-gray-200 overflow-hidden font-sans">
      <header className="flex-none h-14 bg-[#111] border-b border-gray-800 flex items-center justify-between px-2 md:px-6 z-10 shadow-lg">
        <div className="flex items-center gap-2 md:gap-3">
           <UBPLogo />
           <div className="flex flex-col justify-center">
             <h1 className="font-bold text-sm md:text-lg tracking-tight leading-none">Core Studio</h1>
             <span className="hidden sm:inline text-gray-500 font-normal text-[10px] md:text-sm">v4.1.0 Memory</span>
           </div>
        </div>
        <div className="flex items-center gap-2 md:gap-4">
           {/* Save/Load Group */}
           <div className="flex items-center gap-1 md:gap-2 border-r border-gray-700 pr-2 md:pr-4 mr-1 md:mr-2">
             <button onClick={saveStudy} className="text-[9px] md:text-[10px] uppercase font-bold bg-gray-800 hover:bg-gray-700 text-gray-300 px-2 md:px-3 py-1.5 rounded transition-colors border border-gray-700 shadow-sm">Save</button>
             <button onClick={() => loadStudyRef.current?.click()} className="text-[9px] md:text-[10px] uppercase font-bold bg-gray-800 hover:bg-gray-700 text-gray-300 px-2 md:px-3 py-1.5 rounded transition-colors border border-gray-700 shadow-sm">Load</button>
             <input type="file" ref={loadStudyRef} onChange={handleLoadStudy} accept=".json" className="hidden" />
           </div>
           
           <div className="flex items-center mr-1 md:mr-2 relative">
                <button 
                    onClick={() => setShowKeyInput(!showKeyInput)} 
                    className={`transition-colors p-2 rounded-full ${apiKey ? 'text-green-400 bg-green-900/20' : 'text-gray-400 hover:text-white'}`}
                    title={apiKey ? "Edit API Key" : "Enter API Key"}
                >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11.536 9.636 10.122 8.222 7.708 8.636a2 2 0 01-2.422-2.422l.414-2.414L3.293 3.293a1 1 0 00-1.414 1.414l5.243 5.243a8 8 0 0013.879-2.936A6 6 0 0115 7z" /></svg>
                </button>
                {showKeyInput && (
                    <div className="absolute top-full right-0 mt-2 z-50 bg-[#1a1a1a] border border-gray-700 rounded shadow-xl p-2 flex items-center gap-2">
                        <input 
                            type="password" 
                            placeholder="Paste Gemini Key" 
                            value={apiKey} 
                            onChange={(e) => setApiKey(e.target.value)} 
                            className="bg-black border border-gray-700 rounded px-2 py-1 text-xs w-48 text-white focus:border-purple-500 outline-none"
                            autoFocus
                        />
                    </div>
                )}
           </div>

           <div className="flex items-center gap-2 text-[9px] md:text-[10px] font-mono tracking-widest text-gray-400">
              <span className={`w-2 h-2 rounded-full ${isPyodideReady ? 'bg-green-500 animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]' : 'bg-red-500'}`}></span>
              <span className="hidden xs:inline">{isPyodideReady ? (isExecuting ? 'RUNNING' : 'IDLE') : 'OFFLINE'}</span>
           </div>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden relative">
        <div className="flex md:hidden absolute bottom-0 left-0 right-0 h-14 bg-[#111] border-t border-gray-800 z-50 items-center justify-around px-4">
           <button onClick={() => setActiveMobileTab('assistant')} className={`flex flex-col items-center gap-1 ${activeMobileTab === 'assistant' ? 'text-purple-400' : 'text-gray-500'}`}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
              <span className="text-[9px] font-bold uppercase">Assistant</span>
           </button>
           <button onClick={() => setActiveMobileTab('workspace')} className={`flex flex-col items-center gap-1 ${activeMobileTab === 'workspace' ? 'text-purple-400' : 'text-gray-500'}`}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" /></svg>
              <span className="text-[9px] font-bold uppercase">Workspace</span>
           </button>
           <button onClick={() => setActiveMobileTab('studio')} className={`flex flex-col items-center gap-1 ${activeMobileTab === 'studio' ? 'text-purple-400' : 'text-gray-500'}`}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>
              <span className="text-[9px] font-bold uppercase">Studio</span>
           </button>
        </div>

        <div className={`${activeMobileTab === 'assistant' ? 'flex' : 'hidden'} md:flex w-full md:w-[350px] flex-none z-0 border-r border-gray-800 flex-col shadow-2xl pb-14 md:pb-0`}>
          <ChatInterface 
            messages={chatMessages} 
            onSendMessage={handleSendMessage} 
            isLoading={isChatLoading} 
            onExtractCode={createNewTabFromChat} 
            onExtractToKB={handleExtractToKB as any}
          />
        </div>

        <div className={`${activeMobileTab === 'workspace' ? 'flex' : 'hidden'} md:flex w-full md:w-[200px] bg-[#151515] border-r border-gray-800 flex-col text-sm flex-none shadow-xl pb-14 md:pb-0`}>
          <div className="p-3 font-bold text-gray-500 uppercase text-[10px] tracking-[0.2em] border-b border-gray-800 flex justify-between items-center">
              <span>Workspace</span>
              <button onClick={() => fileInputRef.current?.click()} className="hover:text-white transition-colors"><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg></button>
              <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileUpload} />
          </div>
          <div className="flex-1 overflow-y-auto p-2 scrollbar-thin">
              <div className="mb-6">
                  <span className="text-[9px] text-gray-600 font-bold px-2 uppercase tracking-widest">Open Scripts</span>
                  <ul className="mt-2 space-y-1">
                      {files.map(f => (
                          <li key={f.name} onClick={() => { setActiveTabId(f.name); setRightView('editor'); if(window.innerWidth < 768) setActiveMobileTab('studio'); }} className={`group px-2 py-1.5 rounded cursor-pointer truncate flex items-center justify-between transition-all ${activeTabId === f.name && rightView === 'editor' ? 'bg-purple-900/30 text-purple-300 border border-purple-800/50' : 'text-gray-500 hover:bg-gray-800'}`}>
                              <span className="truncate text-xs">{f.name}</span>
                              <button onClick={(e) => { e.stopPropagation(); deleteTab(f.name); }} className="opacity-0 group-hover:opacity-100 hover:text-red-500"><svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></button>
                          </li>
                      ))}
                  </ul>
              </div>
              <div>
                  <div className="flex justify-between items-center px-2 mb-2">
                    <span className="text-[9px] text-gray-600 font-bold uppercase tracking-widest">Runtime</span>
                    <button onClick={refreshFileList} className="text-[9px] text-gray-700 hover:text-gray-400">SYNC</button>
                  </div>
                  <ul className="space-y-1">
                      {fileList.map(name => (
                          <li key={name} className="px-2 py-1 text-gray-500 text-[11px] flex items-center justify-between group hover:bg-gray-800 rounded">
                              <span className="truncate">{name}</span>
                              <div className="flex gap-1 opacity-0 group-hover:opacity-100">
                                  <button onClick={() => downloadRuntimeFile(name)} className="hover:text-blue-400"><svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4-4m0 0l-4 4m4-4v12" /></svg></button>
                              </div>
                          </li>
                      ))}
                  </ul>
              </div>
          </div>
        </div>

        <div ref={rightPanelRef} className={`${activeMobileTab === 'studio' ? 'flex' : 'hidden md:flex'} flex-1 flex-col bg-[#0d0d0d] relative shadow-inner pb-14 md:pb-0`}>
          <div className="flex-none h-12 flex bg-[#1a1a1a] border-b border-gray-800 items-center px-4 justify-between shadow-sm z-10">
             <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
                <div className="flex items-center bg-black/40 rounded p-1 border border-gray-800">
                    { (['editor', 'manual', 'system_kb', 'study_kb', 'hash_memory_kb'] as RightPanelTab[]).map(tab => (
                      <button 
                        key={tab}
                        onClick={() => setRightView(tab)} 
                        className={`px-3 py-1.5 text-[8px] md:text-[9px] font-bold rounded transition-all whitespace-nowrap uppercase tracking-widest ${rightView === tab ? 'bg-purple-700/80 text-white shadow-md' : 'text-gray-600 hover:text-gray-400'}`}
                      >{tab.replace(/_/g, ' ')}</button>
                    )) }
                </div>
             </div>
             <div className="flex items-center gap-2">
                {rightView === 'editor' && (
                  isExecuting ? (
                      <button onClick={stopExecution} className="bg-red-900/60 hover:bg-red-800 text-white text-[9px] md:text-[10px] font-bold py-1.5 px-3 md:px-4 rounded border border-red-800 shadow-lg">STOP</button>
                  ) : (
                      <button onClick={runStudy} disabled={!isPyodideReady} className="bg-green-900/60 hover:bg-green-800 text-white text-[9px] md:text-[10px] font-bold py-1.5 px-3 md:px-4 rounded border border-green-800 disabled:opacity-30 shadow-lg">RUN</button>
                  )
                )}
             </div>
          </div>

          <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
              <div style={{ height: window.innerWidth < 768 ? '50%' : `${editorHeightPercent}%` }} className="border-b border-gray-800 min-h-[100px] relative overflow-hidden">
                  {rightView === 'editor' ? (
                    <CodeEditor code={files.find(f => f.name === activeTabId)?.content || ''} onChange={handleCodeChange} label="Script Editor" readOnly={files.find(f => f.name === activeTabId)?.type === 'core'} />
                  ) : rightView === 'manual' ? (
                    <div className="h-full bg-[#1e1e1e] overflow-y-auto p-4 md:p-8 font-sans text-gray-400 leading-relaxed text-xs md:text-sm">
                        <div className="max-w-4xl mx-auto prose prose-invert">
                          <pre className="whitespace-pre-wrap font-sans text-[10px] md:text-xs">
                            {INSTRUCTION_MANUAL}
                          </pre>
                        </div>
                    </div>
                  ) : (
                    <div className="h-full flex flex-col overflow-hidden">
                       <div className="flex-none p-2 bg-[#2d2d2d] flex justify-end gap-2 border-b border-gray-700">
                          <button onClick={() => exportKb(rightView === 'system_kb' ? systemKb : rightView === 'study_kb' ? studyKb : hashMemoryKb, `ubp_${rightView}`)} className="text-[8px] font-bold bg-gray-800 text-gray-400 px-2 py-1 rounded">EXPORT</button>
                          <button onClick={() => (rightView === 'system_kb' ? importSystemKbRef.current : rightView === 'study_kb' ? importStudyKbRef.current : importHashKbRef.current)?.click()} className="text-[8px] font-bold bg-gray-800 text-gray-400 px-2 py-1 rounded">IMPORT</button>
                          <input type="file" ref={importSystemKbRef} onChange={(e) => handleImportKb(e, setSystemKb, 'System')} className="hidden" />
                          <input type="file" ref={importStudyKbRef} onChange={(e) => handleImportKb(e, setStudyKb, 'Study')} className="hidden" />
                          <input type="file" ref={importHashKbRef} onChange={(e) => handleImportKb(e, setHashMemoryKb, 'HashMemory')} className="hidden" />
                       </div>
                       <div className="flex-1 overflow-hidden">
                          <CodeEditor 
                            code={rightView === 'system_kb' ? systemKb : rightView === 'study_kb' ? studyKb : hashMemoryKb} 
                            onChange={handleCodeChange} 
                            label={rightView === 'system_kb' ? "System KB (HEX_DB)" : rightView === 'study_kb' ? "Study Knowledge Base" : "HashMemory KB (Fingerprints)"} 
                          />
                       </div>
                    </div>
                  )}
              </div>
              <div className="hidden md:block h-1 bg-gray-900 hover:bg-blue-900 cursor-row-resize z-20 transition-colors" onMouseDown={() => { isDraggingSplit.current = true; document.body.style.cursor = 'row-resize'; }} />
              <div style={{ height: window.innerWidth < 768 ? '50%' : `${100 - editorHeightPercent}%` }} className="flex flex-col min-h-[50px] overflow-hidden bg-[#111]">
                  <div className="flex-none h-8 flex items-center bg-[#1a1a1a] border-b border-gray-800">
                      <button 
                          onClick={() => setActiveOutputTab('console')}
                          className={`h-full px-4 text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 transition-colors ${activeOutputTab === 'console' ? 'bg-[#111] text-green-400 border-t-2 border-green-500' : 'text-gray-500 hover:text-gray-300 hover:bg-[#222]'}`}
                      >
                          <span>System Output</span>
                          {isExecuting && <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />}
                      </button>
                      
                      {(generatedImage || scene3dData) && (
                          <button 
                              onClick={() => setActiveOutputTab('visual')}
                              className={`h-full px-4 text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 transition-colors ${activeOutputTab === 'visual' ? 'bg-[#111] text-blue-400 border-t-2 border-blue-500' : 'text-gray-500 hover:text-gray-300 hover:bg-[#222]'}`}
                          >
                              <span>Visual Insights</span>
                          </button>
                      )}
                      
                      <div className="flex-1 flex justify-end items-center px-2">
                          {activeOutputTab === 'visual' && (
                              <div className="flex gap-1">
                                 {generatedImage && <button onClick={() => setActiveVisualTab('2D')} className={`px-2 py-0.5 text-[9px] font-bold rounded ${activeVisualTab === '2D' ? 'bg-blue-900 text-blue-100' : 'text-gray-500 hover:bg-gray-800'}`}>2D</button>}
                                 {scene3dData && <button onClick={() => setActiveVisualTab('3D')} className={`px-2 py-0.5 text-[9px] font-bold rounded ${activeVisualTab === '3D' ? 'bg-blue-900 text-blue-100' : 'text-gray-500 hover:bg-gray-800'}`}>3D</button>}
                              </div>
                          )}
                          {activeOutputTab === 'console' && (
                               <button onClick={() => setConsoleOutput('')} className="text-[9px] text-gray-600 hover:text-red-400 font-bold uppercase px-2">Clear</button>
                          )}
                      </div>
                  </div>

                  <div className="flex-1 overflow-hidden relative bg-black">
                      {activeOutputTab === 'console' && (
                          <ConsoleOutput output={consoleOutput} hideHeader={true} />
                      )}
                      {activeOutputTab === 'visual' && (generatedImage || scene3dData) && (
                           <div className="w-full h-full flex flex-col bg-[#111] overflow-hidden relative">
                               <div className="flex-1 flex items-center justify-center bg-gray-950 overflow-hidden relative">
                                    {activeVisualTab === '2D' && generatedImage && (
                                        <div className="relative group max-w-full max-h-full p-4 flex items-center justify-center">
                                          <img src={`data:image/png;base64,${generatedImage}`} alt="Plot" className="max-w-full max-h-full rounded shadow-2xl border border-gray-800 bg-white" />
                                          <button onClick={() => downloadRuntimeFile('plot.png')} className="absolute top-6 right-6 p-2 bg-black/80 hover:bg-blue-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-all"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4-4m0 0l-4 4m4-4v12" /></svg></button>
                                        </div>
                                    )}
                                    {activeVisualTab === '3D' && scene3dData && <ThreeViewer data={scene3dData} />}
                               </div>
                           </div>
                      )}
                  </div>
              </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
