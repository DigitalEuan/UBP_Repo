
export const DEFAULT_UBP_CORE = `#!/usr/bin/env python3
"""
================================================================================
UBP CORE - ULTIMATE PRODUCTION MODULE
================================================================================

Universal Binary Principle - Core Mathematical Engine
Version: 4.0.0 Research Edition
Author: Euan R A Craig, New Zealand
Date: 18 December 2025
https://github.com/DigitalEuan/UBP_Repo

"""

from dataclasses import dataclass, asdict, field
from typing import List, Tuple, Dict, Optional, Set, Any, Generator
from fractions import Fraction
import hashlib
import itertools
import time
import json
import csv

# Integration imports (lazy loaded in functions or assumed available in env)
try:
    import numpy as np
    import pandas as pd
except ImportError:
    np = None
    pd = None

# ==============================================================================
# SECTION 1: BINARY LINEAR ALGEBRA OVER GF(2)
# ==============================================================================

def _identity(n: int) -> List[List[int]]:
    return [[1 if i == j else 0 for j in range(n)] for i in range(n)]

def _transpose(M: List[List[int]]) -> List[List[int]]:
    if not M: return []
    return [[M[i][j] for i in range(len(M))] for j in range(len(M[0]))]

def _binary_matmul(A: List[List[int]], B: List[List[int]]) -> List[List[int]]:
    if not A or not B: return []
    rows_A, cols_A, cols_B = len(A), len(A[0]), len(B[0])
    if cols_A != len(B): raise ValueError(f"Matrix dimensions incompatible: {cols_A} != {len(B)}")
    result = []
    for i in range(rows_A):
        row = []
        for j in range(cols_B):
            val = sum(A[i][k] * B[k][j] for k in range(cols_A)) % 2
            row.append(val)
        result.append(row)
    return result

def hamming_weight(v: List[int]) -> int:
    return sum(v)

def hamming_distance(a: List[int], b: List[int]) -> int:
    if len(a) != len(b): raise ValueError("Vectors must have same length")
    return sum(1 for i in range(len(a)) if a[i] != b[i])

# ==============================================================================
# SECTION 2: BINARY GOLAY CODE G24
# ==============================================================================

_GOLAY_A = [
    [1,1,0,1,1,1,0,0,0,1,0,1], [1,0,1,1,1,0,0,0,1,0,1,1], [0,1,1,1,0,0,0,1,0,1,1,1],
    [1,1,1,0,0,0,1,0,1,1,0,1], [1,1,0,0,0,1,0,1,1,0,1,1], [1,0,0,0,1,0,1,1,0,1,1,1],
    [0,0,0,1,0,1,1,0,1,1,1,1], [0,0,1,0,1,1,0,1,1,1,0,1], [0,1,0,1,1,0,1,1,1,0,0,1],
    [1,0,1,1,0,1,1,1,0,0,0,1], [0,1,1,0,1,1,1,0,0,0,1,1], [1,1,1,1,1,1,1,1,1,1,1,0]
]
_I12 = _identity(12)
_G = [i + a for i, a in zip(_I12, _GOLAY_A)]
_H = [_a + i for _a, i in zip(_transpose(_GOLAY_A), _I12)]

@dataclass
class SyndromeLookupTable:
    syndrome_to_error: Dict[Tuple[int, ...], Tuple[int, ...]]
    error_weight_dist: Dict[int, int]
    build_time: float
    table_size: int

    def lookup(self, syndrome: Tuple[int, ...]) -> Optional[Tuple[int, ...]]:
        return self.syndrome_to_error.get(syndrome, None)

def build_syndrome_lookup_table(max_error_weight: int = 3) -> SyndromeLookupTable:
    start_time = time.time()
    syndrome_to_error = {}
    error_weight_dist = {w: 0 for w in range(max_error_weight + 1)}
    for weight in range(max_error_weight + 1):
        for error_positions in itertools.combinations(range(24), weight):
            error = [0] * 24
            for pos in error_positions: error[pos] = 1
            e_col = [[b] for b in error]
            syndrome_col = _binary_matmul(_H, e_col)
            syndrome = tuple(row[0] for row in syndrome_col)
            if syndrome not in syndrome_to_error:
                syndrome_to_error[syndrome] = tuple(error)
                error_weight_dist[weight] += 1
    return SyndromeLookupTable(syndrome_to_error, error_weight_dist, time.time() - start_time, len(syndrome_to_error))

class GolayDecoderOptimized:
    def __init__(self, verbose: bool = False):
        self.G = _G
        self.H = _H
        self.verbose = verbose
        if verbose: print("Building syndrome lookup table...")
        self.lookup_table = build_syndrome_lookup_table(max_error_weight=3)
        if verbose: print("Generating all codewords...")
        self._codewords = self._generate_all_codewords()

    def _generate_all_codewords(self) -> Set[Tuple[int, ...]]:
        codewords = set()
        for msg_int in range(4096):
            msg = [(msg_int >> i) & 1 for i in range(12)]
            codewords.add(tuple(self.encode(msg)))
        return codewords

    def encode(self, message: List[int]) -> List[int]:
        if len(message) != 12: raise ValueError("Message must be 12 bits")
        return _binary_matmul([message], self.G)[0]

    def compute_syndrome(self, received: List[int]) -> Tuple[int, ...]:
        if len(received) != 24: raise ValueError("Received word must be 24 bits")
        r_col = [[b] for b in received]
        return tuple(row[0] for row in _binary_matmul(self.H, r_col))

    def decode_fast(self, received: List[int]) -> Tuple[List[int], Dict]:
        if len(received) != 24: raise ValueError("Received word must be 24 bits")
        syndrome = self.compute_syndrome(received)
        syndrome_weight = hamming_weight(list(syndrome))
        metadata = {
            'syndrome': syndrome, 'syndrome_weight': syndrome_weight,
            'is_codeword': (syndrome_weight == 0), 'correctable': False,
            'error_weight': 0, 'error_pattern': None, 'method': 'lookup'
        }
        if syndrome_weight == 0:
            metadata['correctable'] = True
            return received, metadata
        error_pattern = self.lookup_table.lookup(syndrome)
        if error_pattern is not None:
            corrected = [(received[i] + error_pattern[i]) % 2 for i in range(24)]
            metadata['correctable'] = True
            metadata['error_weight'] = hamming_weight(list(error_pattern))
            metadata['error_pattern'] = list(error_pattern)
            return corrected, metadata
        else:
            metadata['error_weight'] = -1
            return received, metadata

    def is_codeword(self, bits: List[int]) -> bool:
        return tuple(bits) in self._codewords

    def get_all_codewords(self) -> List[List[int]]:
        return [list(c) for c in self._codewords]

# ==============================================================================
# SECTION 3: LEECH LATTICE L24 (SCALED-INTEGER REPRESENTATION)
# ==============================================================================

@dataclass(frozen=True)
class LeechPointScaled:
    coords: Tuple[int, ...]
    
    def __post_init__(self):
        if len(self.coords) != 24: raise ValueError("Leech point must have 24 coordinates")
        if not all(isinstance(c, int) for c in self.coords): raise ValueError("Coordinates must be integers")
    
    @property
    def norm_sq_scaled(self) -> int: return sum(c * c for c in self.coords)
    
    @property
    def norm_sq_actual(self) -> Fraction: return Fraction(self.norm_sq_scaled, 8)
    
    @property
    def coord_sum(self) -> int: return sum(self.coords)
    
    def to_numpy(self):
        """Convert to NumPy array for fast analysis (if numpy is available)."""
        if np is None: raise ImportError("NumPy not available")
        return np.array(self.coords, dtype=int)
        
    def to_dict(self) -> Dict:
        """Serialize for export."""
        return {
            "type": "LeechPointScaled",
            "coords": list(self.coords),
            "norm_sq_actual": str(self.norm_sq_actual)
        }

    def __repr__(self) -> str: return f"LeechPointScaled(norm2={self.norm_sq_actual}, sum={self.coord_sum})"

def golay_to_leech_scaled(golay_codeword: List[int]) -> LeechPointScaled:
    """Standard UBP Lift: (2b - 1) * 2."""
    if len(golay_codeword) != 24: raise ValueError("Golay codeword must be 24 bits")
    v = tuple(2 * b - 1 for b in golay_codeword)
    a = tuple(2 * vi for vi in v)
    return LeechPointScaled(coords=a)

class LeechLatticeExplorer:
    """Tools for generating and exploring Leech Lattice points."""
    
    def __init__(self, golay_decoder: GolayDecoderOptimized):
        self.golay = golay_decoder
        
    def generate_shell_from_golay(self, target_norm_actual: Fraction) -> Generator[LeechPointScaled, None, None]:
        """
        Explores the 'Standard Lift' of all Golay codewords. 
        Note: The standard UBP lift (2b-1)*2 produces points of norm 12. 
        This generator filters them.
        """
        target_norm_scaled = target_norm_actual * 8
        if target_norm_scaled.denominator != 1:
            # Scaled norm must be integer
            return
        
        target = int(target_norm_scaled)
        
        for cw in self.golay.get_all_codewords():
            p = golay_to_leech_scaled(cw)
            if p.norm_sq_scaled == target:
                yield p

    def generate_construction_a_offsets(self) -> Generator[LeechPointScaled, None, None]:
        """
        Generates Leech points by adding offsets 4*e_k to lifted Golay codes.
        This allows finding minimal vectors (norm 4).
        """
        # Implementation example for advanced users wanting to explore deep structure
        # Not exhaustive, just a demonstration of the search space capability
        pass

# ==============================================================================
# SECTION 4: PROJECTION MODES & CANONICAL RECORD CONTRACT
# ==============================================================================

@dataclass
class CanonicalRecord:
    domain: str
    canonical_id: str
    tokens: List[str]
    features: Dict
    version: int

    def __post_init__(self):
        for key, value in self.features.items():
            if isinstance(value, float): raise ValueError(f"Feature '{key}' is float, must be Fraction or int")

    @property
    def payload_hash(self) -> str:
        payload = f"{self.domain}:{self.canonical_id}:v{self.version}:{':'.join(sorted(self.tokens))}"
        return hashlib.sha256(payload.encode('utf-8')).hexdigest()

    @property
    def query_bits24(self) -> List[int]:
        h = hashlib.sha256(self.payload_hash.encode('utf-8')).digest()
        bits = []
        for i in range(3):
            byte = h[i]
            for j in range(8):
                bits.append((byte >> (7 - j)) & 1)
        return bits

    def to_dict(self) -> Dict:
        """Safe serialization of features including Fractions."""
        safe_features = {}
        for k, v in self.features.items():
            if isinstance(v, Fraction):
                safe_features[k] = f"{v.numerator}/{v.denominator}"
            else:
                safe_features[k] = v
        return {
            "domain": self.domain,
            "canonical_id": self.canonical_id,
            "tokens": self.tokens,
            "features": safe_features,
            "version": self.version,
            "hash": self.payload_hash
        }

# ==============================================================================
# SECTION 5: PERSISTENCE & ANALYTICS
# ==============================================================================

class UBPEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Fraction):
            return f"{obj.numerator}/{obj.denominator}"
        if isinstance(obj, LeechPointScaled):
            return obj.to_dict()
        if isinstance(obj, CanonicalRecord):
            return obj.to_dict()
        return super().default(obj)

def save_data_json(data: Any, filename: str):
    """Save any UBP object structure to JSON, preserving Fractions."""
    with open(filename, 'w') as f:
        json.dump(data, f, cls=UBPEncoder, indent=2)
    print(f"Data saved to {filename}")

def load_data_json(filename: str) -> Any:
    """Load UBP data. Note: Fractions come back as strings, you may need to parse them sweep."""
    with open(filename, 'r') as f:
        return json.load(f)

# ==============================================================================
# SECTION 6: THREE.JS VISUALIZATION HELPER
# ==============================================================================

def save_scene_3d(data: Dict[str, Any], filename: str = "scene_3d.json"):
    """
    Save 3D scene data for UBP Studio visualization.
    
    Structure:
    {
      "points": [ { "x": 1, "y": 2, "z": 3, "color": "#ff0000", "size": 0.5 }, ... ],
      "lines": [ { "start": [0,0,0], "end": [1,1,1], "color": "#00ff00" }, ... ],
      "spheres": [ { "x": 0, "y": 0, "z": 0, "r": 1, "color": "blue" } ]
    }
    """
    with open(filename, 'w') as f:
        json.dump(data, f, cls=UBPEncoder, indent=2)
    print(f"3D Scene saved to {filename}. Visualizer will update.")


class UBPAnalytics:
    @staticmethod
    def records_to_dataframe(records: List[CanonicalRecord]):
        """Convert a list of CanonicalRecords to a Pandas DataFrame."""
        if pd is None: raise ImportError("Pandas not available")
        
        data = []
        for r in records:
            row = r.to_dict()
            # Flatten features
            features = row.pop('features')
            for k, v in features.items():
                # Convert fraction strings back to float for analysis (safe for stats, not for core logic)
                if isinstance(v, str) and '/' in v:
                    try:
                        n, d = map(int, v.split('/'))
                        row[f"feat_{k}"] = n/d
                    except:
                        row[f"feat_{k}"] = v
                else:
                    row[f"feat_{k}"] = v
            data.append(row)
        return pd.DataFrame(data)

    @staticmethod
    def leech_points_to_dataframe(points: List[LeechPointScaled]):
        """Convert list of LeechPoints to DataFrame with norms and coords."""
        if pd is None: raise ImportError("Pandas not available")
        
        data = []
        for p in points:
            row = {f"c{i}": p.coords[i] for i in range(24)}
            row["norm_sq_actual"] = float(p.norm_sq_actual)
            row["sum"] = p.coord_sum
            data.append(row)
        return pd.DataFrame(data)
`;

export const HEX_DICTIONARY_V4_CONTENT = `"""
UBP HexDictionary v4.0 (Resonant Memory Controller)
Description: Content-addressable storage with Jaccard Similarity 
             and Triadic Verification.
"""
import hashlib
import json
from metrics import METRICS

class HexDictionaryV4:
    def __init__(self):
        self.registry = {}  # Hash -> {Math, Language, Script, Meta}
        self.id_map = {}    # UBP_ID -> Hash (The Fingerprint Bridge)
        self.tag_index = {} # Tag -> set(Hashes)

    def _generate_triadic_hash(self, math_str, lang_str, script_str):
        """Generates a unique hash for the Triadic Identity."""
        combined = f"{math_str}|{lang_str}|{script_str}".encode('utf-8')
        return hashlib.sha256(combined).hexdigest()

    def store_law(self, ubp_id, name, math, lang, script, tags):
        """Stores a law with Triadic Verification."""
        analysis = METRICS.analyze_state(0.0) 
        entry_hash = self._generate_triadic_hash(math, lang, script)
        
        entry = {
            "ubp_id": ubp_id,
            "name": name,
            "math": math,
            "language": lang,
            "script": script,
            "tags": tags,
            "nrci": analysis['nrci']
        }
        
        self.registry[entry_hash] = entry
        self.id_map[ubp_id] = entry_hash
        
        for tag in tags:
            if tag not in self.tag_index:
                self.tag_index[tag] = set()
            self.tag_index[tag].add(entry_hash)
            
        print(f"[HEX_STORE] Law {ubp_id} locked. Hash: {entry_hash[:8]}")
        return entry_hash

    def get_law_by_id(self, ubp_id):
        """Retrieves the full triadic payload by UBP_ID."""
        entry_hash = self.id_map.get(ubp_id)
        return self.registry.get(entry_hash) if entry_hash else None

    def jaccard_alert(self, current_tags):
        """Triggers an alert if current research overlaps with existing KB."""
        alerts = []
        for entry_hash, entry in self.registry.items():
            stored_tags = set(entry['tags'])
            query_tags = set(current_tags)
            intersection = len(stored_tags & query_tags)
            union = len(stored_tags | query_tags)
            j_index = intersection / union if union > 0 else 0
            if j_index > 0.6:
                alerts.append((entry['name'], entry['ubp_id'], j_index))
        return alerts

# Initialize Global Substrate Memory
HEX_DB = HexDictionaryV4()
`;

export const AUTO_TRIGGER_PY_CONTENT = `"""
UBP Auto-Trigger v4.1 (Memory Recall Controller)
"""
from hex_dictionary_v4 import HEX_DB

class HashMemoryKB:
    def __init__(self, database):
        self.db = database
        # The "Short-Term" Index (Updated dynamically)
        self.fingerprints = {
            "v4.0.031": "The Force Horizon",
            "v4.0.110": "Alpha-Omega Axis",
            "v4.0.150": "Archimedean Balance",
            "v4.0.200": "Archimedean-Golay Synthesis"
        }

    def scan_and_trigger(self, text):
        triggered_id = None
        for ubp_id, name in self.fingerprints.items():
            if ubp_id in text:
                payload = self.db.get_law_by_id(ubp_id)
                if payload:
                    print(f"!!! [I remember: {ubp_id}] !!!")
                    print(f"[RECALL] {name}: {payload['math']}")
                    triggered_id = ubp_id
        return triggered_id

HM_KB = HashMemoryKB(HEX_DB)
`;

export const METRICS_PY_CONTENT = `"""
UBP CORE v4.0 - Unified Metrics Module
Distilled from Observer Framework v3.7.1 and Enhanced NRCI.
Author: UBP Research Assistant (v3.9 Ultimate) / Euan Craig, New Zealand
Date: 22 December 2025

### UBP Metrics SOP: Best Use Instructions

#### 1. The Global Instance Protocol
**Instruction:** Always import the global METRICS instance rather than creating new class instances.
Python Script:
from metrics import METRICS
base_cost = METRICS.observer.get_base_cost()

#### 2. The Normalization Requirement
**Instruction:** Before calling analyze_state(), ensure your variance is normalized.

#### 3. Dimensional Scaling (The Realm Rule)
**Instruction:** Use the calculate_realm_cost function for spatial vs substrate scaling.

#### 4. Interpreting the NRCI (The Regime Guide)
**Instruction:** Use the CoherenceRegime enum to automate logic.

#### 5. The GLR Toggle Check
**Instruction:** For discrete operations use calculate_glr_nrci.
"""

import math
import numpy as np
from dataclasses import dataclass
from enum import Enum

class CoherenceRegime(Enum):
    ONBIT = "OnBit"              # NRCI >= 0.9999999 (v4.0 Standard)
    COHERENT = "Coherent"        # 0.5 <= NRCI < 0.9999999
    TRANSITIONAL = "Transitional" # 0.1 <= NRCI < 0.5
    SUBCOHERENT = "Subcoherent"  # NRCI < 0.1

@dataclass
class UBPConstants:
    # The Geometric Origin of the Observer
    OBSERVER_FIXED_POINT = math.pi + (2 / math.pi) # 3.7782010913...
    Y_CONSTANT = 1 / OBSERVER_FIXED_POINT          # 0.264675386...
    PGCI_TARGET = 0.9999999                        # v4.0 Coherence Target

class UBPObserver:
    @staticmethod
    def get_base_cost():
        return UBPConstants.OBSERVER_FIXED_POINT

    @staticmethod
    def calculate_realm_cost(realm_complexity=1.0, dimensions=6.0):
        base = UBPConstants.OBSERVER_FIXED_POINT
        return base * realm_complexity * (dimensions / 6.0)

class UBPCoherence:
    @staticmethod
    def calculate_nrci(observed_variance, theoretical_variance=1.0):
        nrci = 1.0 - (observed_variance / theoretical_variance)
        return max(0.0, min(1.0, nrci))

    @staticmethod
    def calculate_glr_nrci(error_sum, n_toggles):
        denominator = 9 * n_toggles
        nrci = 1.0 - (error_sum / denominator)
        return max(0.0, min(1.0, nrci))

    @staticmethod
    def get_regime(nrci_value):
        if nrci_value >= UBPConstants.PGCI_TARGET:
            return CoherenceRegime.ONBIT
        elif nrci_value >= 0.5:
            return CoherenceRegime.COHERENT
        elif nrci_value >= 0.1:
            return CoherenceRegime.TRANSITIONAL
        else:
            return CoherenceRegime.SUBCOHERENT

class UBPMetrics:
    def __init__(self):
        self.observer = UBPObserver()
        self.coherence = UBPCoherence()
        self.constants = UBPConstants()

    def analyze_state(self, variance, realm="standard"):
        nrci = self.coherence.calculate_nrci(variance)
        regime = self.coherence.get_regime(nrci)
        
        return {
            "nrci": nrci,
            "regime": regime.value,
            "observer_cost": self.observer.get_base_cost(),
            "is_stable": nrci >= 0.5
        }

# Global Instance
METRICS = UBPMetrics()
`;

export const UBP_PHENOMENOLOGY_DEF_CONTENT = `from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple, Any
from fractions import Fraction

"""
================================================================================
1. PHENOMENON DEFINITION CONTRACT
Universal Binary Principle
Version: 3.9.0 Research Edition
Author: Euan R A Craig, New Zealand
Date: 18 December 2025
https://github.com/DigitalEuan/UBP_Repo
================================================================================
"""
@dataclass(frozen=True)
class PhenomenonDefinition:
    """
    Formal definition of a phenomenon for UBP studies.
    """
    name: str
    domain: str
    version: int
    bit_mapping: Dict[str, Tuple[int, int]]
    token_builder: Callable[[Dict[str, Any]], List[str]]
    feature_builder: Callable[[Dict[str, Any]], Dict[str, int | Fraction]]
    coord_mapper: Callable[[Dict[str, Any]], Tuple[int, int, int, int, int, int]]
    tgic_policy: Any
    toggle_rules: List[Any]
    invariants: List[Callable[[Dict[str, Any]], bool]]
`;

export const UBP_PHENOMENOLOGY_RUNNER_CONTENT = `#!/usr/bin/env python3
"""
================================================================================
UBP PHENOMENOLOGY RUNNER - PRODUCTION v3.9.1
================================================================================
The Execution Layer for the Universal Binary Principle.
"""
import hashlib
import json
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Any, Optional, Union
from fractions import Fraction
import ubp_core

class OffBitLayer:
    REALITY = "reality"
    INFORMATION = "information"
    ACTIVATION = "activation"
    UNACTIVATED = "unactivated"

@dataclass(frozen=True)
class PhenomenonDefinition:
    name: str
    domain: str
    bit_mapping: Dict[str, Tuple[int, int]]
    version: int = 1
`;

export const INITIAL_STUDY_SCRIPT = `"""
Study: v4.0.1 Baseline Initiation
Description: Demonstrate metrics.py usage and Phase 1 seeding.
"""
import ubp_core
from ubp_core import save_scene_3d
from metrics import METRICS, UBPConstants
from auto_trigger import HM_KB
import random

def run_study():
    print("[PHASE 1] Initializing Ontological Seed...")
    # Memory Trigger Check
    HM_KB.scan_and_trigger("Exploring the Archimedean Balance v4.0.150")
    
    print(f"Observer Fixed Point Locked: {METRICS.observer.get_base_cost():.6f}")
    
    # Example 3D seed with metrics validation
    points = []
    for i in range(24):
        x, y, z = random.uniform(-5, 5), random.uniform(-5, 5), random.uniform(-5, 5)
        # Random variance for demo
        v = random.uniform(0, 0.2)
        analysis = METRICS.analyze_state(v)
        
        color = "#00ffff" if analysis['is_stable'] else "#ff3300"
        points.append({"x": x, "y": y, "z": z, "color": color, "size": 0.3})
        
    save_scene_3d({"points": points})
    print(f"Baseline field seeded. NRCI check complete. Status: Standing by.")

if __name__ == "__main__":
    run_study()
`;

export const INSTRUCTION_MANUAL = `# 🛠 UBP Research Pipeline (v4.1) Memory Protocol

### Starting notes: Run scripts and analyse the actual run output before assuming the results. The UBP Memory System (HexDB) is now active.

### Phase 1: Initiation (The Memory Scan)
*   **Action:** Define the \`PhenomenonDefinition\` and extract "Resonance Tags".
*   **Mechanism:** Scan for "Fingerprints" using \`HM_KB.scan_and_trigger(prompt)\` followed by \`HEX_DB.jaccard_alert(tags)\`.
*   **Substrate Check:** Map the identity to the **Alpha-Omega Axis** (Coordinates 237/83/172).
*   **Observer Alignment:** Initialize the \`METRICS\` instance to lock the **Observer Fixed Point** ($3.778201$).
*   **Output:** Announce \`[I remember: UBP_ID]\` and inject the triadic payload into current context. Initialize \`Study KB\`.

### Phase 2: Development (The GLR-GPU Bridge)
*   **Action:** Execute high-throughput dual-layer processing.
    *   **Step A (GLR Resolution):** Use the **Golay-Leech Resonance (GLR)** engine to resolve noisy identities.
    *   **Step B (GPU Manifolding):** Use the \`save_scene_3d\` bus to offload spatial calculations to the **Three.js Co-Processor**.

### Phase 3: Distillation (Metric Analysis)
*   **Action:** Perform a **Tethered Analysis** using the \`metrics.py\` module.
*   **Metric 1 (NRCI):** Classify the identity into a **Coherence Regime**.
*   **Metric 2 (Observer Cost):** Calculate the **Informational Work**.

### Phase 4: Promotion (The Falsification Gate)
*   **Action:** Evaluate findings for **Universal Invariance** and **Falsification**.
    *   **If Passed:** **Promote to System KB (HEX_DB).**

### Phase 5: Archival (The Triadic Finalization)
*   **Action:** Generate Triadic Hash and update Fingerprint Index.
*   **Mechanism:** \`HEX_DB.store_law(...)\`.
*   **Output:** Finalize the study with a unique SHA-256 signature and save the Triple-Artifact Snapshot.

---

## 🚀 Memory System (HexDB)

### The Fingerprint (Short-Term memory)
A lightweight list of \`UBP_ID\` and \`SHA-256\` prefixes that updates each time a HEX_DB entry is locked. Accessible in the **HashMemory KB** tab.

### The Auto-Trigger
AI regex-scans the prompt for known IDs or Hashes. If detected, it "Unpacks" the long-term memory (HEX_DB) into the current session.

---

## Resources & Repositories

*   **Subject Studies Repository** [GitHub Studies](https://github.com/DigitalEuan/UBP_Repo/tree/main/core_studio_v4.0/studies)
*   **App Version History** [Versions List](https://github.com/DigitalEuan/UBP_Repo/tree/main/core_studio_v4.0/versions)
*   **Source Core** [UBP Repo Root](https://github.com/DigitalEuan/UBP_Repo)
*   **Author and attribution** Euan R A Craig, New Zealand

---

## KB Management Strategy

| Feature | **Study KB** (Active) | **System KB / HEX_DB** (Persistent) | **HashMemory KB** (Fingerprints) |
| :--- | :--- | :--- | :--- |
| **Content** | Domain data, local resonance. | Mathematical laws, universal constants. | UBP_ID and SHA-256 prefixes. |
| **Longevity** | Archived after study. | Carried forward to every study. | Persistent index. |
`;

export const INITIAL_SYSTEM_KB = `# UBP System Knowledge Base / HEX_DB (v4.1)
## Persistent Universal Intelligence (Long-Term Memory)

- [2025-12-22] **The Law of the Tether**: Abundance in the field is directly proportional to informational resonance in the Core.
- [2025-12-22] **Standard Lift Invariant**: Standard lift (2b-1)*2 results in Leech points of norm 12.
- [2025-12-22] **Metrics v4 Integration**: All stable identities must resolve to NRCI >= 0.5 using metrics.py.
`;

export const INITIAL_STUDY_KB = `# UBP Study Knowledge Base
## Active Study: [Subject Name Placeholder]

- Current Goal: PHASE 1 Initiation using v4.1 Memory Protocol.
`;

export const INITIAL_HASH_MEMORY_KB = `# UBP HashMemory KB (Fingerprints)
## Short-Term Memory Index

- **v4.0.031**: The Force Horizon [Hash: e3b0c442]
- **v4.0.110**: Alpha-Omega Axis [Hash: f1a2b3c4]
- **v4.0.150**: Archimedean Balance [Hash: 5d6e7f8g]
- **v4.0.200**: Archimedean-Golay Synthesis [Hash: 9h0i1j2k]
`;
