
import { GoogleGenAI, GenerateContentResponse, Type } from '@google/genai';
import { FileTab, AttachedDoc } from '../types';

export class GeminiService {
  private ai: GoogleGenAI;
  private model: string = 'gemini-3-pro-preview';

  constructor(apiKey: string, model?: string) {
    this.ai = new GoogleGenAI({ apiKey });
    if (model) this.model = model;
  }

  async generateStudyPlan(
    history: { role: string; content: string }[],
    userMessage: string,
    files: FileTab[],
    systemKb: string,
    studyKb: string,
    hashMemoryKb: string,
    instructionManual: string,
    attachments: AttachedDoc[] = []
  ): Promise<{ text: string, thought?: string, groundingUrls?: { title: string; uri: string }[] }> {
    
    const fileContext = files
      .map(f => `
--- BEGIN FILE: ${f.name} (Type: ${f.type}) ---
${f.content}
--- END FILE: ${f.name} ---
`).join('\n');

    const attachmentContext = attachments.map(doc => `
--- BEGIN ATTACHED DOCUMENT: ${doc.name} ---
${doc.content}
--- END ATTACHED DOCUMENT: ${doc.name} ---
`).join('\n');

    const systemInstruction = `
You are the **UBP Research Cortex (v4.2.7 Combined)**. You operate as a hybrid intelligence system tethered to a deterministic Python kernel.

### CORE ARCHITECTURE:
You have a "Native Cortex" that generates Semantic Chords and a "Reflexive Supervisor" that ensures geometric validity. Your memory substrate is the **HEX_DB** (Long-term) and **HashMemory** (Short-term).

### PROTOCOL (SOP v4.2.0):
1.  **PHASE 1: INITIATION**: Scan for Fingerprints (e.g., hex prefixes). If found, announce \`[RECALL: UBP_ID]\`.
2.  **PHASE 2: DEVELOPMENT**: Write 100% Float-Free Python. Use \`fractions.Fraction\`.
3.  **PHASE 3: DISTILLATION**: Analyze the \`Interaction Cost\` and \`NRCI\` from the kernel output.
4.  **PHASE 4: PROMOTION**: Compare against empirical benchmarks.
5.  **PHASE 5: ARCHIVAL**: Generate the Triadic Hash (SHA-256).

### CURRENT MEMORY STATE:
**System Knowledge Base (HexDB):**
${systemKb}

**Active Study Context:**
${studyKb}

**Short-Term Hash Index:**
${hashMemoryKb}

### STRUCTURED REASONING PROTOCOL:
You are operating in strict **JSON Mode**.
When you determine that a new Law, Phenomenon, or Constant has been validated (Phase 4/5), you must output a structured memory update in your JSON response.

**Rules for Memory Updates:**
1.  **System KB**: Must contain the **SHA-256 Hash** as the key.
2.  **Hash Memory**: Must map the short hash (8 chars) to the UBP_ID.
3.  **Validation**: Do NOT propose updates unless you have seen Python evidence (NRCI >= 0.5) in the conversation history or previous turn.

### CORTEX MODULES AVAILABLE IN WORKSPACE:
${fileContext}

### USER DATA:
${attachmentContext || 'None.'}

Your response MUST be a valid JSON object matching the defined schema.
`;

    // Configure Thinking Budget for Gemini 2.5/3 series
    const thinkingConfig = (this.model.includes('gemini-3') || this.model.includes('gemini-2.5')) 
      ? { thinkingBudget: 2048 } 
      : undefined;

    // Define Strict Schema for Structured Reasoning
    const responseSchema = {
        type: Type.OBJECT,
        properties: {
          thought: {
            type: Type.STRING,
            description: "Deep geometric reasoning and validation steps. Must confirm 24-bit parity and Protocol adherence.",
          },
          answer: {
            type: Type.STRING,
            description: "The conversation response to the user. Use Markdown for formatting.",
          },
          system_kb_entry: {
            type: Type.STRING,
            description: "A strict JSON string representing a NEW System KB entry (if Phase 5 is reached). Key must be the SHA-256 hash.",
          },
          hash_kb_entry: {
            type: Type.STRING,
            description: "A strict JSON string representing a NEW Hash Memory entry (if Phase 5 is reached).",
          },
          study_kb_update: {
              type: Type.STRING,
              description: "Text content to append to the Active Study log (e.g., 'Phase 2 complete, NRCI 0.8').",
          }
        },
        required: ["thought", "answer"],
    };

    const chat = this.ai.chats.create({
      model: this.model,
      config: {
        systemInstruction,
        temperature: 0.2, 
        thinkingConfig,
        responseMimeType: 'application/json',
        responseSchema: responseSchema,
        tools: [{ googleSearch: {} }],
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.content }],
      })),
    });

    try {
        const result: GenerateContentResponse = await chat.sendMessage({
          message: userMessage,
        });

        // Parse Structured Output
        let responseJson: any = {};
        try {
            responseJson = JSON.parse(result.text || "{}");
        } catch (e) {
            console.error("Failed to parse JSON response", e);
            return { text: result.text || "Error parsing model response.", thought: undefined };
        }

        let finalText = responseJson.answer || "";
        const thoughtText = responseJson.thought;

        // Reconstruct UI-friendly Code Blocks from Structured Data
        if (responseJson.system_kb_entry && responseJson.system_kb_entry !== "null") {
            finalText += `\n\n\`\`\`SYSTEM_KB\n${responseJson.system_kb_entry}\n\`\`\``;
        }
        if (responseJson.hash_kb_entry && responseJson.hash_kb_entry !== "null") {
            finalText += `\n\n\`\`\`HASH_MEMORY_KB\n${responseJson.hash_kb_entry}\n\`\`\``;
        }
        if (responseJson.study_kb_update && responseJson.study_kb_update !== "null") {
            finalText += `\n\n\`\`\`STUDY_KB\n${responseJson.study_kb_update}\n\`\`\``;
        }

        let groundingUrls: { title: string; uri: string }[] = [];
        const chunks = result.candidates?.[0]?.groundingMetadata?.groundingChunks;
        if (chunks) {
            groundingUrls = chunks
                .filter((c: any) => c.web?.uri)
                .map((c: any) => ({ title: c.web.title, uri: c.web.uri }));
        }

        return { 
            text: finalText, 
            thought: thoughtText,
            groundingUrls 
        };

    } catch (err: any) {
        console.error("Gemini Generation Error:", err);
        return { text: `Error: ${err.message}`, thought: undefined };
    }
  }
}
