
import React, { useMemo, useState } from 'react';

interface MemoryStatusProps {
  systemKb: string;
  hashMemoryKb: string;
  studyKb?: string;
}

interface ParsedEntry {
  id: string;
  name: string;
  tags: string[];
  fingerprint?: string;
  nrci?: number;
  raw: string;
  category: string; // Now represents Geometric Domain
}

interface CategoryStat {
  code: string;
  count: number;
  description: string;
  percent: string;
}

export const MemoryStatus: React.FC<MemoryStatusProps> = ({ systemKb, hashMemoryKb, studyKb }) => {

  const { parsedSystem, categoryStats } = useMemo(() => {
    const entries: ParsedEntry[] = [];
    let validJsonCount = 0;
    let markdownCount = 0;

    // --- GEOMETRIC DOMAIN MAPPER (The Octad) ---
    const categorize = (name: string, tags: string[] = []): string => {
        const combined = [...tags, name].map(s => s.toUpperCase());
        
        // 1. Explicit Geometric Tags (High Priority)
        if (combined.includes('SUBSTANCE')) return 'SUBSTANCE';
        if (combined.includes('ORGANISM')) return 'ORGANISM';
        if (combined.includes('ALGORITHM')) return 'ALGORITHM';
        if (combined.includes('QUANTITY')) return 'QUANTITY';
        if (combined.includes('MECHANISM')) return 'MECHANISM';
        if (combined.includes('IMPERATIVE')) return 'IMPERATIVE';
        if (combined.includes('ENTROPY')) return 'ENTROPY';
        if (combined.includes('MEANING')) return 'MEANING';

        // 2. Pattern Inference (Based on Study Findings)
        // SUBSTANCE: Elements, Stable Matter, Minerals
        if (name.startsWith('ELEM_') || name.startsWith('MAT_') || combined.some(s => s.includes('MINERAL') || s.includes('PLASTIC') || s.includes('GRAPHENE'))) return 'SUBSTANCE';
        
        // ORGANISM: Biology, Complex Systems, Life
        if (name.startsWith('BIO') || name.startsWith('CELL') || combined.some(s => s.includes('LIFE') || s.includes('CANCER') || s.includes('ORGANIC'))) return 'ORGANISM';
        
        // ALGORITHM: Code, Logic, Information, Relativity
        if (name.startsWith('ALGO') || name.startsWith('CODE') || name.startsWith('INFO') || combined.some(s => s.includes('LOGIC') || s.includes('FRACTAL'))) return 'ALGORITHM';
        
        // QUANTITY: Numbers, Constants, Measurements
        if (name.startsWith('NUM') || name.startsWith('CONST') || name.startsWith('BIN_') || combined.some(s => s.includes('METRIC'))) return 'QUANTITY';
        
        // MECHANISM: Physics interactions, Reactions
        if (name.startsWith('MECH') || name.startsWith('PHYS') || name.startsWith('REACT') || combined.some(s => s.includes('FORCE'))) return 'MECHANISM';
        
        // IMPERATIVE: Laws (Default), Commands, Constraints
        if (name.startsWith('LAW') || combined.some(s => s.includes('RULE') || s.includes('AXIOM'))) return 'IMPERATIVE';
        
        // ENTROPY: Chaos, Void, Uncertainty
        if (combined.some(s => s.includes('CHAOS') || s.includes('VOID') || s.includes('NULL'))) return 'ENTROPY';
        
        // MEANING: Language, Semantics
        if (name.startsWith('WORD') || combined.some(s => s.includes('TERM') || s.includes('SEMANTIC'))) return 'MEANING';

        return 'UNCATEGORIZED'; 
    };

    // 1. Try to parse as a big JSON object/array
    try {
        const json = JSON.parse(systemKb || "[]");
        const list = Array.isArray(json) ? json : Object.values(json);
        list.forEach((item: any) => {
            const tags = item.tags || [];
            entries.push({
                id: item.ubp_id || 'UNKNOWN',
                name: item.name || 'Untitled',
                tags: tags,
                fingerprint: item.fingerprint,
                nrci: item.nrci,
                raw: 'JSON Object',
                category: categorize(item.name || '', tags)
            });
            validJsonCount++;
        });
    } catch (e) {
        // 2. Fallback to Markdown Line Parsing
        const lines = (systemKb || "").split('\n');
        lines.forEach(line => {
            const match = line.match(/^\- \[(.*?)\] \*\*(.*?)\*\*: (.*)/);
            if (match) {
                const content = match[3];
                const tagMatch = content.match(/Tags: (.*?)$/);
                const tags = tagMatch ? tagMatch[1].split(',').map(t => t.trim()) : [];
                const name = content.split('\n')[0]; 

                entries.push({
                    id: match[2],
                    name: name,
                    tags: tags,
                    raw: 'Markdown Line',
                    category: categorize(name, tags)
                });
                markdownCount++;
            } else if (line.trim().startsWith('{')) {
                try {
                   const item = JSON.parse(line.trim().replace(/,$/, ''));
                   const tags = item.tags || [];
                   entries.push({
                       id: item.ubp_id || 'UNKNOWN',
                       name: item.name || 'Untitled',
                       tags: tags,
                       fingerprint: item.fingerprint,
                       nrci: item.nrci,
                       raw: 'JSON Line',
                       category: categorize(item.name || '', tags)
                   });
                   validJsonCount++;
                } catch(err) {}
            }
        });
    }

    // Aggregate Stats
    const statsMap: Record<string, number> = {};
    const total = entries.length;
    entries.forEach(e => {
        statsMap[e.category] = (statsMap[e.category] || 0) + 1;
    });

    const categoryStats: CategoryStat[] = Object.entries(statsMap)
        .map(([code, count]) => {
            let desc = "Unknown Domain";
            switch(code) {
                case 'SUBSTANCE': desc = "Stable Matter & Elements (Bit 12=1)"; break;
                case 'ORGANISM': desc = "Biological & Complex Systems"; break;
                case 'ALGORITHM': desc = "Logic, Code & Information"; break;
                case 'QUANTITY': desc = "Pure Magnitude & Constants (Bit 12=0)"; break;
                case 'MECHANISM': desc = "Physical Interactions & Reactions"; break;
                case 'IMPERATIVE': desc = "System Laws & Constraints"; break;
                case 'ENTROPY': desc = "Chaos, Void & Dissolution"; break;
                case 'MEANING': desc = "Semantic & Linguistic Value"; break;
            }
            return { 
                code, 
                count, 
                description: desc,
                percent: total > 0 ? ((count / total) * 100).toFixed(1) + '%' : '0%'
            };
        })
        .sort((a, b) => b.count - a.count);

    return { parsedSystem: { entries, validJsonCount, markdownCount }, categoryStats };
  }, [systemKb]);

  const parsedHash = useMemo(() => {
     let count = 0;
     const targetKb = hashMemoryKb || "";
     try {
         const json = JSON.parse(targetKb);
         if (typeof json === 'object') {
             count = Array.isArray(json) ? json.length : Object.keys(json).length;
         }
     } catch (e) {
         const lines = targetKb.split('\n');
         lines.forEach(line => {
             const trimmed = line.trim();
             if (!trimmed || trimmed.startsWith('#')) return;
             if (trimmed.startsWith('-') || /^[a-zA-Z0-9_\-\.]+:/.test(trimmed)) {
                 count++;
             }
         });
     }
     return count;
  }, [hashMemoryKb]);

  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  // Filter entries if a category row is clicked
  const filteredEntries = useMemo(() => {
    if (!expandedCategory) return parsedSystem.entries;
    return parsedSystem.entries.filter(e => e.category === expandedCategory);
  }, [parsedSystem.entries, expandedCategory]);

  return (
    <div className="flex flex-col h-full bg-[#111] overflow-hidden">
      
      {/* Header Stats */}
      <div className="grid grid-cols-3 gap-2 p-4 border-b border-gray-800 bg-[#151515]">
        <div className="bg-purple-900/20 border border-purple-500/30 p-3 rounded">
            <div className="text-[10px] uppercase text-purple-400 font-bold tracking-widest">Geometric Nodes</div>
            <div className="text-2xl font-mono text-white">{parsedSystem.entries.length}</div>
        </div>
        <div className="bg-blue-900/20 border border-blue-500/30 p-3 rounded">
            <div className="text-[10px] uppercase text-blue-400 font-bold tracking-widest">Octad Integrity</div>
            <div className="text-xl font-mono text-white">
                {parsedSystem.validJsonCount > 0 ? 'V4.2 STRUCTURED' : 'LEGACY MODE'}
            </div>
        </div>
        <div className="bg-gray-800/40 border border-gray-700 p-3 rounded">
             <div className="text-[10px] uppercase text-gray-400 font-bold tracking-widest">Active Hash</div>
             <div className="text-xl font-mono text-white">{parsedHash} keys</div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-4 scrollbar-thin">
         
         {/* Category Table */}
         <div className="mb-6 border border-gray-800 rounded overflow-hidden">
            <table className="w-full text-left border-collapse">
                <thead>
                    <tr className="bg-[#1a1a1a] border-b border-gray-800 text-[10px] text-gray-500 uppercase tracking-widest">
                        <th className="p-2 pl-3 font-bold">Geometric Domain</th>
                        <th className="p-2 font-bold">Count</th>
                        <th className="p-2 font-bold text-right">%</th>
                        <th className="p-2 font-bold">Description</th>
                    </tr>
                </thead>
                <tbody className="text-xs font-mono">
                    {categoryStats.length === 0 ? (
                        <tr><td colSpan={4} className="p-3 text-center text-gray-600">No geometric data available.</td></tr>
                    ) : (
                        categoryStats.map((stat) => (
                            <tr 
                                key={stat.code} 
                                onClick={() => setExpandedCategory(expandedCategory === stat.code ? null : stat.code)}
                                className={`cursor-pointer transition-colors ${expandedCategory === stat.code ? 'bg-purple-900/20 text-white' : 'hover:bg-[#222] text-gray-400'}`}
                            >
                                <td className={`p-2 pl-3 font-bold ${expandedCategory === stat.code ? 'text-purple-400' : 'text-gray-500'}`}>
                                    <div className="flex items-center gap-2">
                                        <div className={`w-2 h-2 rounded-full ${
                                            stat.code === 'SUBSTANCE' ? 'bg-orange-500' :
                                            stat.code === 'ORGANISM' ? 'bg-green-500' :
                                            stat.code === 'ALGORITHM' ? 'bg-blue-500' :
                                            stat.code === 'QUANTITY' ? 'bg-red-500' :
                                            'bg-gray-500'
                                        }`} />
                                        {stat.code}
                                    </div>
                                </td>
                                <td className="p-2 text-white">{stat.count}</td>
                                <td className="p-2 text-right text-gray-400">{stat.percent}</td>
                                <td className="p-2 text-gray-500 italic">{stat.description}</td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
         </div>

         <div className="flex justify-between items-end mb-2">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">
                {expandedCategory ? `Domain: ${expandedCategory}` : 'Full Geometric Registry'}
            </h3>
            {expandedCategory && (
                <button onClick={() => setExpandedCategory(null)} className="text-[10px] text-blue-400 hover:text-white uppercase">Show All</button>
            )}
         </div>
         
         <div className="space-y-2">
            {filteredEntries.length === 0 ? (
                <div className="text-center p-8 text-gray-600 italic border border-dashed border-gray-800 rounded">
                    Memory is empty or unreadable.
                </div>
            ) : (
                filteredEntries.map((entry, idx) => (
                    <div key={idx} className="bg-[#1a1a1a] border border-gray-800 p-3 rounded hover:border-purple-500/50 transition-colors group">
                        <div className="flex justify-between items-start mb-1">
                            <div className="flex items-center gap-2">
                                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border border-white/10 ${
                                    entry.category === 'SUBSTANCE' ? 'bg-orange-900/40 text-orange-400' :
                                    entry.category === 'ORGANISM' ? 'bg-green-900/40 text-green-400' :
                                    entry.category === 'ALGORITHM' ? 'bg-blue-900/40 text-blue-400' :
                                    entry.category === 'QUANTITY' ? 'bg-red-900/40 text-red-400' :
                                    'bg-gray-800 text-gray-500'
                                }`}>{entry.category}</span>
                                <span className="text-sm font-bold text-gray-200 font-mono group-hover:text-white transition-colors">{entry.id}</span>
                            </div>
                            {entry.nrci && (
                                <span className={`text-[9px] px-1.5 rounded ${entry.nrci >= 0.5 ? 'bg-green-900/50 text-green-200' : 'bg-red-900/50 text-red-200'}`}>
                                    NRCI: {entry.nrci}
                                </span>
                            )}
                        </div>
                        <div className="text-xs text-gray-400 mb-2 pl-1">{entry.name}</div>
                        
                        <div className="flex flex-wrap gap-2 items-center">
                            {entry.tags.map((tag, tIdx) => (
                                <span key={tIdx} className="text-[9px] bg-gray-800 text-gray-500 px-1.5 py-0.5 rounded border border-gray-700">#{tag}</span>
                            ))}
                            {entry.fingerprint && (
                                <span className="text-[9px] font-mono text-gray-600 bg-black px-1 rounded truncate max-w-[100px]" title={entry.fingerprint}>
                                    {entry.fingerprint.substring(0, 8)}...
                                </span>
                            )}
                        </div>
                    </div>
                ))
            )}
         </div>
      </div>
      
      <div className="p-2 border-t border-gray-800 bg-[#0d0d0d] text-[10px] text-gray-500 text-center font-mono">
          UBP Geometric Categorization Engine (Octad v1.0)
      </div>
    </div>
  );
};
