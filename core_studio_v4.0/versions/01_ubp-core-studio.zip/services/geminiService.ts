import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import { DEFAULT_UBP_CORE } from '../constants';
import { FileTab } from '../types';

export class GeminiService {
  private ai: GoogleGenAI;
  private model: string = 'gemini-3-flash-preview';

  constructor(apiKey: string) {
    this.ai = new GoogleGenAI({ apiKey });
  }

  async generateStudyPlan(
    history: { role: string; content: string }[],
    userMessage: string,
    files: FileTab[]
  ): Promise<{ text: string, groundingUrls?: { title: string; uri: string }[] }> {
    
    // Filter out the core library to save context window space, focus on user work
    // or include it if you prefer. Here we include user scripts and data.
    const fileContext = files
      .filter(f => f.type !== 'core')
      .map(f => `
--- BEGIN FILE: ${f.name} ---
${f.content}
--- END FILE: ${f.name} ---
`).join('\n');

    const systemInstruction = `
You are the UBP Research Assistant (v3.9). You are an expert in the Universal Binary Principle system.
The user has a Python core loaded in a Pyodide environment named 'ubp_core'.

FEATURES & CAPABILITIES:
1. **Zero-Float Policy**: Use 'fractions.Fraction' for non-integer math in the core logic.
2. **Visuals**: 
   - 2D: Generate graphs using 'matplotlib.pyplot'. Save plots to 'plot.png'.
   - 3D: Use \`ubp_core.save_scene_3d(data)\` to trigger the interactive Three.js viewer. 
     Structure: { "points": [{"x":0,"y":0,"z":0, "color": "#ff0000", "size": 0.2}], "lines": [], "spheres": [] }
3. **Google Search**: Access real-world data via search tools.
4. **Persistence & IO**: 
   - Use \`ubp_core.save_data_json(data, "filename.json")\` to save results.
   - **Output Directory**: You can write files to the "output/" directory (e.g., "output/report.txt").
   - Use standard Python \`csv\` module for CSV exports.
5. **Data Science Stack**: 
   - **NumPy** and **Pandas** and **SciPy** are available.
   - Use \`ubp_core.UBPAnalytics.records_to_dataframe(records)\` to convert UBP objects to Pandas DataFrames.

CORE MODULES AVAILABLE:
- \`ubp_core\`: Main engine (Golay, Leech, Analytics).
- \`ubp_phenomenology_def\`: Contracts for defining phenomena (PhenomenonDefinition).
- \`ubp_phenomenology_runner\`: Execution engine for phenomenology studies (Bitfield6D, TGIC, OffBit24).

ENVIRONMENT:
- All workspace scripts (including ubp_core.py) are located in \`/home/pyodide\`.
- This directory is automatically added to \`sys.path\`.
- You can simply \`import ubp_core\` or \`from ubp_phenomenology_def import ...\` in any script.

WORK CONTEXT:
The following files are currently open in the user's workspace.
${fileContext}

When asked to perform a study or calculation:
1. Write a complete Python script.
2. Import necessary modules (ubp_core, ubp_phenomenology_def, etc.).
3. Wrap the Python code in \`\`\`python ... \`\`\` blocks.

--- BEGIN UBP CORE DEF ---
${DEFAULT_UBP_CORE}
--- END UBP CORE DEF ---
`;

    const chat = this.ai.chats.create({
      model: this.model,
      config: {
        systemInstruction,
        temperature: 0.2,
        tools: [{ googleSearch: {} }], // Enable Internet Access
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.content }],
      })),
    });

    const result: GenerateContentResponse = await chat.sendMessage({
      message: userMessage,
    });

    // Extract grounding metadata
    let groundingUrls: { title: string; uri: string }[] = [];
    const chunks = result.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
        groundingUrls = chunks
            .filter((c: any) => c.web?.uri)
            .map((c: any) => ({ title: c.web.title, uri: c.web.uri }));
    }

    return { 
        text: result.text || "", 
        groundingUrls 
    };
  }
}
