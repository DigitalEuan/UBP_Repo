export interface ChatMessage {
  id: string;
  role: 'user' | 'model' | 'system';
  content: string;
  codeBlock?: string;
  isError?: boolean;
  timestamp: number;
  groundingUrls?: { title: string; uri: string }[];
}

export type PyodideInterface = any;

export interface Scene3DData {
  points?: Array<{ x: number, y: number, z: number, color?: string, size?: number }>;
  lines?: Array<{ start: [number, number, number], end: [number, number, number], color?: string }>;
  spheres?: Array<{ x: number, y: number, z: number, r: number, color?: string }>;
}

export interface ExecutionResult {
  stdout: string;
  stderr: string;
  error?: string;
  image?: string; // Base64 image string if a plot was generated
  scene3d?: Scene3DData; // 3D Scene data
}

export enum TabView {
  EDITOR = 'EDITOR',
  VISUALS = 'VISUALS'
}

export interface FileTab {
  name: string;
  content: string;
  type: 'script' | 'core' | 'data';
}