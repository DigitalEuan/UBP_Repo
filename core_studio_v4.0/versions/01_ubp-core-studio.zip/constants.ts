export const DEFAULT_UBP_CORE = `#!/usr/bin/env python3
"""
================================================================================
UBP CORE - ULTIMATE PRODUCTION MODULE
================================================================================

Universal Binary Principle - Core Mathematical Engine
Version: 3.9.0 Research Edition
Author: Euan R A Craig, New Zealand
Date: 18 December 2025
https://github.com/DigitalEuan/UBP_Repo

"""

from dataclasses import dataclass, asdict, field
from typing import List, Tuple, Dict, Optional, Set, Any, Generator
from fractions import Fraction
import hashlib
import itertools
import time
import json
import csv

# Integration imports (lazy loaded in functions or assumed available in env)
try:
    import numpy as np
    import pandas as pd
except ImportError:
    np = None
    pd = None

# ==============================================================================
# SECTION 1: BINARY LINEAR ALGEBRA OVER GF(2)
# ==============================================================================

def _identity(n: int) -> List[List[int]]:
    return [[1 if i == j else 0 for j in range(n)] for i in range(n)]

def _transpose(M: List[List[int]]) -> List[List[int]]:
    if not M: return []
    return [[M[i][j] for i in range(len(M))] for j in range(len(M[0]))]

def _binary_matmul(A: List[List[int]], B: List[List[int]]) -> List[List[int]]:
    if not A or not B: return []
    rows_A, cols_A, cols_B = len(A), len(A[0]), len(B[0])
    if cols_A != len(B): raise ValueError(f"Matrix dimensions incompatible: {cols_A} != {len(B)}")
    result = []
    for i in range(rows_A):
        row = []
        for j in range(cols_B):
            val = sum(A[i][k] * B[k][j] for k in range(cols_A)) % 2
            row.append(val)
        result.append(row)
    result.append(row)
    return result

def hamming_weight(v: List[int]) -> int:
    return sum(v)

def hamming_distance(a: List[int], b: List[int]) -> int:
    if len(a) != len(b): raise ValueError("Vectors must have same length")
    return sum(1 for i in range(len(a)) if a[i] != b[i])

# ==============================================================================
# SECTION 2: BINARY GOLAY CODE G24
# ==============================================================================

_GOLAY_A = [
    [1,1,0,1,1,1,0,0,0,1,0,1], [1,0,1,1,1,0,0,0,1,0,1,1], [0,1,1,1,0,0,0,1,0,1,1,1],
    [1,1,1,0,0,0,1,0,1,1,0,1], [1,1,0,0,0,1,0,1,1,0,1,1], [1,0,0,0,1,0,1,1,0,1,1,1],
    [0,0,0,1,0,1,1,0,1,1,1,1], [0,0,1,0,1,1,0,1,1,1,0,1], [0,1,0,1,1,0,1,1,1,0,0,1],
    [1,0,1,1,0,1,1,1,0,0,0,1], [0,1,1,0,1,1,1,0,0,0,1,1], [1,1,1,1,1,1,1,1,1,1,1,0]
]
_I12 = _identity(12)
_G = [i + a for i, a in zip(_I12, _GOLAY_A)]
_H = [_a + i for _a, i in zip(_transpose(_GOLAY_A), _I12)]

@dataclass
class SyndromeLookupTable:
    syndrome_to_error: Dict[Tuple[int, ...], Tuple[int, ...]]
    error_weight_dist: Dict[int, int]
    build_time: float
    table_size: int

    def lookup(self, syndrome: Tuple[int, ...]) -> Optional[Tuple[int, ...]]:
        return self.syndrome_to_error.get(syndrome, None)

def build_syndrome_lookup_table(max_error_weight: int = 3) -> SyndromeLookupTable:
    start_time = time.time()
    syndrome_to_error = {}
    error_weight_dist = {w: 0 for w in range(max_error_weight + 1)}
    for weight in range(max_error_weight + 1):
        for error_positions in itertools.combinations(range(24), weight):
            error = [0] * 24
            for pos in error_positions: error[pos] = 1
            e_col = [[b] for b in error]
            syndrome_col = _binary_matmul(_H, e_col)
            syndrome = tuple(row[0] for row in syndrome_col)
            if syndrome not in syndrome_to_error:
                syndrome_to_error[syndrome] = tuple(error)
                error_weight_dist[weight] += 1
    return SyndromeLookupTable(syndrome_to_error, error_weight_dist, time.time() - start_time, len(syndrome_to_error))

class GolayDecoderOptimized:
    def __init__(self, verbose: bool = False):
        self.G = _G
        self.H = _H
        self.verbose = verbose
        if verbose: print("Building syndrome lookup table...")
        self.lookup_table = build_syndrome_lookup_table(max_error_weight=3)
        if verbose: print("Generating all codewords...")
        self._codewords = self._generate_all_codewords()

    def _generate_all_codewords(self) -> Set[Tuple[int, ...]]:
        codewords = set()
        for msg_int in range(4096):
            msg = [(msg_int >> i) & 1 for i in range(12)]
            codewords.add(tuple(self.encode(msg)))
        return codewords

    def encode(self, message: List[int]) -> List[int]:
        if len(message) != 12: raise ValueError("Message must be 12 bits")
        return _binary_matmul([message], self.G)[0]

    def compute_syndrome(self, received: List[int]) -> Tuple[int, ...]:
        if len(received) != 24: raise ValueError("Received word must be 24 bits")
        r_col = [[b] for b in received]
        return tuple(row[0] for row in _binary_matmul(self.H, r_col))

    def decode_fast(self, received: List[int]) -> Tuple[List[int], Dict]:
        if len(received) != 24: raise ValueError("Received word must be 24 bits")
        syndrome = self.compute_syndrome(received)
        syndrome_weight = hamming_weight(list(syndrome))
        metadata = {
            'syndrome': syndrome, 'syndrome_weight': syndrome_weight,
            'is_codeword': (syndrome_weight == 0), 'correctable': False,
            'error_weight': 0, 'error_pattern': None, 'method': 'lookup'
        }
        if syndrome_weight == 0:
            metadata['correctable'] = True
            return received, metadata
        error_pattern = self.lookup_table.lookup(syndrome)
        if error_pattern is not None:
            corrected = [(received[i] + error_pattern[i]) % 2 for i in range(24)]
            metadata['correctable'] = True
            metadata['error_weight'] = hamming_weight(list(error_pattern))
            metadata['error_pattern'] = list(error_pattern)
            return corrected, metadata
        else:
            metadata['error_weight'] = -1
            return received, metadata

    def is_codeword(self, bits: List[int]) -> bool:
        return tuple(bits) in self._codewords

    def get_all_codewords(self) -> List[List[int]]:
        return [list(c) for c in self._codewords]

# ==============================================================================
# SECTION 3: LEECH LATTICE L24 (SCALED-INTEGER REPRESENTATION)
# ==============================================================================

@dataclass(frozen=True)
class LeechPointScaled:
    coords: Tuple[int, ...]
    
    def __post_init__(self):
        if len(self.coords) != 24: raise ValueError("Leech point must have 24 coordinates")
        if not all(isinstance(c, int) for c in self.coords): raise ValueError("Coordinates must be integers")
    
    @property
    def norm_sq_scaled(self) -> int: return sum(c * c for c in self.coords)
    
    @property
    def norm_sq_actual(self) -> Fraction: return Fraction(self.norm_sq_scaled, 8)
    
    @property
    def coord_sum(self) -> int: return sum(self.coords)
    
    def to_numpy(self):
        """Convert to NumPy array for fast analysis (if numpy is available)."""
        if np is None: raise ImportError("NumPy not available")
        return np.array(self.coords, dtype=int)
        
    def to_dict(self) -> Dict:
        """Serialize for export."""
        return {
            "type": "LeechPointScaled",
            "coords": list(self.coords),
            "norm_sq_actual": str(self.norm_sq_actual)
        }

    def __repr__(self) -> str: return f"LeechPointScaled(norm2={self.norm_sq_actual}, sum={self.coord_sum})"

def golay_to_leech_scaled(golay_codeword: List[int]) -> LeechPointScaled:
    """Standard UBP Lift: (2b - 1) * 2."""
    if len(golay_codeword) != 24: raise ValueError("Golay codeword must be 24 bits")
    v = tuple(2 * b - 1 for b in golay_codeword)
    a = tuple(2 * vi for vi in v)
    return LeechPointScaled(coords=a)

class LeechLatticeExplorer:
    """Tools for generating and exploring Leech Lattice points."""
    
    def __init__(self, golay_decoder: GolayDecoderOptimized):
        self.golay = golay_decoder
        
    def generate_shell_from_golay(self, target_norm_actual: Fraction) -> Generator[LeechPointScaled, None, None]:
        """
        Explores the 'Standard Lift' of all Golay codewords. 
        Note: The standard UBP lift (2b-1)*2 produces points of norm 12. 
        This generator filters them.
        """
        target_norm_scaled = target_norm_actual * 8
        if target_norm_scaled.denominator != 1:
            # Scaled norm must be integer
            return
        
        target = int(target_norm_scaled)
        
        for cw in self.golay.get_all_codewords():
            p = golay_to_leech_scaled(cw)
            if p.norm_sq_scaled == target:
                yield p

    def generate_construction_a_offsets(self) -> Generator[LeechPointScaled, None, None]:
        """
        Generates Leech points by adding offsets 4*e_k to lifted Golay codes.
        This allows finding minimal vectors (norm 4).
        """
        # Implementation example for advanced users wanting to explore deep structure
        # Not exhaustive, just a demonstration of the search space capability
        pass

# ==============================================================================
# SECTION 4: PROJECTION MODES & CANONICAL RECORD CONTRACT
# ==============================================================================

@dataclass
class CanonicalRecord:
    domain: str
    canonical_id: str
    tokens: List[str]
    features: Dict
    version: int

    def __post_init__(self):
        for key, value in self.features.items():
            if isinstance(value, float): raise ValueError(f"Feature '{key}' is float, must be Fraction or int")

    @property
    def payload_hash(self) -> str:
        payload = f"{self.domain}:{self.canonical_id}:v{self.version}:{':'.join(sorted(self.tokens))}"
        return hashlib.sha256(payload.encode('utf-8')).hexdigest()

    @property
    def query_bits24(self) -> List[int]:
        h = hashlib.sha256(self.payload_hash.encode('utf-8')).digest()
        bits = []
        for i in range(3):
            byte = h[i]
            for j in range(8):
                bits.append((byte >> (7 - j)) & 1)
        return bits

    def to_dict(self) -> Dict:
        """Safe serialization of features including Fractions."""
        safe_features = {}
        for k, v in self.features.items():
            if isinstance(v, Fraction):
                safe_features[k] = f"{v.numerator}/{v.denominator}"
            else:
                safe_features[k] = v
        return {
            "domain": self.domain,
            "canonical_id": self.canonical_id,
            "tokens": self.tokens,
            "features": safe_features,
            "version": self.version,
            "hash": self.payload_hash
        }

# ==============================================================================
# SECTION 5: PERSISTENCE & ANALYTICS
# ==============================================================================

class UBPEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Fraction):
            return f"{obj.numerator}/{obj.denominator}"
        if isinstance(obj, LeechPointScaled):
            return obj.to_dict()
        if isinstance(obj, CanonicalRecord):
            return obj.to_dict()
        return super().default(obj)

def save_data_json(data: Any, filename: str):
    """Save any UBP object structure to JSON, preserving Fractions."""
    with open(filename, 'w') as f:
        json.dump(data, f, cls=UBPEncoder, indent=2)
    print(f"Data saved to {filename}")

def load_data_json(filename: str) -> Any:
    """Load UBP data. Note: Fractions come back as strings, you may need to parse them."""
    with open(filename, 'r') as f:
        return json.load(f)

# ==============================================================================
# SECTION 6: THREE.JS VISUALIZATION HELPER
# ==============================================================================

def save_scene_3d(data: Dict[str, Any], filename: str = "scene_3d.json"):
    """
    Save 3D scene data for UBP Studio visualization.
    
    Structure:
    {
      "points": [ { "x": 1, "y": 2, "z": 3, "color": "#ff0000", "size": 0.5 }, ... ],
      "lines": [ { "start": [0,0,0], "end": [1,1,1], "color": "#00ff00" }, ... ],
      "spheres": [ { "x": 0, "y": 0, "z": 0, "r": 1, "color": "blue" } ]
    }
    """
    with open(filename, 'w') as f:
        json.dump(data, f, cls=UBPEncoder, indent=2)
    print(f"3D Scene saved to {filename}. Visualizer will update.")


class UBPAnalytics:
    @staticmethod
    def records_to_dataframe(records: List[CanonicalRecord]):
        """Convert a list of CanonicalRecords to a Pandas DataFrame."""
        if pd is None: raise ImportError("Pandas not available")
        
        data = []
        for r in records:
            row = r.to_dict()
            # Flatten features
            features = row.pop('features')
            for k, v in features.items():
                # Convert fraction strings back to float for analysis (safe for stats, not for core logic)
                if isinstance(v, str) and '/' in v:
                    try:
                        n, d = map(int, v.split('/'))
                        row[f"feat_{k}"] = n/d
                    except:
                        row[f"feat_{k}"] = v
                else:
                    row[f"feat_{k}"] = v
            data.append(row)
        return pd.DataFrame(data)

    @staticmethod
    def leech_points_to_dataframe(points: List[LeechPointScaled]):
        """Convert list of LeechPoints to DataFrame with norms and coords."""
        if pd is None: raise ImportError("Pandas not available")
        
        data = []
        for p in points:
            row = {f"c{i}": p.coords[i] for i in range(24)}
            row["norm_sq_actual"] = float(p.norm_sq_actual)
            row["sum"] = p.coord_sum
            data.append(row)
        return pd.DataFrame(data)
`;

export const UBP_PHENOMENOLOGY_DEF_CONTENT = `from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple, Any
from fractions import Fraction

"""
================================================================================
1. PHENOMENON DEFINITION CONTRACT
Universal Binary Principle
Version: 3.9.0 Research Edition
Author: Euan R A Craig, New Zealand
Date: 18 December 2025
https://github.com/DigitalEuan/UBP_Repo
================================================================================
"""
@dataclass(frozen=True)
class PhenomenonDefinition:
    """
    Formal definition of a phenomenon for UBP studies.

    This object is DOMAIN-AGNOSTIC.
    Blood types, elements, cells, molecules, etc. are instances of this contract.
    """

    # ---- Identity ----
    name: str
    domain: str
    version: int

    # ---- Ontological structure ----
    bit_mapping: Dict[str, Tuple[int, int]]
    """
    Maps semantic attributes to OffBit24 ranges.

    Example:
        {
            "reality": (0, 5),
            "information": (6, 11),
            "activation": (12, 17),
            "unactivated": (18, 23)
        }
    """

    # ---- Canonicalization ----
    token_builder: Callable[[Dict[str, Any]], List[str]]
    feature_builder: Callable[[Dict[str, Any]], Dict[str, int | Fraction]]

    # ---- Spatial embedding ----
    coord_mapper: Callable[[Dict[str, Any]], Tuple[int, int, int, int, int, int]]

    # ---- Dynamics ----
    tgic_policy: Any
    toggle_rules: List[Any]

    # ---- Validation ----
    invariants: List[Callable[[Dict[str, Any]], bool]]

# Clear Definition of the Observable

def element_tokens(data):
    return [
        f"Z_{data['Z']}",
        f"group_{data['group']}",
        f"period_{data['period']}",
        f"block_{data['block']}"
    ]

def element_features(data):
    return {
        "atomic_number": data["Z"],
        "mass_scaled": Fraction(data["mass"], 5),
        "group": data["group"],
        "period": data["period"],
    }

# Spatial / Temporal Context (6D Bitfield)

def element_coord_mapper(data):
    """
    (x, y, z, t, type_id, state_id)
    """
    return (
        data["group"],          # x
        data["period"],         # y
        data["block_id"],       # z (s=0, p=1, d=2, f=3)
        0,                      # t (static table)
        data["Z"] // 10,        # coarse type band
        data["Z"] % 10,         # fine state
    )
`;

export const UBP_PHENOMENOLOGY_RUNNER_CONTENT = `from pathlib import Path, PurePosixPath

# Define the content for ubp_phenomenology_runner.py
runner_code = r'''#!/usr/bin/env python3
"""
================================================================================
ubp_phenomenology_runner.py — UBP Phenomenological Simulation Runner
================================================================================

Universal Binary Principle
Version: 3.9.0 Research Edition
Author: Euan R A Craig, New Zealand
Date: 18 December 2025
https://github.com/DigitalEuan/UBP_Repo

Purpose
-------
This module acts as the execution engine for UBP phenomenological studies.
It takes a PhenomenonDefinition and orchestrates the creation of digital twins
within a 6D Bitfield, applies dynamic rules, and extracts observable records.

It integrates with ubp_core for Information-First analysis.

Design principles
-----------------
- **Generic:** Operates on any PhenomenonDefinition.
- **Exact:** All internal calculations are int/Fraction only.
- **Deterministic:** Reproducible simulations.
- **Auditable:** Detailed audit logs of all state changes.

================================================================================
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from fractions import Fraction
from typing import (
    Any,
    Callable,
    Dict,
    Iterable,
    List,
    Mapping,
    MutableMapping,
    Optional,
    Protocol,
    Sequence,
    Tuple,
    Union,
)
import hashlib
import time

# Import PhenomenonDefinition from the new definition file
from ubp_phenomenology_def import PhenomenonDefinition

Exact = Union[int, Fraction]


# =============================================================================
# SECTION 1: Core exact utilities (no floats)
# =============================================================================

def _require_int(x, name: str) -> int:
    if not isinstance(x, int):
        raise TypeError(f"{name} must be int, got {type(x)}")
    return x

def _require_fraction_or_int(x, name: str) -> Union[int, Fraction]:
    if isinstance(x, (int, Fraction)):
        return x
    raise TypeError(f"{name} must be int or Fraction, got {type(x)}")

def popcount24(x: int) -> int:
    """Exact popcount for 24-bit integer."""
    _require_int(x, "x")
    x &= (1 << 24) - 1
    return x.bit_count()

def parity24(x: int) -> int:
    """Return parity (0 even, 1 odd) of a 24-bit integer."""
    return popcount24(x) & 1

def bits24_from_int(x: int) -> List[int]:
    """Return list of 24 bits MSB->LSB (audit/debug only)."""
    _require_int(x, "x")
    x &= (1 << 24) - 1
    return [(x >> (23 - i)) & 1 for i in range(24)]

def int_from_bits24(bits: Sequence[int]) -> int:
    if len(bits) != 24:
        raise ValueError("bits must be length 24")
    w = 0
    for i, b in enumerate(bits):
        if b not in (0, 1):
            raise ValueError("bits must be binary")
        w |= (int(b) & 1) << i # LSB first
    return w

def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def _stable_int_from_str(s: str, mod: int) -> int:
    h = hashlib.sha256(s.encode("utf-8")).digest()
    x = int.from_bytes(h[:8], "big")
    return x % mod


# =============================================================================
# SECTION 2: OffBit24 — layered 24-bit ontology
# =============================================================================

class OffBitLayer(Enum):
    REALITY = "reality"
    INFORMATION = "information"
    ACTIVATION = "activation"
    UNACTIVATED = "unactivated"

# _LAYER_RANGES will be dynamically set by PhenomenonDefinition's bit_mapping

def _layer_mask(start: int, width: int) -> int:
    """Inclusive bit range mask for 0 <= start, width > 0, start+width <= 24."""
    return ((1 << width) - 1) << start

@dataclass(frozen=True)
class OffBit24:
    """
    A 24-bit layered state stored as a single int.

    This is the atomic phenomenological unit: exact, compact, and auditable.
    """
    word: int  # must be 24-bit
    layer_map: Dict[OffBitLayer, Tuple[int, int]] = field(compare=False) # (start_bit, width)

    def __post_init__(self):
        v = _require_int(self.word, "word")
        if v < 0 or v >= (1 << 24):
            raise ValueError("OffBit24.word must be in [0, 2^24)")
        object.__setattr__(self, "word", v)

        # Validate layer_map structure
        if not isinstance(self.layer_map, dict):
            raise TypeError("layer_map must be a dictionary")
        for layer_enum, (start, width) in self.layer_map.items():
            if not isinstance(layer_enum, OffBitLayer):
                raise TypeError(f"Layer key {layer_enum} must be an OffBitLayer enum")
            if not (isinstance(start, int) and isinstance(width, int) and width > 0 and 0 <= start and (start + width) <= 24):
                raise ValueError(f"Invalid layer range for {layer_enum}: (start={start}, width={width}). Must be 0 <= start, width > 0, start+width <= 24.")

        # Basic validation: check for overlaps
        covered_mask = 0
        for layer_enum, (start, width) in self.layer_map.items():
            m = _layer_mask(start, width)
            if covered_mask & m:
                raise ValueError(f"Layer '{layer_enum.value}' overlaps another layer.")
            covered_mask |= m

    # ---- bit access ----
    def get_bit(self, i: int) -> int:
        _require_int(i, "i")
        if i < 0 or i >= 24:
            raise ValueError("bit index must be in [0, 23]")
        return (self.word >> i) & 1

    def set_bit(self, i: int, b: int) -> OffBit24:
        _require_int(i, "i")
        if i < 0 or i >= 24:
            raise ValueError("bit index must be in [0, 23]")
        if b not in (0, 1):
            raise ValueError("bit value must be 0 or 1")
        if b == self.get_bit(i):
            return self
        return OffBit24(self.word ^ (1 << i), layer_map=self.layer_map)

    def toggle_bit(self, i: int) -> OffBit24:
        return self.set_bit(i, 1 - self.get_bit(i))

    # ---- layer access ----
    def get_layer_int(self, layer: OffBitLayer) -> int:
        if layer not in self.layer_map:
            raise KeyError(f"Unknown layer: {layer}")
        start, width = self.layer_map[layer]
        return (self.word & _layer_mask(start, width)) >> start

    def set_layer_int(self, layer: OffBitLayer, value: int) -> "OffBit24":
        if layer not in self.layer_map:
            raise KeyError(f"Unknown layer: {layer}")
        start, width = self.layer_map[layer]
        _require_int(value, "value")
        if value < 0 or value >= (1 << width):
            raise ValueError(f"Value out of range for {layer}: needs {width} bits")
        cleared = self.word & ~_layer_mask(start, width)
        new_word = cleared | (value << start)
        return OffBit24(new_word, layer_map=self.layer_map)

    def layer_hamming_weight(self, layer: OffBitLayer) -> int:
        return self.get_layer_int(layer).bit_count()

    def hamming_weight(self) -> int:
        return self.word.bit_count()

    def to_bits(self) -> List[int]:
        return [(self.word >> i) & 1 for i in range(24)]

    @staticmethod
    def from_bits(bits24: Sequence[int], layer_map: Dict[OffBitLayer, Tuple[int, int]]) -> "OffBit24":
        if len(bits24) != 24:
            raise ValueError("bits24 must have length 24")
        w = 0
        for i, b in enumerate(bits24):
            if b not in (0, 1):
                raise ValueError("bits24 must be binary")
            w |= (int(b) & 1) << i
        return OffBit24(w, layer_map=layer_map)

    def __repr__(self) -> str:
        return f"OffBit24(word=0x{self.word:06x}, wt={self.hamming_weight()})"


# =============================================================================
# SECTION 3: Bitfield6D — sparse computational space
# =============================================================================

Coord6D = Tuple[int, int, int, int, int, int]


@dataclass
class Bitfield6D:
    """
    Sparse 6D Bitfield for UBP phenomenology.

    Storage is dict[Coord6D] -> OffBit24 for sparsity and exactness.
    """
    dims: Coord6D = (170, 170, 170, 5, 2, 2) # Default operational projection space
    cells: MutableMapping[Coord6D, OffBit24] = field(default_factory=dict)

    def _check_coord(self, c: Coord6D) -> None:
        if len(c) != 6:
            raise ValueError("Coord must be 6D")
        for idx, (v, lim) in enumerate(zip(c, self.dims)):
            if v < 0 or v >= lim:
                raise ValueError(f"Coord out of bounds at dim {idx}: {v} not in [0,{lim})")

    def get(self, c: Coord6D, default: Optional[OffBit24] = None) -> Optional[OffBit24]:
        self._check_coord(c)
        return self.cells.get(c, default)

    def set(self, c: Coord6D, offbit: OffBit24) -> None:
        self._check_coord(c)
        self.cells[c] = offbit

    def delete(self, c: Coord6D) -> None:
        self._check_coord(c)
        self.cells.pop(c, None)

    def neighbors_manhattan(self, c: Coord6D) -> List[Coord6D]:
        """
        6D Manhattan neighbors (±1 along each axis), clipped to bounds.
        Deterministic order.
        """
        self._check_coord(c)
        out: List[Coord6D] = []
        for axis in range(6):
            for delta in (-1, 1):
                cc = list(c)
                cc[axis] += delta
                if 0 <= cc[axis] < self.dims[axis]:
                    out.append(tuple(cc))  # type: ignore[arg-type]
        return out


# =============================================================================
# SECTION 4: TGIC Gate (policy-based, exact, auditable)
# =============================================================================

@dataclass(frozen=True)
class TGICDecision:
    allow: bool
    reason: str
    details: Dict[str, Any] = field(default_factory=dict)


class TGICPolicy(Protocol):
    """
    TGIC policy interface.
    A policy decides whether a mutation (toggle/apply op) is allowed.
    """
    def decide(
        self,
        field: Bitfield6D,
        target: Coord6D,
        before: OffBit24,
        after: OffBit24,
        context: Mapping[str, Any],
    ) -> TGICDecision: ...


@dataclass
class ConservativeTGIC:
    """
    Conservative deterministic TGIC-like gate.

    This is intentionally strict and *non-physical*: it exists to prevent
    uncontrolled drift while you refine a true TGIC geometry rule-set.

    Rules (all exact):
      1) Activation layer (bits 16–17) may only change if Information layer HW
         is non-zero (avoids activation without meaning).
      2) Unactivated layer (18–23) may only be toggled if Reality layer HW <= 4.
      3) Local coherence: average neighbor Reality HW must not increase by >2
         (stability gate).

    All thresholds are integers; no floats.
    """
    def decide(
        self,
        field: Bitfield6D,
        target: Coord6D,
        before: OffBit24,
        after: OffBit24,
        context: Mapping[str, Any],
    ) -> TGICDecision:
        b_info = before.layer_hamming_weight(OffBitLayer.INFORMATION)
        a_info = after.layer_hamming_weight(OffBitLayer.INFORMATION)

        b_act = before.get_layer_int(OffBitLayer.ACTIVATION)
        a_act = after.get_layer_int(OffBitLayer.ACTIVATION)

        b_real = before.layer_hamming_weight(OffBitLayer.REALITY)
        a_real = after.layer_hamming_weight(OffBitLayer.REALITY)

        # Rule 1
        if b_act != a_act and a_info == 0:
            return TGICDecision(
                allow=False,
                reason="TGIC: activation change requires nonzero information layer",
                details={"before_act": b_act, "after_act": a_act, "after_info_hw": a_info},
            )

        # Rule 2
        b_unact = before.get_layer_int(OffBitLayer.UNACTIVATED)
        a_unact = after.get_layer_int(OffBitLayer.UNACTIVATED)
        if b_unact != a_unact and a_real > 4:
            return TGICDecision(
                allow=False,
                reason="TGIC: unactivated toggles require reality HW<=4",
                details={"after_real_hw": a_real},
            )

        # Rule 3 (local stability)
        neigh = field.neighbors_manhattan(target)
        # Deterministic: treat missing neighbors as zero word.
        def _real_hw(c: Coord6D) -> int:
            ob = field.get(c, OffBit24(0, layer_map=before.layer_map))
            assert ob is not None
            return ob.layer_hamming_weight(OffBitLayer.REALITY)

        neigh_hw_sum = sum(_real_hw(nc) for nc in neigh)
        neigh_count = len(neigh) if neigh else 1
        neigh_avg = Fraction(neigh_hw_sum, neigh_count)  # exact
        # allow increase by at most 2
        if a_real - b_real > 2 and neigh_avg > 6:
            return TGICDecision(
                allow=False,
                reason="TGIC: local coherence gate (neighbor reality density high)",
                details={
                    "before_real_hw": b_real,
                    "after_real_hw": a_real,
                    "neighbor_avg_real_hw": neigh_avg,
                },
            )

        return TGICDecision(allow=True, reason="TGIC: allow", details={})


# =============================================================================
# SECTION 5: Audit log + Toggle operations (exact)
# =============================================================================

@dataclass(frozen=True)
class AuditEvent:
    t_ns: int
    op: str
    target: Coord6D
    before_word: int
    after_word: int
    allowed: bool
    tgic_reason: str
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AuditLog:
    events: List[AuditEvent] = field(default_factory=list)

    def add(self, e: AuditEvent) -> None:
        self.events.append(e)


@dataclass
class ToggleOps:
    """
    Exact toggle operations on OffBit24 in a Bitfield6D, guarded by TGICPolicy.
    """
    field: Bitfield6D
    tgic: TGICPolicy = field(default_factory=ConservativeTGIC)
    audit: Optional[AuditLog] = None
    layer_map: Dict[OffBitLayer, Tuple[int, int]] = field(compare=False) # Required for default OffBit24

    def _emit(self, op: str, target: Coord6D, before: OffBit24, after: OffBit24,
              decision: TGICDecision, meta: Dict[str, Any]) -> None:
        if self.audit is None:
            return
        self.audit.add(
            AuditEvent(
                t_ns=time.time_ns(),
                op=op,
                target=target,
                before_word=before.word,
                after_word=after.word,
                allowed=decision.allow,
                tgic_reason=decision.reason,
                meta=dict(meta, **decision.details),
            )
        )

    def apply(self, target: Coord6D, f: Callable[[OffBit24], OffBit24],
              op_name: str, context: Optional[Dict[str, Any]] = None) -> TGICDecision:
        context = context or {}
        # Ensure default OffBit24 has the correct layer_map
        before = self.field.get(target, OffBit24(0, layer_map=self.layer_map)) or OffBit24(0, layer_map=self.layer_map)
        after = f(before)

        decision = self.tgic.decide(self.field, target, before, after, context)
        self._emit(op_name, target, before, after, decision, meta=context)

        if decision.allow:
            self.field.set(target, after)
        return decision

    # --- convenience ops ---

    def toggle_bit(self, target: Coord6D, bit_index: int,
                   context: Optional[Dict[str, Any]] = None) -> TGICDecision:
        return self.apply(
            target=target,
            f=lambda ob: ob.toggle_bit(bit_index),
            op_name="toggle_bit",
            context=dict(context or {}, bit_index=bit_index),
        )

    def xor_layer(self, target: Coord6D, layer: OffBitLayer, value: int,
                  context: Optional[Dict[str, Any]] = None) -> TGICDecision:
        start, width = self.layer_map[layer] # Use instance's layer_map
        if value < 0 or value >= (1 << width):
            raise ValueError("xor value out of range for layer")
        def _op(ob: OffBit24) -> OffBit24:
            cur = ob.get_layer_int(layer)
            return ob.set_layer_int(layer, cur ^ value)
        return self.apply(target, _op, "xor_layer", dict(context or {}, layer=layer.value, value=value))

    def not_layer(self, target: Coord6D, layer: OffBitLayer,
                  context: Optional[Dict[str, Any]] = None) -> TGICDecision:
        start, width = self.layer_map[layer] # Use instance's layer_map
        mask = (1 << width) - 1
        def _op(ob: OffBit24) -> OffBit24:
            cur = ob.get_layer_int(layer)
            return ob.set_layer_int(layer, cur ^ mask)
        return self.apply(target, _op, "not_layer", dict(context or {}, layer=layer.value))


# =============================================================================
# SECTION 6: Deterministic "resonance toggle" (no floats) — tokenized frequency model
# =============================================================================

def resonance_toggle_word(word: int, freq_token: str, time_token: str, salt: str = "") -> int:
    """
    Deterministic toggle transform on a 24-bit word.

    Inputs are *tokens* (strings), not floats. This prevents "float infestation"
    while allowing studies to label resonance contexts (e.g. "60Hz", "1e-9", "pi").

    Construction:
      digest = SHA256(f"{word}:{freq_token}:{time_token}:{salt}")
      take first 3 bytes -> 24-bit mask
      toggled = word XOR mask
    """
    payload = f"{word}:{freq_token}:{time_token}:{salt}".encode("utf-8")
    h = hashlib.sha256(payload).digest()
    mask24 = (h[0] << 16) | (h[1] << 8) | h[2]
    return (word ^ mask24) & ((1 << 24) - 1)


# =============================================================================
# SECTION 7: Adapter contract (Study → canonical → Bitfield seed)
# =============================================================================

class PhenomenologyAdapter(Protocol):
    """
    Study adapter for phenomenology input.

    A study MUST:
      - canonicalize(obs) -> Canonical-like record (domain/id/tokens/features/version)
      - map_to_offbit(record) -> OffBit24
      - map_to_coord(record) -> Coord6D (deterministic placement)
    """
    def canonicalize(self, obs: Any) -> Any: ...
    def map_to_offbit(self, record: Any) -> OffBit24: ...
    def map_to_coord(self, record: Any) -> Coord6D: ...


@dataclass
class GenericPhenomenologyAdapter:
    """
    A generic adapter that uses a PhenomenonDefinition to map observables.
    """
    phenomenon_def: PhenomenonDefinition

    def canonicalize(self, obs: Any) -> Dict[str, Any]:
        # Validate against invariants
        for invariant_check in self.phenomenon_def.invariants:
            if not invariant_check(obs):
                raise ValueError(f"Observable {obs} failed invariant check for {self.phenomenon_def.name}")

        # Build tokens and features using the definition's callables
        tokens = self.phenomenon_def.token_builder(obs)
        features = self.phenomenon_def.feature_builder(obs)

        # Ensure features are exact
        for k, v in features.items():
            _require_fraction_or_int(v, f"feature[{k}]")

        # Construct a canonical-like dictionary
        return {
            "domain": self.phenomenon_def.domain,
            "canonical_id": obs.get("name", str(obs)), # Use 'name' if available, else string representation
            "tokens": sorted(tokens),
            "features": features,
            "version": self.phenomenon_def.version,
        }

    def _payload_hash(self, record: Mapping[str, Any]) -> str:
        payload = (
            f"{record['domain']}:{record['canonical_id']}:v{record['version']}:"
            + ":".join(sorted(record["tokens"])) # FIX 1 APPLIED HERE
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def map_to_offbit(self, record: Mapping[str, Any]) -> OffBit24:
        """
        Map to OffBit24 using the phenomenon's bit_mapping.
        This is a generic mapping that takes the payload hash and distributes
        bits according to the defined layer ranges (start, width).
        """
        h = bytes.fromhex(self._payload_hash(record))
        word = 0

        # Prepare layer_map for OffBit24 (which expects (start, width))
        layer_map_for_offbit = {}
        for layer_name, (start_bit, width) in self.phenomenon_def.bit_mapping.items():
            layer_map_for_offbit[OffBitLayer[layer_name.upper()]] = (start_bit, width)

        # Distribute hash bits across layers - FIX 2 APPLIED HERE
        bit_cursor = 0
        for layer_enum in (
            OffBitLayer.REALITY,
            OffBitLayer.INFORMATION,
            OffBitLayer.ACTIVATION,
            OffBitLayer.UNACTIVATED,
        ):
            if layer_enum not in layer_map_for_offbit:
                continue

            start, width = layer_map_for_offbit[layer_enum]

            # Take bits from the hash, cycling through bytes if needed
            layer_value = 0
            for i in range(width):
                byte_idx = (bit_cursor // 8) % len(h)
                bit_in_byte_idx = bit_cursor % 8
                bit = (h[byte_idx] >> bit_in_byte_idx) & 1
                layer_value |= (bit << i) # Build layer value LSB first
                bit_cursor += 1
            word |= (layer_value << start)

        return OffBit24(word, layer_map=layer_map_for_offbit)


    def map_to_coord(self, record: Mapping[str, Any]) -> Coord6D:
        """
        Deterministic placement into the 6D field using the phenomenon's coord_mapper.
        """
        # The record contains the canonicalized data, which might be needed by coord_mapper
        # For now, we pass the full record to the coord_mapper.
        return self.phenomenon_def.coord_mapper(record)


# =============================================================================
# SECTION 8: Phenomenology Engine
# =============================================================================

@dataclass
class PhenomenologyEngine:
    """
    Glue object: adapter → Bitfield seed → guarded toggles → readout.

    This is deliberately small so studies can build above it.
    """
    field: Bitfield6D = field(default_factory=Bitfield6D)
    tgic: TGICPolicy = field(default_factory=ConservativeTGIC)
    audit: AuditLog = field(default_factory=AuditLog)
    phenomenon_def: PhenomenonDefinition # FIX 3: Added phenomenon_def

    # FIX 3: layer_map derived automatically in post_init
    layer_map: Dict[OffBitLayer, Tuple[int, int]] = field(init=False, compare=False)

    def __post_init__(self): # FIX 3: Derive layer_map here
        self.layer_map = {
            OffBitLayer[k.upper()]: v
            for k, v in self.phenomenon_def.bit_mapping.items()
        }

    def make_ops(self) -> ToggleOps:
        return ToggleOps(field=self.field, tgic=self.tgic, audit=self.audit, layer_map=self.layer_map)

    def seed_from_observable(self, adapter: PhenomenologyAdapter, obs: Any) -> Dict[str, Any]:
        record = adapter.canonicalize(obs)
        coord = adapter.map_to_coord(record)
        offbit = adapter.map_to_offbit(record)
        self.field.set(coord, offbit)
        self.audit.add(
            AuditEvent(
                t_ns=time.time_ns(),
                op="seed",
                target=coord,
                before_word=0,
                after_word=offbit.word,
                allowed=True,
                tgic_reason="seed",
                meta={"domain": record.get("domain"), "canonical_id": record.get("canonical_id"), "version": record.get("version")},
            )
        )
        return {"record": record, "coord": coord, "offbit": offbit}

    def resonance_step(self, coord: Coord6D, freq_token: str, time_token: str, salt: str = "") -> TGICDecision:
        ops = self.make_ops()
        def _op(ob: OffBit24) -> OffBit24:
            new_word = resonance_toggle_word(ob.word, freq_token=freq_token, time_token=time_token, salt=salt)
            return OffBit24(new_word, layer_map=self.layer_map) # Ensure new OffBit24 has layer_map
        return ops.apply(coord, _op, "resonance_toggle", {"freq_token": freq_token, "time_token": time_token, "salt": salt})

    def snapshot(self, coord: Coord6D) -> Dict[str, Any]:
        ob = self.field.get(coord, OffBit24(0, layer_map=self.layer_map)) or OffBit24(0, layer_map=self.layer_map)
        return {
            "coord": coord,
            "word_hex": hex(ob.word),
            "hw_total": ob.hamming_weight(),
            "hw_reality": ob.layer_hamming_weight(OffBitLayer.REALITY),
            "hw_info": ob.layer_hamming_weight(OffBitLayer.INFORMATION),
            "activation": ob.get_layer_int(OffBitLayer.ACTIVATION),
            "unactivated": ob.get_layer_int(OffBitLayer.UNACTIVATED),
        }

    def apply_toggle_rule(self, rule: "ToggleRule", steps: int = 1) -> List[Dict[str, Any]]:
        """
        Applies a given toggle rule for a number of steps and returns audit events.
        """
        audit_events_this_run = []
        ops = self.make_ops()

        for step_num in range(steps):
            flips = rule.propose(self.field, self.layer_map) # Pass layer_map to rule
            flips_sorted = sorted(flips, key=lambda x: (x[0], x[1]))

            for coord, bit_index in flips_sorted:
                before_offbit = self.field.get(coord, OffBit24(0, layer_map=self.layer_map))
                after_offbit = before_offbit.toggle_bit(bit_index)
                decision = self.tgic.decide(self.field, coord, before_offbit, after_offbit, {"rule": rule.name()})

                ops._emit(
                    op=f"rule_toggle_{rule.name()}",
                    target=coord,
                    before=before_offbit,
                    after=after_offbit,
                    decision=decision,
                    meta={"bit_index": bit_index, "step": step_num + 1}
                )

                if decision.allow:
                    self.field.set(coord, after_offbit)
                    audit_events_this_run.append(ops.audit.events[-1]) # Add the last emitted event

        return [e.meta for e in audit_events_this_run] # Return metadata of applied events


# =============================================================================
# SECTION 9: Toggle rules (exact dynamics)
# =============================================================================

class ToggleRule(Protocol):
    """
    Base class for deterministic toggle-rule dynamics.
    """
    def name(self) -> str: ...

    def propose(self, field: Bitfield6D, layer_map: Dict[OffBitLayer, Tuple[int, int]]) -> List[Tuple[Coord6D, int]]:
        """
        Return a list of (coord, bit_index) flips to apply.
        Must be deterministic. Must not mutate field.
        """
        raise NotImplementedError

@dataclass
class NeighborhoodParityRule:
    """
    Deterministic local rule:
      - For each cell, compute XOR parity of a chosen layer across its neighborhood.
      - If parity != desired, flip a specific target bit in that layer.

    This is a “field-stabilization” rule: exact, discrete, and interpretable.

    Parameters:
      - layer: which layer is monitored (e.g., OffBitLayer.ACTIVATION)
      - target_bit_in_layer: which bit (0..width-1 within the layer) is toggled
      - desired_parity: 0 or 1
      - neighborhood_offsets: list of coordinate offsets (default: von Neumann in 2D)
    """
    layer: OffBitLayer
    target_bit_in_layer: int
    desired_parity: int
    neighborhood_offsets: Optional[List[Coord6D]] = None

    def __post_init__(self):
        _require_int(self.target_bit_in_layer, "target_bit_in_layer")
        if self.desired_parity not in (0, 1):
            raise ValueError("desired_parity must be 0 or 1")
        if self.neighborhood_offsets is None:
            # Default to a simple 2D von Neumann neighborhood for demonstration
            # In a 6D context, this would be more complex, but for a generic rule,
            # we need to consider the dimensionality of the actual coords.
            # For now, let's assume a generic +/-1 along each axis for 6D.
            self.neighborhood_offsets = []
            for i in range(6):
                offset_plus = [0]*6
                offset_plus[i] = 1
                self.neighborhood_offsets.append(tuple(offset_plus))
                offset_minus = [0]*6
                offset_minus[i] = -1
                self.neighborhood_offsets.append(tuple(offset_minus))
            self.neighborhood_offsets.append(tuple([0]*6)) # Include self

    def name(self) -> str:
        return f"NeighborhoodParityRule_{self.layer.value}_{self.target_bit_in_layer}"

    def propose(self, field: Bitfield6D, layer_map: Dict[OffBitLayer, Tuple[int, int]]) -> List[Tuple[Coord6D, int]]:
        flips: List[Tuple[Coord6D, int]] = []
        coords = sorted(field.cells.keys()) # Ensure deterministic iteration

        # Pre-check target_bit_in_layer validity against the actual layer width
        layer_start, layer_width = layer_map[self.layer]
        if not (0 <= self.target_bit_in_layer < layer_width):
            raise ValueError(f"target_bit_in_layer {self.target_bit_in_layer} is out of range for layer {self.layer.value} (width {layer_width})")


        for c in coords:
            off = field.get(c)
            if off is None:
                continue

            # Compute neighborhood parity on the layer (6-bit integer)
            parity = 0
            for d_offset in self.neighborhood_offsets:
                # Calculate neighbor coordinate
                neighbor_coord = tuple(c_i + d_i for c_i, d_i in zip(c, d_offset))
                
                # Check if neighbor_coord is within field dimensions
                is_valid_neighbor = True
                for idx, (v, lim) in enumerate(zip(neighbor_coord, field.dims)):
                    if not (0 <= v < lim):
                        is_valid_neighbor = False
                        break
                
                if not is_valid_neighbor:
                    continue # Skip out-of-bounds neighbors

                onn = field.get(neighbor_coord)
                if onn is None:
                    # Treat missing neighbors as having a zero word for parity calculation
                    # This ensures determinism and avoids errors for sparse fields.
                    neighbor_layer_int = 0
                else:
                    neighbor_layer_int = onn.get_layer_int(self.layer)

                parity ^= (neighbor_layer_int.bit_count() & 1)

            if parity != self.desired_parity:
                layer_start_bit, _ = layer_map[self.layer]
                flip_bit_index = layer_start_bit + self.target_bit_in_layer
                flips.append((c, flip_bit_index))

        return flips

@dataclass
class CrossLayerCouplingRule:
    """
    Cross-layer coupling (exact):
      - If information-layer weight is odd, toggle a chosen activation-layer bit.
      - If activation-layer weight is odd, toggle a chosen reality-layer bit.
    This creates a deterministic, layered feedback without floats.
    """
    info_to_act_bit_in_layer: int = 0
    act_to_real_bit_in_layer: int = 0

    def __post_init__(self):
        _require_int(self.info_to_act_bit_in_layer, "info_to_act_bit_in_layer")
        _require_int(self.act_to_real_bit_in_layer, "act_to_real_bit_in_layer")
        # We cannot check bit_in_layer validity here without the layer_map,
        # so this check will be done in propose().

    def name(self) -> str:
        return f"CrossLayerCouplingRule_I{self.info_to_act_bit_in_layer}_R{self.act_to_real_bit_in_layer}"

    def propose(self, field: Bitfield6D, layer_map: Dict[OffBitLayer, Tuple[int, int]]) -> List[Tuple[Coord6D, int]]:
        flips: List[Tuple[Coord6D, int]] = []
        coords = sorted(field.cells.keys()) # Ensure deterministic iteration

        # Pre-check bit_in_layer validity against layer widths
        info_layer_start, info_layer_width = layer_map[OffBitLayer.INFORMATION]
        if not (0 <= self.info_to_act_bit_in_layer < info_layer_width):
            raise ValueError(f"info_to_act_bit_in_layer {self.info_to_act_bit_in_layer} out of range for INFORMATION layer (width {info_layer_width})")

        act_layer_start, act_layer_width = layer_map[OffBitLayer.ACTIVATION]
        if not (0 <= self.info_to_act_bit_in_layer < act_layer_width): # This bit targets activation layer
            raise ValueError(f"info_to_act_bit_in_layer {self.info_to_act_bit_in_layer} out of range for ACTIVATION layer (width {act_layer_width})")

        real_layer_start, real_layer_width = layer_map[OffBitLayer.REALITY]
        if not (0 <= self.act_to_real_bit_in_layer < real_layer_width):
            raise ValueError(f"act_to_real_bit_in_layer {self.act_to_real_bit_in_layer} out of range for REALITY layer (width {real_layer_width})")


        for c in coords:
            off = field.get(c)
            if off is None:
                continue

            info_wt = off.layer_hamming_weight(OffBitLayer.INFORMATION)
            act_wt = off.layer_hamming_weight(OffBitLayer.ACTIVATION)

            if info_wt & 1: # If information layer weight is odd
                act_layer_start_bit, _ = layer_map[OffBitLayer.ACTIVATION]
                flips.append((c, act_layer_start_bit + self.info_to_act_bit_in_layer))
            if act_wt & 1: # If activation layer weight is odd
                real_layer_start_bit, _ = layer_map[OffBitLayer.REALITY]
                flips.append((c, real_layer_start_bit + self.act_to_real_bit_in_layer))
        return flips


# =============================================================================
# SECTION 10: Observable extraction (phenomenology → tokens/features)
# =============================================================================

@dataclass(frozen=True)
class PhenomenologyRecord:
    """
    A drift-resistant, exact output describing a Bitfield state.

    This is analogous to a CanonicalRecord, but stays on the phenomenology side.
    The bridge can later map this to your ubp_core CanonicalRecord contract.
    """
    domain: str
    semantic_id: str
    tokens: Tuple[str, ...]
    features: Tuple[Tuple[str, Union[int, Fraction]], ...]
    version: int

    @property
    def payload(self) -> str:
        toks = ":".join(self.tokens)
        feats = ":".join(f"{k}={v}" for k, v in self.features)
        return f"{self.domain}:{self.semantic_id}:v{self.version}:{toks}:{feats}"

    @property
    def payload_hash(self) -> str:
        return sha256_hex(self.payload)

class ObservableExtractor:
    """
    Deterministic, exact extraction of a Bitfield into tokens + features.

    Output rules:
      - tokens are sorted lexicographically
      - features are sorted by key
      - features values are int/Fraction only
    """

    def __init__(self, phenomenon_def: PhenomenonDefinition):
        self.phenomenon_def = phenomenon_def
        self.version = phenomenon_def.version
        # Prepare layer_map for OffBit24 (which expects (start, width))
        self.layer_map_for_offbit = {}
        for layer_name, (start_bit, width) in self.phenomenon_def.bit_mapping.items():
            self.layer_map_for_offbit[OffBitLayer[layer_name.upper()]] = (start_bit, width)


    def extract(self, field: Bitfield6D, domain: str, semantic_id: str) -> PhenomenologyRecord:
        # Features
        cells = field.cells.keys()
        num_cells = len(cells)
        
        # Calculate total weight sum and layer weights
        total_weight_sum = 0
        layer_weights: Dict[OffBitLayer, int] = {layer: 0 for layer in OffBitLayer}

        for coord in sorted(cells): # Deterministic iteration
            offbit = field.get(coord)
            if offbit:
                total_weight_sum += offbit.hamming_weight()
                for layer_enum in OffBitLayer:
                    layer_weights[layer_enum] += offbit.layer_hamming_weight(layer_enum)

        coords_sum = tuple(sum(c[i] for c in cells) for i in range(6)) if cells else (0,0,0,0,0,0)


        # Simple exact ratios (guard divide-by-zero)
        avg_w = Fraction(total_weight_sum, num_cells) if num_cells else Fraction(0, 1)
        
        activation_w = layer_weights[OffBitLayer.ACTIVATION]
        act_over_total = Fraction(activation_w, total_weight_sum) if total_weight_sum else Fraction(0, 1)

        # Deterministic tokens (examples; you can add more, but keep stable)
        tokens: List[str] = []
        tokens.append(f"cells_{num_cells}")
        tokens.append(f"parity_total_{(total_weight_sum & 1)}")
        tokens.append(f"layer_dom_{self._dominant_layer(layer_weights)}")

        # Coordinate summary tokens
        tokens.append("coord_sum_" + "_".join(str(x) for x in coords_sum))

        tokens_sorted = tuple(sorted(tokens))

        features_dict: Dict[str, Union[int, Fraction]] = {
            "cells": num_cells,
            "weight_sum": total_weight_sum,
            "reality_w": layer_weights[OffBitLayer.REALITY],
            "information_w": layer_weights[OffBitLayer.INFORMATION],
            "activation_w": layer_weights[OffBitLayer.ACTIVATION],
            "unactivated_w": layer_weights[OffBitLayer.UNACTIVATED],
            "avg_weight_per_cell": avg_w,
            "activation_over_total_weight": act_over_total,
            "digest_tag": int(sha256_hex(self._field_digest(field))[:8], 16),
        }

        features_sorted = tuple(sorted(features_dict.items(), key=lambda kv: kv[0]))

        # Validate exactness
        for k, v in features_sorted:
            _require_fraction_or_int(v, f"feature[{k}]")

        return PhenomenologyRecord(
            domain=domain,
            semantic_id=semantic_id,
            tokens=tokens_sorted,
            features=features_sorted,
            version=self.version,
        )

    @staticmethod
    def _dominant_layer(layer_weights: Dict[OffBitLayer, int]) -> str:
        items = [(layer.value, weight) for layer, weight in layer_weights.items()]
        # deterministic tie-breaker by layer name
        items.sort(key=lambda x: (-x[1], x[0]))
        return items[0][0]

    def _field_digest(self, field: Bitfield6D) -> str:
        """
        Deterministic SHA-256 of the whole field (coords + OffBit values).
        Useful for regression locking.
        """
        parts = []
        for c in sorted(field.cells.keys()):
            off = field.get(c)
            if off:
                parts.append(f"{c}:{off.word}")
        return sha256_hex("|".join(parts))

'''
out_path = Path("/mnt/data/ubp_phenomenology_runner.py")
out_path.parent.mkdir(parents=True, exist_ok=True)
out_path.write_text(runner_code, encoding="utf-8")
str(out_path)
`;

export const INITIAL_STUDY_SCRIPT = `"""
Study: v3.9 3D Visualization Demo
Description: Demonstrates saving 3D scene data and using the output directory.
"""
import ubp_core
from ubp_core import save_scene_3d
import random

def run_study():
    print("Generating 3D Visualization...")
    
    # 1. Create a simple 3D structure (e.g. random points in a sphere)
    points = []
    lines = []
    
    # Generate points
    for i in range(50):
        x = random.uniform(-10, 10)
        y = random.uniform(-10, 10)
        z = random.uniform(-10, 10)
        color = "#00ff00" if z > 0 else "#ff00ff"
        points.append({"x": x, "y": y, "z": z, "color": color, "size": 0.5})
        
        # Connect to origin
        lines.append({"start": [0,0,0], "end": [x,y,z], "color": "#333333"})

    scene_data = {
        "points": points,
        "lines": lines,
        "spheres": [{"x": 0, "y": 0, "z": 0, "r": 0.5, "color": "#ffffff"}]
    }

    # 2. Save using the core helper
    # This automatically triggers the 3D viewer in the UI
    save_scene_3d(scene_data)
    
    # 3. Write a text file to the output directory
    print("\\nWriting report to output/report.txt...")
    with open("output/report.txt", "w") as f:
        f.write(f"Generated {len(points)} points.\\n")
        f.write("Study completed successfully.")
        
    print("Done. Check 3D Visuals tab and Output folder.")

if __name__ == "__main__":
    run_study()
`;