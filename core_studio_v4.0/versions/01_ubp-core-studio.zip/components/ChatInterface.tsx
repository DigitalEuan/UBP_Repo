import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  onSendMessage: (msg: string) => void;
  isLoading: boolean;
  onExtractCode: (code: string) => void;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages, onSendMessage, isLoading, onExtractCode }) => {
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    onSendMessage(input);
    setInput('');
  };

  const renderMessageContent = (msg: ChatMessage) => {
    // Basic markdown-ish parsing for code blocks
    const parts = msg.content.split(/(```python[\s\S]*?```)/g);
    
    return parts.map((part, idx) => {
      if (part.startsWith('```python')) {
        const code = part.replace(/```python\n?/, '').replace(/```$/, '').trim();
        return (
          <div key={idx} className="my-2 rounded-md overflow-hidden border border-gray-700 bg-gray-900">
            <div className="flex justify-between items-center px-3 py-1 bg-gray-800 border-b border-gray-700">
              <span className="text-xs text-gray-400">Python Script</span>
              <button 
                onClick={() => onExtractCode(code)}
                className="text-xs bg-blue-600 hover:bg-blue-500 text-white px-2 py-0.5 rounded transition-colors"
              >
                Load as New Tab
              </button>
            </div>
            <pre className="p-3 overflow-x-auto text-xs text-gray-300 font-mono">
              <code>{code}</code>
            </pre>
          </div>
        );
      }
      return <span key={idx} className="whitespace-pre-wrap">{part}</span>;
    });
  };

  return (
    <div className="flex flex-col h-full bg-[#1a1a1a] border-r border-gray-800">
      <div className="p-4 border-b border-gray-800 bg-[#252525]">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>
          UBP Assistant <span className="text-xs bg-blue-900 text-blue-200 px-1 rounded ml-2">ONLINE</span>
        </h2>
        <p className="text-xs text-gray-400 mt-1">Connected to Google Search & Pyodide</p>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
            <div className={`max-w-[90%] rounded-lg p-3 text-sm shadow-md ${
              msg.role === 'user' 
                ? 'bg-purple-900/50 text-gray-100 border border-purple-700/50' 
                : 'bg-gray-800 text-gray-200 border border-gray-700'
            }`}>
               {renderMessageContent(msg)}
            </div>
            
            {/* Grounding / Sources Display */}
            {msg.groundingUrls && msg.groundingUrls.length > 0 && (
              <div className="mt-2 max-w-[90%] text-xs bg-[#111] p-2 rounded border border-gray-800">
                <p className="text-gray-500 font-bold mb-1 uppercase tracking-wider">Sources:</p>
                <div className="flex flex-wrap gap-2">
                  {msg.groundingUrls.map((source, i) => (
                    <a 
                      key={i} 
                      href={source.uri} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-400 hover:underline truncate max-w-xs block bg-gray-900 px-2 py-1 rounded"
                    >
                      {source.title || source.uri}
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="bg-gray-800 rounded-lg p-3 border border-gray-700">
                <div className="flex gap-1 items-center">
                  <span className="text-xs text-gray-400 mr-2">Thinking & Searching...</span>
                  <div className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce"></div>
                  <div className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce delay-75"></div>
                  <div className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce delay-150"></div>
                </div>
             </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="p-4 bg-[#252525] border-t border-gray-800">
        <div className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Search web for data, visualize results, or design study..."
            className="w-full bg-gray-900 border border-gray-700 rounded-md py-3 px-4 text-sm text-white focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 pr-10"
            disabled={isLoading}
          />
          <button 
            type="submit" 
            disabled={isLoading || !input.trim()}
            className="absolute right-2 top-2 text-gray-400 hover:text-white p-1"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
          </button>
        </div>
      </form>
    </div>
  );
};
