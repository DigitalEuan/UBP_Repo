import React, { useState, useEffect, useCallback, useRef } from 'react';
import { pyodideService } from './services/pyodideService';
import { GeminiService } from './services/geminiService';
import { 
    DEFAULT_UBP_CORE, 
    UBP_PHENOMENOLOGY_DEF_CONTENT, 
    UBP_PHENOMENOLOGY_RUNNER_CONTENT, 
    INITIAL_STUDY_SCRIPT 
} from './constants';
import { ChatMessage, FileTab, Scene3DData } from './types';
import { CodeEditor } from './components/CodeEditor';
import { ConsoleOutput } from './components/ConsoleOutput';
import { ChatInterface } from './components/ChatInterface';
import { ThreeViewer } from './components/ThreeViewer';

const App: React.FC = () => {
  const [apiKey, setApiKey] = useState(process.env.API_KEY || '');
  const [isPyodideReady, setIsPyodideReady] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);
  
  // File System State
  const [activeTabId, setActiveTabId] = useState<string>('study_1.py');
  const [files, setFiles] = useState<FileTab[]>([
    { name: 'ubp_core.py', content: DEFAULT_UBP_CORE, type: 'core' },
    { name: 'ubp_phenomenology_def.py', content: UBP_PHENOMENOLOGY_DEF_CONTENT, type: 'core' },
    { name: 'ubp_phenomenology_runner.py', content: UBP_PHENOMENOLOGY_RUNNER_CONTENT, type: 'core' },
    { name: 'study_1.py', content: INITIAL_STUDY_SCRIPT, type: 'script' }
  ]);
  const [fileList, setFileList] = useState<string[]>([]);
  
  // Output State
  const [consoleOutput, setConsoleOutput] = useState('');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [scene3dData, setScene3dData] = useState<Scene3DData | null>(null);
  const [activeVisualTab, setActiveVisualTab] = useState<'2D' | '3D'>('2D');
  
  // UI State
  const [editorHeightPercent, setEditorHeightPercent] = useState(60);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const isDraggingSplit = useRef(false);

  // Chat State
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      content: 'Welcome to UBP Core Studio v3.9. Features enabled: Google Search Grounding, File Uploads, Multi-Tab Scripting, 3D Visualization (Three.js), and Phenomenology modules.',
      timestamp: Date.now()
    }
  ]);
  const [isChatLoading, setIsChatLoading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const loadStudyRef = useRef<HTMLInputElement>(null);
  const rightPanelRef = useRef<HTMLDivElement>(null);

  // Initialize Pyodide
  const initKernel = async (isRestart: boolean = false) => {
    try {
      if (isRestart) {
        setIsPyodideReady(false);
        pyodideService.reset();
        setConsoleOutput(prev => prev + "\n[SYSTEM] Terminating existing kernel and restarting...\n");
      } else {
        setConsoleOutput("Initializing Pyodide Runtime & Loading Matplotlib...\n");
      }
      
      await pyodideService.initialize();
      setIsPyodideReady(true);
      setConsoleOutput(prev => prev + "Pyodide Ready.\nWriting default files...\n");
      
      // Write initial files
      for (const f of files) {
          await pyodideService.writeFile(f.name, f.content);
      }
      await refreshFileList();
      setConsoleOutput(prev => prev + "System ready.\n");
    } catch (err) {
      setConsoleOutput(prev => prev + `Error initializing runtime: ${err}\n`);
    }
  };

  useEffect(() => {
    initKernel();
  }, []);

  // Split Pane Resizing Logic
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
        if (!isDraggingSplit.current || !rightPanelRef.current) return;
        
        const panelRect = rightPanelRef.current.getBoundingClientRect();
        const relativeY = e.clientY - panelRect.top;
        const newPercent = (relativeY / panelRect.height) * 100;
        
        // Clamp between 20% and 80%
        if (newPercent > 20 && newPercent < 80) {
            setEditorHeightPercent(newPercent);
        }
    };

    const handleMouseUp = () => {
        isDraggingSplit.current = false;
        document.body.style.cursor = 'default';
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  const refreshFileList = async () => {
    if (isPyodideReady) {
      const list = await pyodideService.listFiles();
      setFileList(list);
    }
  };

  // Sync Current Tab Code to File System and State
  const handleCodeChange = async (newCode: string) => {
    setFiles(prev => prev.map(f => f.name === activeTabId ? { ...f, content: newCode } : f));
    // Also write to FS immediately for imports to work across files
    if (isPyodideReady) {
      await pyodideService.writeFile(activeTabId, newCode);
    }
  };

  const getActiveContent = () => {
    return files.find(f => f.name === activeTabId)?.content || '';
  };

  // Run Active Script
  const runStudy = async () => {
    if (!isPyodideReady) return;
    
    setIsExecuting(true);
    setConsoleOutput(prev => prev + `\n\n--- Executing ${activeTabId} ---\n`);
    setGeneratedImage(null); // Reset image
    setScene3dData(null); // Reset 3D

    try {
      // Ensure all tabs are synced to FS before running
      let syncedCount = 0;
      for (const f of files) {
          await pyodideService.writeFile(f.name, f.content);
          syncedCount++;
      }
      setConsoleOutput(prev => prev + `[SYSTEM] Synced ${syncedCount} files to virtual filesystem (cwd).\n`);

      const codeToRun = getActiveContent();
      const result = await pyodideService.runPython(codeToRun);
      
      if (result.stdout) setConsoleOutput(prev => prev + result.stdout);
      if (result.stderr) setConsoleOutput(prev => prev + `\n[STDERR]\n${result.stderr}`);
      if (result.error) setConsoleOutput(prev => prev + `\n[SYSTEM ERROR]\n${result.error}`);
      
      if (result.image) {
          setGeneratedImage(result.image);
          setActiveVisualTab('2D');
          setConsoleOutput(prev => prev + "\n[GRAPHIC GENERATED] See Visuals tab.");
      }

      if (result.scene3d) {
          setScene3dData(result.scene3d);
          setActiveVisualTab('3D');
          setConsoleOutput(prev => prev + "\n[3D SCENE GENERATED] See Visuals tab.");
      }
      
      setConsoleOutput(prev => prev + "\n--- Execution Finished ---");
    } catch (e: any) {
      setConsoleOutput(prev => prev + `\n[EXECUTION FAILED] ${e.message}\n`);
    } finally {
      setIsExecuting(false);
      await refreshFileList();
    }
  };

  const stopExecution = () => {
    // On the main thread, the only way to "stop" a synchronous stuck Pyodide run
    // is to terminate the instance and reload everything.
    initKernel(true);
  };

  const deleteTab = async (name: string) => {
    if (!confirm(`Are you sure you want to delete ${name}?`)) return;
    
    setFiles(prev => prev.filter(f => f.name !== name));
    if (activeTabId === name) {
        const remaining = files.filter(f => f.name !== name);
        if (remaining.length > 0) setActiveTabId(remaining[0].name);
    }
    
    if (isPyodideReady) {
        try {
            await pyodideService.deleteFile(name);
            await refreshFileList();
        } catch (e) { /* ignore */ }
    }
  };

  const deleteRuntimeFile = async (name: string) => {
    if (!confirm(`Delete ${name} from runtime?`)) return;
    if (isPyodideReady) {
        try {
            await pyodideService.deleteFile(name);
            await refreshFileList();
        } catch (e) {
            alert("Could not delete file: " + e);
        }
    }
  };

  // Chat Handler
  const handleSendMessage = async (text: string) => {
    if (!apiKey) {
      alert("Please enter a Google Gemini API Key first.");
      return;
    }

    const newUserMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: Date.now()
    };
    
    setChatMessages(prev => [...prev, newUserMsg]);
    setIsChatLoading(true);

    try {
      const gemini = new GeminiService(apiKey);
      const history = chatMessages.map(m => ({ role: m.role, content: m.content }));
      
      const { text: responseText, groundingUrls } = await gemini.generateStudyPlan(history, text, files);
      
      const newAiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        content: responseText,
        timestamp: Date.now(),
        groundingUrls: groundingUrls
      };
      
      setChatMessages(prev => [...prev, newAiMsg]);

    } catch (err: any) {
      setChatMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'model',
        content: `Error: ${err.message || 'Failed to communicate with Gemini.'}`,
        isError: true,
        timestamp: Date.now()
      }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  const createNewTabFromChat = (code: string) => {
    const newFileName = `study_${files.length}.py`;
    const newFile: FileTab = { name: newFileName, content: code, type: 'script' };
    setFiles(prev => [...prev, newFile]);
    setActiveTabId(newFileName);
    if (isPyodideReady) {
        pyodideService.writeFile(newFileName, code);
    }
  };

  // File Upload Handler (Raw Files)
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !isPyodideReady) return;

    const reader = new FileReader();
    reader.onload = async (evt) => {
        const arrayBuffer = evt.target?.result as ArrayBuffer;
        const uint8View = new Uint8Array(arrayBuffer);
        
        await pyodideService.writeBinaryFile(file.name, uint8View);
        
        if (file.name.endsWith('.py') || file.name.endsWith('.txt') || file.name.endsWith('.csv')) {
             if (file.name.endsWith('.py')) {
                 const textContent = new TextDecoder().decode(uint8View);
                 setFiles(prev => [...prev, { name: file.name, content: textContent, type: 'script' }]);
                 setActiveTabId(file.name);
             }
        }
        await refreshFileList();
        setConsoleOutput(prev => prev + `\n[SYSTEM] Uploaded ${file.name} to virtual filesystem.\n`);
    };
    reader.readAsArrayBuffer(file);
  };

  const downloadRuntimeFile = async (name: string) => {
     if (!isPyodideReady) return;
     const data = await pyodideService.readBinaryFile(name);
     if (!data) return;
     
     const blob = new Blob([data], { type: 'application/octet-stream' });
     const url = URL.createObjectURL(blob);
     const a = document.createElement('a');
     a.href = url;
     const fileName = name.includes('/') ? name.split('/').pop()! : name;
     a.download = fileName;
     a.click();
     URL.revokeObjectURL(url);
  };

  const downloadCurrentFile = () => {
     const content = getActiveContent();
     const blob = new Blob([content], { type: 'text/plain' });
     const url = URL.createObjectURL(blob);
     const a = document.createElement('a');
     a.href = url;
     a.download = activeTabId;
     a.click();
     URL.revokeObjectURL(url);
  };

  // --- SAVE / LOAD STUDY STATE ---

  const saveStudy = () => {
    const studyState = {
        version: '1.0',
        timestamp: Date.now(),
        activeTabId,
        files,
        chatMessages
    };
    const blob = new Blob([JSON.stringify(studyState, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ubp_study_${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleLoadStudy = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (evt) => {
        try {
            const json = JSON.parse(evt.target?.result as string);
            
            if (!json.files || !Array.isArray(json.files)) {
                throw new Error("Invalid study file format");
            }

            setFiles(json.files);
            if (json.activeTabId) setActiveTabId(json.activeTabId);
            if (json.chatMessages) setChatMessages(json.chatMessages);

            if (isPyodideReady) {
                for (const f of json.files) {
                    await pyodideService.writeFile(f.name, f.content);
                }
                await refreshFileList();
            }

            setConsoleOutput(prev => prev + `\n[SYSTEM] Study loaded successfully. Restored ${json.files.length} files and chat history.\n`);
        } catch (err) {
            setConsoleOutput(prev => prev + `\n[SYSTEM ERROR] Failed to load study: ${err}\n`);
        }
    };
    reader.readAsText(file);
  };

  return (
    <div className="flex flex-col h-screen bg-black text-gray-200 overflow-hidden">
      {/* Header */}
      <header className="flex-none h-14 bg-[#111] border-b border-gray-800 flex items-center justify-between px-6 z-10">
        <div className="flex items-center gap-3">
           <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-blue-600 rounded flex items-center justify-center font-bold text-white">
             UBP
           </div>
           <h1 className="font-bold text-lg tracking-tight">Core Studio <span className="text-gray-500 font-normal text-sm ml-2">v3.9 Ultimate</span></h1>
        </div>
        
        <div className="flex items-center gap-4">
           {/* Study Controls */}
           <div className="flex items-center gap-2 border-r border-gray-700 pr-4 mr-2">
             <button onClick={saveStudy} className="text-xs bg-gray-800 hover:bg-gray-700 text-gray-300 px-3 py-1.5 rounded transition-colors border border-gray-700 flex items-center gap-1">
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" /></svg>
                Save Study
             </button>
             <button onClick={() => loadStudyRef.current?.click()} className="text-xs bg-gray-800 hover:bg-gray-700 text-gray-300 px-3 py-1.5 rounded transition-colors border border-gray-700 flex items-center gap-1">
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
                Load Study
             </button>
             <input type="file" ref={loadStudyRef} onChange={handleLoadStudy} accept=".json" className="hidden" />
           </div>

           {!process.env.API_KEY && (
             <input 
              type="password" 
              placeholder="Paste Gemini API Key"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              className="bg-gray-900 border border-gray-700 rounded px-3 py-1 text-sm w-48 focus:outline-none focus:border-purple-500"
             />
           )}
           <div className="flex items-center gap-2 text-xs font-mono">
              <span className={`w-2 h-2 rounded-full ${isPyodideReady ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' : 'bg-red-500'}`}></span>
              {isPyodideReady ? (isExecuting ? 'EXECUTING...' : 'KERNEL ACTIVE') : 'KERNEL LOADING'}
           </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex overflow-hidden">
        
        {/* Left Panel: Chat (25%) */}
        <div className="w-[350px] flex-none z-0 border-r border-gray-800 flex flex-col">
          <ChatInterface 
            messages={chatMessages} 
            onSendMessage={handleSendMessage}
            isLoading={isChatLoading}
            onExtractCode={createNewTabFromChat}
          />
        </div>

        {/* Sidebar Toggle Bar */}
        <div 
          onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          className="w-1.5 bg-gray-900 hover:bg-gray-800 border-r border-gray-800 cursor-pointer flex flex-col items-center justify-center group"
          title={isSidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
        >
          <div className="text-[10px] text-gray-600 group-hover:text-blue-500 font-bold transition-transform" style={{ transform: isSidebarCollapsed ? 'rotate(180deg)' : 'none' }}>
            {isSidebarCollapsed ? '▶' : '◀'}
          </div>
        </div>

        {/* Middle Panel: File Explorer & Files (15%) */}
        {!isSidebarCollapsed && (
          <div className="w-[220px] bg-[#151515] border-r border-gray-800 flex flex-col text-sm flex-none transition-all">
              <div className="p-3 font-bold text-gray-400 uppercase text-xs tracking-wider border-b border-gray-800 flex justify-between items-center">
                  <span>Workspace</span>
                  <div className="flex gap-2">
                    <button onClick={() => fileInputRef.current?.click()} className="hover:text-white" title="Upload File to Runtime">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
                    </button>
                  </div>
                  <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileUpload} />
              </div>
              <div className="flex-1 overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-gray-800">
                  <div className="mb-4">
                      <span className="text-xs text-gray-500 font-bold px-2">OPEN TABS</span>
                      <ul className="mt-1 space-y-1">
                          {files.map(f => (
                              <li 
                                  key={f.name} 
                                  onClick={() => setActiveTabId(f.name)}
                                  className={`group px-2 py-1 rounded cursor-pointer truncate flex items-center justify-between ${activeTabId === f.name ? 'bg-purple-900/40 text-purple-300 border border-purple-800/50' : 'text-gray-400 hover:bg-gray-800'}`}
                              >
                                  <div className="flex items-center gap-2 truncate pr-2">
                                      <svg className="w-3 h-3 flex-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={f.type === 'core' ? "M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" : "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"} /></svg>
                                      <span className="truncate">{f.name}</span>
                                  </div>
                                  <button 
                                    onClick={(e) => { e.stopPropagation(); deleteTab(f.name); }} 
                                    className="opacity-0 group-hover:opacity-100 hover:text-red-500 text-gray-600 transition-opacity"
                                    title="Delete File"
                                  >
                                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                  </button>
                              </li>
                          ))}
                      </ul>
                  </div>
                  <div>
                      <div className="flex justify-between items-center px-2 mb-1">
                        <span className="text-xs text-gray-500 font-bold">RUNTIME FILES</span>
                        <button onClick={refreshFileList} className="text-[10px] text-gray-600 hover:text-gray-300">REFRESH</button>
                      </div>
                      <ul className="space-y-1">
                          {fileList.length === 0 && <li className="text-xs text-gray-600 px-2 italic">Empty</li>}
                          {fileList.map(name => (
                              <li key={name} className="px-2 py-1 text-gray-500 text-xs flex items-center justify-between group hover:bg-gray-800/50 rounded transition-colors">
                                  <div className="flex items-center gap-2 truncate pr-2">
                                      <svg className="w-3 h-3 flex-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
                                      <span className="truncate" title={name}>{name}</span>
                                  </div>
                                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                      <button 
                                        onClick={(e) => { e.stopPropagation(); downloadRuntimeFile(name); }} 
                                        className="text-gray-400 hover:text-blue-400 p-0.5" 
                                        title="Download File"
                                      >
                                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4-4m0 0l-4 4m4-4v12" /></svg>
                                      </button>
                                      <button 
                                        onClick={(e) => { e.stopPropagation(); deleteRuntimeFile(name); }} 
                                        className="text-gray-600 hover:text-red-500 p-0.5" 
                                        title="Delete File"
                                      >
                                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                      </button>
                                  </div>
                              </li>
                          ))}
                      </ul>
                  </div>
              </div>
          </div>
        )}

        {/* Right Panel: Editor & Output (60%) */}
        <div ref={rightPanelRef} className="flex-1 flex flex-col bg-[#0d0d0d] relative">
          
          {/* Toolbar */}
          <div className="flex-none h-10 flex bg-[#1a1a1a] border-b border-gray-800 items-center px-4 justify-between">
             <div className="flex items-center gap-3">
                <span className="font-mono text-sm text-gray-300 font-bold">{activeTabId}</span>
                {files.find(f => f.name === activeTabId)?.type === 'core' && <span className="text-[10px] bg-blue-900/50 text-blue-400 border border-blue-800 px-1.5 py-0.5 rounded font-bold uppercase tracking-widest">Core Module</span>}
             </div>
             
             <div className="flex items-center gap-2">
                <button onClick={downloadCurrentFile} className="text-gray-400 hover:text-white p-1" title="Download Script">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4-4m0 0l-4 4m4-4v12" /></svg>
                </button>
                {isExecuting ? (
                    <button 
                    onClick={stopExecution}
                    className="bg-red-700 hover:bg-red-600 text-white text-xs font-bold py-1.5 px-4 rounded flex items-center gap-2 transition-all shadow-[0_0_15px_rgba(185,28,28,0.2)] active:scale-95"
                    >
                    <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8 7a1 1 0 00-1 1v4a1 1 0 001 1h4a1 1 0 001-1V8a1 1 0 00-1-1H8z" clipRule="evenodd" /></svg>
                    STOP RUN
                    </button>
                ) : (
                    <button 
                    onClick={runStudy}
                    disabled={!isPyodideReady}
                    className="bg-green-700 hover:bg-green-600 text-white text-xs font-bold py-1.5 px-4 rounded flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-[0_0_15px_rgba(21,128,61,0.2)] active:scale-95"
                    >
                    <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>
                    RUN SCRIPT
                    </button>
                )}
             </div>
          </div>

          {/* Split View: Editor top, Output bottom */}
          <div className="flex-1 flex flex-col min-h-0">
              <div style={{ height: `${editorHeightPercent}%` }} className="border-b border-gray-800 min-h-[100px]">
                  <CodeEditor 
                    code={getActiveContent()} 
                    onChange={handleCodeChange} 
                    label="Editor"
                    readOnly={false}
                  />
              </div>

              {/* Resize Handle */}
              <div 
                className="h-1.5 bg-gray-900 hover:bg-blue-600 cursor-row-resize flex items-center justify-center group z-20"
                onMouseDown={() => { isDraggingSplit.current = true; document.body.style.cursor = 'row-resize'; }}
              >
                  <div className="w-12 h-1 bg-gray-700 rounded-full group-hover:bg-white transition-colors"></div>
              </div>

              <div style={{ height: `${100 - editorHeightPercent}%` }} className="flex min-h-[50px]">
                  <div className={`flex-1 ${generatedImage || scene3dData ? 'w-1/2' : 'w-full'} border-r border-gray-800 h-full`}>
                    <ConsoleOutput output={consoleOutput} />
                  </div>
                  
                  {(generatedImage || scene3dData) && (
                      <div className="w-1/2 flex flex-col bg-[#111] h-full">
                          <div className="px-4 py-2 bg-gray-900 border-b border-gray-800 font-bold text-xs text-gray-500 uppercase flex justify-between items-center">
                              <span>Visuals</span>
                              <div className="flex gap-1">
                                  {generatedImage && (
                                    <button 
                                        onClick={() => setActiveVisualTab('2D')}
                                        className={`px-2 py-0.5 text-[10px] rounded ${activeVisualTab === '2D' ? 'bg-blue-600 text-white' : 'bg-gray-800 text-gray-400'}`}
                                    >2D Plot</button>
                                  )}
                                  {scene3dData && (
                                    <button 
                                        onClick={() => setActiveVisualTab('3D')}
                                        className={`px-2 py-0.5 text-[10px] rounded ${activeVisualTab === '3D' ? 'bg-blue-600 text-white' : 'bg-gray-800 text-gray-400'}`}
                                    >3D View</button>
                                  )}
                              </div>
                          </div>
                          <div className="flex-1 flex items-center justify-center bg-gray-900/50 overflow-hidden relative">
                              {activeVisualTab === '2D' && generatedImage && (
                                  <div className="relative group max-w-full max-h-full p-4">
                                    <img src={`data:image/png;base64,${generatedImage}`} alt="Generated Plot" className="max-w-full max-h-full rounded shadow-2xl border border-gray-700 bg-white" />
                                    <button 
                                        onClick={() => downloadRuntimeFile('plot.png')}
                                        className="absolute top-6 right-6 p-2 bg-black/70 hover:bg-blue-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                                        title="Download Plot"
                                    >
                                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4-4m0 0l-4 4m4-4v12" /></svg>
                                    </button>
                                  </div>
                              )}
                              {activeVisualTab === '3D' && scene3dData && (
                                  <ThreeViewer data={scene3dData} />
                              )}
                          </div>
                      </div>
                  )}
              </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
