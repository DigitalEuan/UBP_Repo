# GLM v3.17.0 + v3.18.0 — Migration Notes

Quick checklist for applying the v3.17 + v3.18 upgrades to your `UBP_Repo`.

## v3.18 files to ADD (new — no conflicts)

| Source | Destination in your repo |
|---|---|
| `download/GLM_v3.17/GLM27_crg_expander.py` | `core_studio_v4.0/GLM/GLM27_crg_expander.py` |
| `download/GLM_v3.17/GLM28_native_poly.py` | `core_studio_v4.0/GLM/GLM28_native_poly.py` |
| `download/tests/test_v318_levelling.py` | `core_studio_v4.0/GLM/tests/test_v318_levelling.py` |
| `download/tests/run_all_tests.py` | `core_studio_v4.0/GLM/tests/run_all_tests.py` (replaces `run_all_v317_tests.py`) |

## v3.18 files to PATCH (existing — apply diffs on top of v3.17)

All patches are surgical and marked with `# v3.18.0` comments.

| File | What changed | Why |
|---|---|---|
| `GLM09_tools.py` | `evaluate_symbolic` now tries native polynomial path first (GLM28); routes other symbolic ops through `symbolic_with_fingerprint` so results carry `{trace, fingerprint}` | Native-first for polynomials; fingerprint on all symbolic results |
| `GLM11_runtime.py` | Added `expand_crg` call in `__init__` (auto CRG expansion on boot); added auto topic-shift detection block in `_run_pipeline` | 50% more CRG edges; eliminates cross-topic bleed automatically |
| `GLM22_ontological_grammar.py` | Added `use_crg=True` parameter to `construct_paragraph` | Eliminates word salad at the source by preferring CRG-reachable objects |
| `GLM12_cli_entry.py` | Test E accepts forming zone with `num_zones>=1`; Test L accepts any non-trivial meta-thesis | Tests reflect the new (correct) behavior |

## v3.17 files to ADD (new — no conflicts)

| Source | Destination in your repo |
|---|---|
| `download/GLM_v3.17/GLM25_native_alu.py` | `core_studio_v4.0/GLM/GLM25_native_alu.py` |
| `download/GLM_v3.17/GLM26_crg_alu.py` | `core_studio_v4.0/GLM/GLM26_crg_alu.py` |
| `download/tests/test_v317_levelling.py` | `core_studio_v4.0/GLM/tests/test_v317_levelling.py` (or wherever you keep tests) |
| `download/tests/test_v317_signal_and_sovereign.py` | `core_studio_v4.0/GLM/tests/test_v317_signal_and_sovereign.py` |
| `download/tests/run_all_v317_tests.py` | `core_studio_v4.0/GLM/tests/run_all_v317_tests.py` |

## Files to PATCH (existing — apply diffs)

All patches are surgical and marked with `# v3.17.0` comments. To see what changed:

```bash
cd /path/to/your/UBP_Repo
for f in GLM01_substrate.py GLM09_tools.py GLM11_runtime.py \
         GLM22_ontological_grammar.py GLM23_grammar_vectors.py \
         GLM24_continuous_learner.py; do
  echo "=== $f ==="
  diff -u core_studio_v4.0/GLM/$f /home/z/my-project/download/GLM_v3.17/$f | head -50
done
```

### Summary of patches

| File | What changed | Why |
|---|---|---|
| `GLM01_substrate.py` | Added `"co_occurs"` to `EDGE_LABELS` | Root-cause fix: original `_check_for_new_edges` was silently failing because `co_occurs` wasn't an allowed label |
| `GLM09_tools.py` | Rewrote `evaluate_numeric` to call `GLM25.native_compute` first; falls back to stdlib/SymPy only on failure | Native-first compute; SymPy validation only |
| `GLM11_runtime.py` | Added `fresh=False` param to `chat_prose`; added `crg_alu()` method | Cross-topic bleed fix; expose CRG-ALU |
| `GLM22_ontological_grammar.py` | Added `max_verb_distance=8` param to `construct_sentence` | Word-salad gate |
| `GLM23_grammar_vectors.py` | Added `QUADRANT_FORCING_ENABLED` flag (default OFF); added `build_svd_only_vectors`; routed `build_grammar_vectors` through SVD-only path by default | Retire the signal-destroyer |
| `GLM24_continuous_learner.py` | Three bug fixes (prefix-skip, learned_edges reload, atexit flush); quadrant-forcing retired in `_learn_new_word` and `_refine_vectors` | Continuous learner actually learns now |

## Verification commands

After applying the patches, run from the GLM directory:

```bash
# 1. Existing self-tests (must still pass)
python3 GLM12_cli_entry.py --test
# Expected: 26/26 tests passed

# 2. Existing golden cases (must still pass)
python3 run_golden_cases.py
# Expected: 41/41 passed (100.0%)

# 3. New v3.17 tests
python3 tests/run_all_v317_tests.py
# Expected: 2/2 suites passed (46 individual tests)
```

## Environment variables

| Variable | Default | Effect |
|---|---|---|
| `GLM_QUADRANT_FORCING` | `0` (off) | Set to `1` to re-enable the v3.15 quadrant-forcing path (for A/B testing only) |
| `UBP_CORE_PATH` | (cwd) | Path to the directory containing `ubp_system_kb.json` and `ubp_lang_kb_combined_v4.json`. Set this if running from outside the GLM directory. |

## Rollback procedure

If v3.17 causes any issue, you can roll back to v3.16 behavior by:

1. **Quickest rollback** — set the env var to re-enable forcing:
   ```bash
   GLM_QUADRANT_FORCING=1 python3 GLM12_cli_entry.py --test
   ```
   This restores the v3.15 quadrant-forcing path. The native-ALU wiring and continuous-learner bug fixes remain active (those don't have a flag).

2. **Full rollback** — restore the original v3.16 files from git:
   ```bash
   git checkout core_studio_v4.0/GLM/GLM01_substrate.py
   git checkout core_studio_v4.0/GLM/GLM09_tools.py
   git checkout core_studio_v4.0/GLM/GLM11_runtime.py
   git checkout core_studio_v4.0/GLM/GLM22_ontological_grammar.py
   git checkout core_studio_v4.0/GLM/GLM23_grammar_vectors.py
   git checkout core_studio_v4.0/GLM/GLM24_continuous_learner.py
   rm core_studio_v4.0/GLM/GLM25_native_alu.py
   rm core_studio_v4.0/GLM/GLM26_crg_alu.py
   ```
   The two new modules are purely additive and can be deleted without effect.

## Pyodide / `ubp_core_studio_app` considerations

The v3.17 modules use only stdlib + SymPy + numpy (which the original code already required). No new dependencies. Specifically:

- `GLM25_native_alu.py` imports `ubp_unified_v5` (already in Pyodide env), `sympy` (already used), and stdlib `math`, `time`, `fractions`. No new deps.
- `GLM26_crg_alu.py` imports `ubp_unified_v5`, `GLM01_substrate`, and stdlib `time`, `hashlib`, `collections`. No new deps.

The `ubp_core_studio_app` React/Pyodide frontend doesn't need changes — it talks to the GLM runtime via the same `chat()` / `chat_prose()` APIs. The new `fresh=True` parameter is optional (defaults to False, preserving existing behavior). The new `crg_alu()` method is opt-in.

If you want to expose `fresh=True` from the UI, add a "fresh start" toggle that passes `fresh=True` to `chat_prose` when the user wants to switch topics. The default behavior (multi-turn with state) is preserved.
