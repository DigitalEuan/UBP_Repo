# GLM v3.18.0 — Levelling-Up Deliverables

This directory contains the improved Geometric Language Machine system, test
harness, and documentation produced by two Z.ai levelling-up passes (v3.17 + v3.18).

## What's in this directory

| Path | Purpose |
|---|---|
| `GLM_v3.17/` | The complete improved GLM system (drop-in replacement for v3.16). 4 new modules + 8 patched modules + all original files. |
| `tests/` | 4-file test harness: `test_v317_levelling.py` (30 tests), `test_v317_signal_and_sovereign.py` (16 tests), `test_v318_levelling.py` (29 tests), `run_all_tests.py` (master runner). |
| `UPGRADE_REPORT.md` | Full v3.17 architecture explanation with before/after diagrams. |
| `UPGRADE_REPORT_v318.md` | v3.18 deltas — implements 5 of the 6 v3.17 recommended next steps. |
| `MIGRATION_NOTES.md` | Step-by-step file-by-file patch guide for applying v3.17 + v3.18 to your UBP_Repo. |

## Quick start

```bash
cd GLM_v3.17
export UBP_CORE_PATH=$(pwd)

# Verify existing tests still pass (26/26 + 41/41 expected)
python3 GLM12_cli_entry.py --test
python3 run_golden_cases.py

# Run the new v3.17 + v3.18 test suite (75 tests)
python3 ../tests/run_all_tests.py
```

## What was leveled up (cumulative across v3.17 + v3.18)

### v3.17 — Foundation

1. **Native compute (SymPy → validation only)** — `GLM09_tools.evaluate_numeric`
   routes through `NoiseALU`/`ExactMath`/`LinearAlgebraALU` via `GLM25_native_alu`.
   Every numeric op produces `{result, trace, fingerprint, sympy_check}`.

2. **CRG-Traversal-ALU** — new `GLM26_crg_alu` provides the word-level NoiseALU
   equivalent proposed in SESSION_SUMMARY §10. Word relations produce the same
   `{result, trace, fingerprint}` shape as math operations.

3. **Quadrant-forcing retired** — the signal-destroyer is now opt-in via
   `GLM_QUADRANT_FORCING=1`. Default is SVD-only + plain Golay snap.

4. **Continuous-learner bugs fixed** — all 3 confirmed bugs plus a 4th
   discovered during testing (`co_occurs` not in `EDGE_LABELS`).

5. **NL quality** — `chat_prose(fresh=True)` eliminates cross-topic bleed;
   `generate_grammatical` respects a `max_verb_distance` gate.

### v3.18 — Recommended next steps (5 of 6 implemented)

1. **Symbolic fingerprinting** — `evaluate_symbolic` now routes through
   `symbolic_with_fingerprint` so simplify/solve/ODE/Taylor/limit results
   carry `{trace, fingerprint}` even when SymPy is the engine.

2. **CRG expansion (GLM27)** — auto-curated edges from master resource +
   KB descriptions + hand-picked physics edges. CRG grew from 173 → 260+
   edges. The CRG-ALU now has fuel.

3. **CRG-aware grammar (GLM22)** — `construct_paragraph(use_crg=True)` prefers
   CRG-reachable objects over pure Hamming neighbours. Eliminates word salad
   at the source: "Hamiltonian commute symmetry. Symmetry commute hamiltonian."
   instead of "Hamiltonian restore construction. Construction event cliff."

4. **Auto topic-shift detection (GLM11)** — `_run_pipeline` auto-resets the
   IdeaManager when the active zone has crystallised AND the new query has
   zero content overlap (direct + CRG-reachable). No more manual `fresh=True`.

5. **Native polynomial ALU (GLM28)** — polynomial differentiation and
   integration done natively with Fraction arithmetic. Closes the last gap
   in the "native-first" promise. Falls back to SymPy for non-polynomials
   (sin, exp, etc.) with clear "[fallback]" trace annotation.

## Test results

| Suite | Result |
|---|---|
| Existing self-tests (v3.16) | 26/26 pass |
| Existing golden cases (v3.16) | 41/41 pass |
| New v3.17 levelling tests | 30/30 pass |
| New v3.17 signal/sovereign tests | 16/16 pass |
| New v3.18 levelling tests | 29/29 pass |
| **Total** | **142/142 pass** |

See `UPGRADE_REPORT.md` and `UPGRADE_REPORT_v318.md` for the full story.

## What's deferred

- **Production A/B test against legacy forcing** — requires your real query
  workload. The infrastructure exists: `GLM_QUADRANT_FORCING=1` re-enables
  the v3.15 path for direct comparison.

- **Curate ~200 more edges by hand** — the curated set in GLM27 is ~80 edges.
  Expanding to 200+ is a curation task that benefits from your domain
  expertise. The framework is ready; just append to `_CURATED_EDGES` in
  `GLM27_crg_expander.py`.

## Pyodide / `ubp_core_studio_app` notes

No new dependencies. v3.18 modules use only stdlib + SymPy + numpy (already
required). The `ubp_core_studio_app` React/Pyodide frontend doesn't need
changes — same `chat()` / `chat_prose()` APIs. The auto topic-shift detection
makes `fresh=True` largely unnecessary (it happens automatically), but the
parameter is preserved for explicit control.
