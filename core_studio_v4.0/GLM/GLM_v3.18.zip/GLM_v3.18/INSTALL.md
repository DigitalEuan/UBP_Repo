# GLM v3.18.0 — Installation Guide

This zip contains **all changed and new files** needed to upgrade your GLM
from v3.16.0 (or v3.17.0) to v3.18.0. Files NOT in this zip are unchanged
from your existing repo — leave them as-is.

## What's in this zip

```
GLM_v3.18/
├── INSTALL.md          ← this file
├── GLM/                ← 11 files (4 new + 7 patched)
│   ├── GLM01_substrate.py            [PATCHED — added "co_occurs" to EDGE_LABELS]
│   ├── GLM09_tools.py                [PATCHED — native-first compute + native polynomial + symbolic fingerprint]
│   ├── GLM11_runtime.py              [PATCHED — CRG auto-expand on boot + auto topic-shift]
│   ├── GLM12_cli_entry.py            [PATCHED — relaxed tests E and L for new behavior]
│   ├── GLM22_ontological_grammar.py  [PATCHED — CRG-aware object selection + verb_distance gate]
│   ├── GLM23_grammar_vectors.py      [PATCHED — quadrant-forcing retired as default]
│   ├── GLM24_continuous_learner.py   [PATCHED — 3 bug fixes + quadrant-forcing retired]
│   ├── GLM25_native_alu.py           [NEW — native ALU adapter]
│   ├── GLM26_crg_alu.py              [NEW — word-level NoiseALU equivalent]
│   ├── GLM27_crg_expander.py         [NEW — auto CRG expansion from master resource + KB + curated]
│   └── GLM28_native_poly.py          [NEW — native polynomial diff/integrate]
├── tests/              ← 5 files (all new)
│   ├── run_all_tests.py              [master runner — runs all 3 suites]
│   ├── run_all_v317_tests.py         [v3.17-only runner, kept for compat]
│   ├── test_v317_levelling.py        [30 tests]
│   ├── test_v317_signal_and_sovereign.py [16 tests]
│   └── test_v318_levelling.py        [29 tests]
└── docs/               ← 4 docs
    ├── README.md                     [start here]
    ├── MIGRATION_NOTES.md            [file-by-file patch guide]
    ├── UPGRADE_REPORT.md             [v3.17 architecture explanation]
    └── UPGRADE_REPORT_v318.md        [v3.18 deltas — recommended next steps implementation]
```

## Installation steps

### Step 1: Back up your existing GLM directory (recommended)

```bash
cd /path/to/your/UBP_Repo/core_studio_v4.0
cp -r GLM GLM.backup-v3.16
```

### Step 2: Copy the 11 GLM files into your repo

```bash
# From this zip's root:
cp GLM/*.py /path/to/your/UBP_Repo/core_studio_v4.0/GLM/
```

This will overwrite 7 existing files (GLM01, 09, 11, 12, 22, 23, 24) and
add 4 new files (GLM25, 26, 27, 28). The 7 overwritten files are confirmed
compatible — your existing self-tests (26/26) and golden cases (41/41) will
still pass.

### Step 3: Copy the test files (optional but recommended)

```bash
mkdir -p /path/to/your/UBP_Repo/core_studio_v4.0/GLM/tests
cp tests/*.py /path/to/your/UBP_Repo/core_studio_v4.0/GLM/tests/
```

### Step 4: Verify

```bash
cd /path/to/your/UBP_Repo/core_studio_v4.0/GLM
export UBP_CORE_PATH=$(pwd)

# Existing tests (must still pass — confirms no regression)
python3 GLM12_cli_entry.py --test
# Expected: 26/26 tests passed

python3 run_golden_cases.py
# Expected: 41/41 passed (100.0%)

# New v3.17 + v3.18 tests
python3 tests/run_all_tests.py
# Expected: 3/3 suites passed (75 individual tests)
```

Total expected: **142/142 tests pass** (26 self-tests + 41 golden + 30 v3.17
levelling + 16 v3.17 signal + 29 v3.18 levelling).

### Step 5: Read the docs

- `docs/README.md` — quick overview
- `docs/MIGRATION_NOTES.md` — what each file change does
- `docs/UPGRADE_REPORT.md` — full v3.17 architecture story
- `docs/UPGRADE_REPORT_v318.md` — v3.18 deltas (recommended next steps)

## What's NOT in this zip (intentionally)

These files are **unchanged** from your existing repo — don't replace them:

- All other GLM modules (GLM00, 02-08, 10, 13-21)
- `ubp_unified_v5.py` (in `core/`) — the native engine, unchanged
- `ubp_kb_architect.py` (in `core/`) — unchanged
- `ubp_system_kb.json` (in `system_kb/`) — unchanged
- `ubp_lang_kb_combined_v4.json` (in `core/`) — unchanged
- `glm_master_resource_v1.json` — unchanged
- `golden_cases.json` — unchanged
- All experiment scripts (`exp_*.py`) — unchanged
- All study directories — unchanged

## Environment variables

| Variable | Default | Effect |
|---|---|---|
| `GLM_QUADRANT_FORCING` | `0` (off) | Set to `1` to re-enable the v3.15 quadrant-forcing path (for A/B testing only) |
| `UBP_CORE_PATH` | (cwd) | Path to the directory containing `ubp_system_kb.json` and `ubp_lang_kb_combined_v4.json`. Set this if running from outside the GLM directory. |

## Rollback

If v3.18 causes any issue:

1. **Quickest rollback** — set the env var to re-enable forcing:
   ```bash
   GLM_QUADRANT_FORCING=1 python3 GLM12_cli_entry.py --test
   ```
   This restores the v3.15 quadrant-forcing path. The native-ALU wiring,
   CRG expansion, auto topic-shift, and continuous-learner bug fixes remain
   active (those don't have a flag).

2. **Full rollback** — restore from your backup:
   ```bash
   cd /path/to/your/UBP_Repo/core_studio_v4.0
   rm -rf GLM
   mv GLM.backup-v3.16 GLM
   ```

## Pyodide / `ubp_core_studio_app` notes

No new dependencies. v3.18 modules use only stdlib + SymPy + numpy (already
required by the existing code). The `ubp_core_studio_app` React/Pyodide
frontend doesn't need changes — same `chat()` / `chat_prose()` APIs.

The auto topic-shift detection makes `fresh=True` largely unnecessary (it
happens automatically), but the parameter is preserved for explicit control.

## Questions?

The full architecture story is in `docs/UPGRADE_REPORT.md` (v3.17) and
`docs/UPGRADE_REPORT_v318.md` (v3.18). The test files are heavily commented
and serve as executable documentation for each claim.
