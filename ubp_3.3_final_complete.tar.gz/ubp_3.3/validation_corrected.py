"""
UBP 3.3 Corrected Validation Test Suite
Using actual module APIs
"""

import sys
import numpy as np

print("="*80)
print("UBP 3.3 CORRECTED VALIDATION TEST SUITE")
print("="*80)

passed = 0
failed = 0

# Test 1: GLR (Golay-Leech-Resonance)
print("\n" + "="*80)
print("TEST 1: GLR Framework")
print("="*80)

try:
    from glr_base import GLRFramework, GLRLevel
    
    # Create GLR instance
    glr = GLRFramework(level=GLRLevel.LEVEL_3)
    
    # Test error correction
    test_data = np.random.randint(0, 2, 24).tolist()
    print(f"Original data: {test_data[:8]}... (24 bits)")
    
    # Apply GLR correction
    result = glr.apply_correction(test_data)
    
    print(f"Correction applied: {result.corrected}")
    print(f"Errors detected: {result.errors_detected}")
    print(f"Errors corrected: {result.errors_corrected}")
    print(f"NRCI improvement: {result.nrci_improvement:.6f}")
    
    print("✓ GLR TEST PASSED")
    passed += 1
        
except Exception as e:
    print(f"✗ GLR TEST FAILED: {e}")
    failed += 1

# Test 2: TGIC
print("\n" + "="*80)
print("TEST 2: TGIC Constraint")
print("="*80)

try:
    from tgic import TGICConstraint, InteractionType
    
    # Create TGIC instance
    tgic = TGICConstraint()
    
    # Test triad constraint
    test_coords = [(0, 0, 0), (1, 1, 1), (2, 2, 2)]
    
    # Validate triad
    is_valid = tgic.validate_triad(test_coords)
    print(f"Triad validation: {is_valid}")
    
    # Calculate interaction energy
    energy = tgic.calculate_interaction_energy(test_coords, InteractionType.RESONANT)
    print(f"Interaction energy: {energy:.6f}")
    
    # Apply constraint
    constrained = tgic.apply_constraint(test_coords)
    print(f"Constraint applied: {len(constrained)} coordinates")
    
    print("✓ TGIC TEST PASSED")
    passed += 1
        
except Exception as e:
    print(f"✗ TGIC TEST FAILED: {e}")
    failed += 1

# Test 3: Observer Framework
print("\n" + "="*80)
print("TEST 3: Self-Actualizing Observer")
print("="*80)

try:
    from observer_framework import SelfActualizingObserver
    
    # Create observer
    observer = SelfActualizingObserver()
    
    # Test convergence
    result = observer.converge(max_iterations=50, tolerance=1e-12)
    
    print(f"Converged to: {result.final_o_observer:.12f}")
    print(f"Iterations: {result.iterations}")
    print(f"Converged: {result.converged}")
    print(f"Final error: {result.final_error:.2e}")
    
    expected = 3.7782010914
    match = abs(result.final_o_observer - expected) < 1e-8
    
    if match and result.converged:
        print("✓ OBSERVER FRAMEWORK TEST PASSED")
        passed += 1
    else:
        print("✗ OBSERVER FRAMEWORK TEST FAILED")
        failed += 1
        
except Exception as e:
    print(f"✗ OBSERVER FRAMEWORK TEST FAILED: {e}")
    failed += 1

# Test 4: Y Constants
print("\n" + "="*80)
print("TEST 4: Y Constants System")
print("="*80)

try:
    from y_constants import YConstants, calculate_y_constant, calculate_y_m_constant
    
    # Create Y constants
    y_const = YConstants()
    
    # Test Y
    Y = calculate_y_constant()
    Y_expected = np.pi / (np.pi**2 + 2)
    print(f"Y constant: {Y:.15f}")
    print(f"Expected:   {Y_expected:.15f}")
    print(f"Match: {abs(Y - Y_expected) < 1e-14}")
    
    # Test Y_m
    Y_m = calculate_y_m_constant()
    phi = (1 + np.sqrt(5)) / 2
    Y_m_expected = Y * phi
    print(f"\nY_m: {Y_m:.15f}")
    print(f"Expected: {Y_m_expected:.15f}")
    print(f"Match: {abs(Y_m - Y_m_expected) < 1e-14}")
    
    precision_ok = (abs(Y - Y_expected) < 1e-14 and 
                   abs(Y_m - Y_m_expected) < 1e-14)
    
    if precision_ok:
        print("✓ Y CONSTANTS TEST PASSED")
        passed += 1
    else:
        print("✗ Y CONSTANTS TEST FAILED")
        failed += 1
        
except Exception as e:
    print(f"✗ Y CONSTANTS TEST FAILED: {e}")
    failed += 1

# Test 5: Wall of Reality
print("\n" + "="*80)
print("TEST 5: Wall of Reality")
print("="*80)

try:
    from wall_of_reality import WallOfReality, check_frequency_limit
    
    # Create wall
    wall = WallOfReality()
    
    # Test frequency checking
    test_freqs = [1e9, 1e10, 1e11, 5e11, 1e12, 2e12]
    
    for freq in test_freqs:
        status = wall.check_frequency(freq)
        proximity = wall.calculate_proximity(freq)
        print(f"{freq:.2e} Hz: {status.name}, proximity={proximity:.3f}")
    
    # Test limit function
    is_valid_1THz = check_frequency_limit(1e12)
    is_valid_2THz = check_frequency_limit(2e12)
    
    limit_ok = is_valid_1THz and not is_valid_2THz
    
    if limit_ok:
        print("✓ WALL OF REALITY TEST PASSED")
        passed += 1
    else:
        print("✗ WALL OF REALITY TEST FAILED")
        failed += 1
        
except Exception as e:
    print(f"✗ WALL OF REALITY TEST FAILED: {e}")
    failed += 1

# Test 6: Cross-Realm Integration
print("\n" + "="*80)
print("TEST 6: Cross-Realm Integration")
print("="*80)

try:
    from quantum_realm import QuantumRealm
    from atomic_realm import AtomicRealm
    from gravitational_realm import GravitationalRealm
    
    # Test quantum
    qr = QuantumRealm()
    qubit_result = qr.model_superconducting_qubit(
        frequency=6.5e9,
        coherence_time=50e-6
    )
    print(f"Qubit NRCI: {qubit_result['nrci']:.6f}")
    
    # Test atomic
    ar = AtomicRealm()
    balmer_result = ar.model_balmer_series(n_max=4)
    print(f"Balmer NRCI: {balmer_result['nrci']:.6f}")
    
    # Test gravitational
    gr = GravitationalRealm()
    gw_result = gr.model_gravitational_wave(
        mass_radiated=3.0,
        distance=410
    )
    print(f"GW NRCI: {gw_result['nrci']:.6f}")
    
    # Check all have NRCI
    has_nrci = all([
        'nrci' in qubit_result,
        'nrci' in balmer_result,
        'nrci' in gw_result
    ])
    
    if has_nrci:
        print("✓ CROSS-REALM INTEGRATION TEST PASSED")
        passed += 1
    else:
        print("✗ CROSS-REALM INTEGRATION TEST FAILED")
        failed += 1
        
except Exception as e:
    print(f"✗ CROSS-REALM INTEGRATION TEST FAILED: {e}")
    failed += 1

# Test 7: Enhanced NRCI
print("\n" + "="*80)
print("TEST 7: Enhanced NRCI System")
print("="*80)

try:
    from enhanced_nrci import calculate_nrci, NRCIResult
    
    # Test NRCI calculation
    observed_variance = 0.001
    random_variance = 1.0
    
    result = calculate_nrci(observed_variance, random_variance)
    
    print(f"Observed variance: {observed_variance}")
    print(f"Random variance: {random_variance}")
    print(f"NRCI: {result.nrci:.6f}")
    print(f"Quality: {result.quality}")
    print(f"Meets target: {result.meets_target}")
    
    expected_nrci = 1 - (observed_variance / random_variance)
    match = abs(result.nrci - expected_nrci) < 1e-10
    
    if match:
        print("✓ ENHANCED NRCI TEST PASSED")
        passed += 1
    else:
        print("✗ ENHANCED NRCI TEST FAILED")
        failed += 1
        
except Exception as e:
    print(f"✗ ENHANCED NRCI TEST FAILED: {e}")
    failed += 1

# Test 8: HexDictionary
print("\n" + "="*80)
print("TEST 8: HexDictionary Content-Addressable Storage")
print("="*80)

try:
    from hex_dictionary import HexDictionary
    
    # Create hex dictionary
    hex_dict = HexDictionary()
    
    # Store some data
    test_data = {"test": "value", "number": 42}
    key = hex_dict.store(test_data)
    print(f"Stored data with key: {key}")
    
    # Retrieve data
    retrieved = hex_dict.retrieve(key)
    print(f"Retrieved: {retrieved}")
    
    # Verify match
    match = retrieved == test_data
    
    if match:
        print("✓ HEXDICTIONARY TEST PASSED")
        passed += 1
    else:
        print("✗ HEXDICTIONARY TEST FAILED")
        failed += 1
        
except Exception as e:
    print(f"✗ HEXDICTIONARY TEST FAILED: {e}")
    failed += 1

# Test 9: State Management
print("\n" + "="*80)
print("TEST 9: State Management (24-bit OffBit)")
print("="*80)

try:
    from state import OffBit, MutableBitfield
    
    # Test OffBit
    offbit = OffBit(0xABCDEF)
    print(f"OffBit value: 0x{offbit.value:06X}")
    print(f"Active bits: {offbit.active_bits}")
    
    # Test bit access in unactivated layer (18-23)
    print("\nUnactivated layer (bits 18-23):")
    for i in range(18, 24):
        bit = offbit.get_bit(i)
        print(f"  Bit {i}: {bit}")
    
    # Test toggle
    toggled = offbit.toggle()
    print(f"\nToggled: 0x{toggled.value:06X}")
    
    # Test Bitfield
    bitfield = MutableBitfield(shape=(10, 10, 10))
    print(f"\nBitfield shape: {bitfield.shape}")
    print(f"Bitfield size: {bitfield.size}")
    
    print("✓ STATE MANAGEMENT TEST PASSED")
    passed += 1
        
except Exception as e:
    print(f"✗ STATE MANAGEMENT TEST FAILED: {e}")
    failed += 1

# Test 10: Toggle Operations
print("\n" + "="*80)
print("TEST 10: Toggle Operations")
print("="*80)

try:
    from toggle_ops import toggle_offbit, apply_toggle_operation
    
    # Test toggle
    original = 0xABCDEF
    toggled = toggle_offbit(original)
    print(f"Original: 0x{original:06X}")
    print(f"Toggled:  0x{toggled:06X}")
    print(f"XOR:      0x{(original ^ toggled):06X}")
    
    # Should be all 1s (0xFFFFFF)
    all_ones = (original ^ toggled) == 0xFFFFFF
    
    if all_ones:
        print("✓ TOGGLE OPERATIONS TEST PASSED")
        passed += 1
    else:
        print("✗ TOGGLE OPERATIONS TEST FAILED")
        failed += 1
        
except Exception as e:
    print(f"✗ TOGGLE OPERATIONS TEST FAILED: {e}")
    failed += 1

# Summary
print("\n" + "="*80)
print("VALIDATION SUMMARY")
print("="*80)
print(f"Tests passed: {passed}/10")
print(f"Tests failed: {failed}/10")
print(f"Success rate: {(passed/10)*100:.1f}%")

if passed == 10:
    print("\n✓ ALL TESTS PASSED - System fully validated!")
elif passed >= 7:
    print(f"\n⚠ Most tests passed - {failed} minor issues to address")
else:
    print(f"\n✗ Multiple failures - {failed} issues need fixing")

print("="*80)
